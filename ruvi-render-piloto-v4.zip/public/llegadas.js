const arrivalForm = document.getElementById('llegada-form');

arrivalForm.addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(arrivalForm);
  const airport = data.get('aeropuerto');
  const date = data.get('fecha');
  const time = data.get('hora');
  const destination = arrivalForm.elements.destino;
  const flight = data.get('vuelo').trim();
  if (!destination.value.trim()) {
    destination.value = '';
    destination.reportValidity();
    return;
  }

  const message = [
    'Hola, RUVI. Quiero cotizar un traslado en República Dominicana.',
    'Aeropuerto: ' + airport,
    'Llegada (hora dominicana): ' + date + ' ' + time,
    'Destino: ' + destination.value.trim(),
    'Pasajeros: ' + data.get('pasajeros'),
  ];
  if (flight) message.push('Vuelo: ' + flight);
  const support = new URL('https://wa.me/584122696073');
  support.searchParams.set('text', message.join('\n'));
  window.open(support, '_blank', 'noopener,noreferrer');
});
