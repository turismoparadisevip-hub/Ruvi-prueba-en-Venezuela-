const areas = {
  pc: { bounds: [17.44, -72.02, 20.05, -68.18], currency: 'DOP' },
  ve: { bounds: [0.6, -73.5, 15.8, -59.7], currency: 'USD' },
};
const vehicles = ['carro', 'mototaxi'];
const quoteServices = [...vehicles, 'delivery'];
const busy = "('offered', 'accepted', 'arrived', 'in_progress')";
const recent = 45_000;
const nearbyLatitudeReach = 0.09;
const offerTime = zone => zone === 've' ? 20_000 : 25_000;
const searchTime = 180_000;
const quoteTime = 300_000;

const json = (data, status = 200) => Response.json(data, {
  status, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' },
});
const fail = (error, status = 400) => json({ error }, status);
const sql = (db, statement, ...args) => db.prepare(statement).bind(...args);
const changed = (result) => result.meta.changes > 0;
const clean = (value, max) => typeof value === 'string' ? value.trim().slice(0, max) : '';
const within = (point, bounds) => Array.isArray(point) && point.length === 2
  && point.every(Number.isFinite) && point[0] >= bounds[0] && point[0] <= bounds[2]
  && point[1] >= bounds[1] && point[1] <= bounds[3];

function configuredRates(env) {
  try {
    const configured = JSON.parse(env.RUVI_RIDE_RATES ?? '{}');
    const result = {};
    for (const [zone, area] of Object.entries(areas)) {
      for (const vehicle of quoteServices) {
        const tariff = configured?.[zone]?.[vehicle] ?? (zone === 'pc' && vehicle === 'delivery'
          ? { base: 30, perKm: 10, perMinute: 0, minimum: 50 } : null);
        if (!tariff) continue;
        const { base, perKm, perMinute, minimum } = tariff;
        if (![base, perKm, perMinute, minimum].every((value) =>
          Number.isFinite(value) && value >= 0 && value <= 1_000_000) || minimum <= 0) continue;
        (result[zone] ??= {})[vehicle] = { base, perKm, perMinute, minimum, currency: area.currency };
      }
    }
    return result;
  } catch {
    return {};
  }
}

async function road(env, from, to, geometry = false) {
  const endpoint = geometry ? 'geojson' : 'json';
  const response = await fetch('https://api.heigit.org/openrouteservice/v2/directions/driving-car/' + endpoint, {
    method: 'POST',
    headers: { Authorization: env.RUVI_ROUTING_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ coordinates: [from, to].map(([lat, lng]) => [lng, lat]) }),
    signal: AbortSignal.timeout(9000),
  });
  if (!response.ok) throw new Error('Routing unavailable');
  const data = await response.json();
  const feature = data.features?.[0];
  const summary = geometry ? feature?.properties?.summary : data.routes?.[0]?.summary;
  if (!Number.isFinite(summary?.distance) || !Number.isFinite(summary?.duration)) {
    throw new Error('No route');
  }
  return {
    distance: summary.distance, duration: summary.duration,
    points: geometry ? feature.geometry.coordinates.map(([lng, lat]) => [lat, lng]) : undefined,
  };
}

async function throttle(db, key, now, delay) {
  return changed(await sql(db, `
    INSERT INTO ruvi_throttle (id, until) VALUES (?, ?)
    ON CONFLICT(id) DO UPDATE SET until = excluded.until WHERE ruvi_throttle.until <= ?
  `, key, now + delay, now).run());
}

async function dispatch(db, ride, now) {
  if (!['searching', 'offered'].includes(ride.state)) return;
  const latReach = nearbyLatitudeReach;
  const longitudeScale = Math.cos(ride.from_lat * Math.PI / 180);
  const lngReach = latReach / longitudeScale;
  // D1 executes the batch as a transaction. A driver's offer is exclusive across riders.
  await db.batch([
    sql(db, `
      UPDATE ruvi_rides SET state = 'unavailable', driver_id = NULL, offer_until = NULL
      WHERE id = ? AND state IN ('searching', 'offered') AND created <= ?
    `, ride.id, now - searchTime),
    sql(db, `
      UPDATE ruvi_rides SET state = 'searching', driver_id = NULL, offer_until = NULL
      WHERE id = ? AND state = 'offered' AND (
        offer_until <= ? OR NOT EXISTS (
          SELECT 1 FROM ruvi_drivers d WHERE d.id = driver_id AND d.online = 1 AND d.seen > ?
        )
      )
    `, ride.id, now, now - recent),
    sql(db, `
      UPDATE ruvi_rides SET state = 'offered', driver_id = candidate.id, offer_until = ?
      FROM (
        SELECT d.id FROM ruvi_drivers d
        WHERE d.zone = ? AND (d.vehicle = ? OR (? = 'delivery' AND d.accepts_delivery = 1)) AND d.online = 1 AND d.seen > ? AND d.id != ?
          AND d.lat BETWEEN ? AND ? AND d.lng BETWEEN ? AND ?
          AND NOT EXISTS (SELECT 1 FROM ruvi_offers o WHERE o.ride_id = ? AND o.driver_id = d.id)
          AND NOT EXISTS (SELECT 1 FROM ruvi_rides r WHERE r.driver_id = d.id AND r.state IN ${busy})
        ORDER BY ((d.lat - ?) * (d.lat - ?)) + ((d.lng - ?) * (d.lng - ?) * ?), d.id
        LIMIT 1
      ) AS candidate
      WHERE ruvi_rides.id = ? AND ruvi_rides.state = 'searching'
    `, Math.min(now + offerTime(ride.zone), ride.created + searchTime),
    ride.zone, ride.vehicle, ride.vehicle, now - recent, ride.rider,
    ride.from_lat - latReach, ride.from_lat + latReach,
    ride.from_lng - lngReach, ride.from_lng + lngReach, ride.id,
    ride.from_lat, ride.from_lat, ride.from_lng, ride.from_lng, longitudeScale ** 2, ride.id),
  ]);
}

async function driverRide(db, user, now) {
  return sql(db, `
    SELECT * FROM ruvi_rides WHERE driver_id = ? AND state IN ('offered', 'accepted', 'arrived', 'in_progress')
      AND (state != 'offered' OR (offer_until > ? AND created > ?))
    ORDER BY created DESC LIMIT 1
  `, user, now, now - searchTime).first();
}

function driverCommission(ride) {
  if (ride.vehicle !== 'carro' && ride.vehicle !== 'mototaxi') return {};
  const commission = Math.round(ride.amount * 15 / 100);
  return { commission, driverNet: ride.amount - commission };
}

function rideView(ride) {
  return {
    id: ride.id, state: ride.state, vehicle: ride.vehicle, amount: ride.amount,
    currency: ride.currency, distance: ride.distance, duration: ride.duration,
    cashPaid: Boolean(ride.cash_paid), cardPaid: Boolean(ride.card_paid_at),
    paymentMethod: ride.payment_method, offerUntil: ride.offer_until,
  };
}

const latestRide = (db, user) => sql(db, 'SELECT * FROM ruvi_rides WHERE rider = ? ORDER BY created DESC LIMIT 1', user).first();
const ownDriver = (db, user) => sql(db, 'SELECT * FROM ruvi_drivers WHERE id = ?', user).first();

async function status(db, user, approved, now) {
  let ride = await latestRide(db, user);
  if (ride && ['searching', 'offered'].includes(ride.state)) {
    await dispatch(db, ride, now);
    ride = await latestRide(db, user);
  }
  const profile = await ownDriver(db, user);
  if (approved && profile?.online && profile.seen > now - recent) {
    // Clear expired offers, including ones for riders who closed the page.
    await db.batch([
      sql(db, `UPDATE ruvi_rides SET state = 'unavailable', driver_id = NULL, offer_until = NULL
        WHERE zone = ? AND (vehicle = ? OR (vehicle = 'delivery' AND ? = 1)) AND state IN ('searching', 'offered') AND created <= ?
      `, profile.zone, profile.vehicle, profile.accepts_delivery, now - searchTime),
      sql(db, `UPDATE ruvi_rides SET state = 'searching', driver_id = NULL, offer_until = NULL
        WHERE zone = ? AND (vehicle = ? OR (vehicle = 'delivery' AND ? = 1)) AND state = 'offered' AND offer_until <= ?
      `, profile.zone, profile.vehicle, profile.accepts_delivery, now),
    ]);
    if (!await driverRide(db, user, now)) {
      const waiting = await sql(db, `
        SELECT r.* FROM ruvi_rides r
        WHERE r.zone = ? AND (r.vehicle = ? OR (r.vehicle = 'delivery' AND ? = 1)) AND r.state = 'searching' AND r.rider != ? AND r.created > ?
          AND r.from_lat BETWEEN ? AND ? AND r.from_lng BETWEEN ? AND ?
          AND NOT EXISTS (SELECT 1 FROM ruvi_offers o WHERE o.ride_id = r.id AND o.driver_id = ?)
        ORDER BY r.created LIMIT 1
      `, profile.zone, profile.vehicle, profile.accepts_delivery, user, now - searchTime, profile.lat - 0.09, profile.lat + 0.09,
      profile.lng - 0.09 / Math.cos(profile.lat * Math.PI / 180), profile.lng + 0.09 / Math.cos(profile.lat * Math.PI / 180), user).first();
      if (waiting) await dispatch(db, waiting, now);
    }
  }
  const job = approved ? await driverRide(db, user, now) : null;
  let driver;
  if (ride?.driver_id && ['accepted', 'arrived', 'in_progress'].includes(ride.state)) {
    const assigned = await ownDriver(db, ride.driver_id);
    if (assigned) driver = {
      name: assigned.name,
      position: assigned.online && assigned.seen > now - recent ? [assigned.lat, assigned.lng] : null,
    };
  }
  return json({
    ride: ride && { ...rideView(ride), pickup: ride.pickup, dropoff: ride.dropoff,
      from: [ride.from_lat, ride.from_lng], driver },
    driver: profile && { approved, online: Boolean(profile.online && profile.seen > now - recent),
      zone: profile.zone, vehicle: profile.vehicle, acceptsDelivery: Boolean(profile.accepts_delivery) },
    job: job && { ...rideView(job), ...driverCommission(job), ...(job.state === 'offered' ? {} : {
      pickup: job.pickup, dropoff: job.dropoff, deliveryNote: job.delivery_note,
      from: [job.from_lat, job.from_lng], to: [job.to_lat, job.to_lng],
    }) },
  });
}

function cardZones(env) {
  if (!env.STRIPE_SECRET_KEY || !env.STRIPE_WEBHOOK_SECRET) return [];
  return (env.RUVI_CARD_ZONES ?? '').split(',').map((zone) => zone.trim()).filter((zone) => Object.hasOwn(areas, zone));
}

async function stripeRequest(env, endpoint, params, idempotencyKey) {
  const headers = { Authorization: 'Bearer ' + env.STRIPE_SECRET_KEY };
  if (idempotencyKey) headers['Idempotency-Key'] = idempotencyKey;
  const response = await fetch('https://api.stripe.com/v1' + endpoint, {
    method: params ? 'POST' : 'GET', headers, body: params,
    signal: AbortSignal.timeout(10000),
  });
  if (!response.ok) throw new Error('Stripe Checkout unavailable');
  return response.json();
}

async function recordCardPayment(db, session, now) {
  if (session.payment_status !== 'paid' || session.mode !== 'payment' || !session.metadata?.ruvi_ride
    || !Number.isInteger(session.amount_total) || typeof session.currency !== 'string'
    || typeof session.id !== 'string') return;
  await sql(db, `
    UPDATE ruvi_rides SET card_paid_at = ?
    WHERE id = ? AND checkout_session = ? AND payment_method = 'card'
      AND card_paid_at IS NULL AND state = 'in_progress' AND amount = ? AND currency = ?
  `, now, session.metadata.ruvi_ride, session.id, session.amount_total, session.currency.toUpperCase()).run();
}

async function stripeWebhook(request, env) {
  if (request.method !== 'POST' || !env.STRIPE_WEBHOOK_SECRET || !env.DB) return fail('unavailable', 503);
  const signature = request.headers.get('Stripe-Signature') ?? '';
  const components = signature.split(',').map((part) => part.trim());
  const timestamp = components.find((part) => part.startsWith('t='))?.slice(2);
  if (!/^\d+$/.test(timestamp ?? '') || Math.abs(Date.now() / 1000 - Number(timestamp)) > 300) return fail('invalid');
  const body = await request.text();
  if (body.length > 250000) return fail('invalid', 413);
  const encoder = new TextEncoder();
  const key = await crypto.subtle.importKey('raw', encoder.encode(env.STRIPE_WEBHOOK_SECRET),
    { name: 'HMAC', hash: 'SHA-256' }, false, ['verify']);
  const message = encoder.encode(timestamp + '.' + body);
  const signatures = components.filter((part) => /^v1=[0-9a-f]{64}$/.test(part));
  const valid = await Promise.all(signatures.map((part) => {
    const bytes = Uint8Array.from(part.slice(3).match(/../g), (hex) => parseInt(hex, 16));
    return crypto.subtle.verify('HMAC', key, bytes, message);
  }));
  if (!valid.includes(true)) return fail('invalid');
  let event;
  try { event = JSON.parse(body); } catch { return fail('invalid'); }
  if (['checkout.session.completed', 'checkout.session.async_payment_succeeded'].includes(event?.type)
      && event.data?.object) {
    await recordCardPayment(env.DB, event.data.object, Date.now());
  }
  await venueStripeEvent(env, event);
  if (['checkout.session.completed','checkout.session.async_payment_succeeded'].includes(event?.type)) await commerceRecordPayment(env.DB,event.data.object,Date.now());
  return json({ received: true });
}

async function rideCheckout(env, ride, origin, now) {
  const db = env.DB;
  if (ride.card_paid_at) return json({ paid: true });
  if (ride.checkout_session) {
    const session = await stripeRequest(env, '/checkout/sessions/' + encodeURIComponent(ride.checkout_session));
    if (session.payment_status === 'paid') {
      await recordCardPayment(db, session, now);
      const current = await sql(db, 'SELECT card_paid_at FROM ruvi_rides WHERE id = ?', ride.id).first();
      return current?.card_paid_at ? json({ paid: true }) : fail('changed', 409);
    }
    if (session.status === 'open' && session.url) return stripeCheckoutLink(session.url);
    if (session.status !== 'expired') return fail('wait', 409);
    const reset = await sql(db, `
      UPDATE ruvi_rides SET checkout_session = NULL, checkout_attempt = checkout_attempt + 1
      WHERE id = ? AND checkout_session = ? AND card_paid_at IS NULL AND state = 'in_progress'
    `, ride.id, ride.checkout_session).run();
    if (!changed(reset)) return fail('wait', 409);
    ride.checkout_attempt++;
  }

  const returnToRide = new URL('/#mi-carrera', origin).href;
  const params = new URLSearchParams({
    mode: 'payment',
    'adaptive_pricing[enabled]': 'false',
    'payment_method_types[0]': 'card',
    'line_items[0][price_data][currency]': ride.currency.toLowerCase(),
    'line_items[0][price_data][product_data][name]': 'RUVI · Transporte',
    'line_items[0][price_data][unit_amount]': String(ride.amount),
    'line_items[0][quantity]': '1',
    'metadata[ruvi_ride]': ride.id,
    success_url: returnToRide,
    cancel_url: returnToRide,
  });
  const session = await stripeRequest(env, '/checkout/sessions', params, 'ruvi-ride-' + ride.id + '-' + ride.checkout_attempt);
  const saved = await sql(db, `
    UPDATE ruvi_rides SET checkout_session = ?
    WHERE id = ? AND checkout_session IS NULL AND checkout_attempt = ? AND card_paid_at IS NULL AND state = 'in_progress'
  `, session.id, ride.id, ride.checkout_attempt).run();
  if (!changed(saved)) {
    const current = await sql(db, 'SELECT checkout_session FROM ruvi_rides WHERE id = ?', ride.id).first();
    if (current?.checkout_session !== session.id) return fail('wait', 409);
  }
  return stripeCheckoutLink(session.url);
}

function stripeCheckoutLink(url) {
  if (typeof url !== 'string' || !url.startsWith('https://checkout.stripe.com/')) return fail('card_unavailable', 503);
  return json({ checkoutUrl: url });
}

function driverDocumentTable(db) {
  return db.prepare(`CREATE TABLE IF NOT EXISTS ruvi_driver_documents (
    driver_id TEXT NOT NULL REFERENCES ruvi_drivers(id), kind TEXT NOT NULL,
    photo TEXT NOT NULL, version INTEGER NOT NULL DEFAULT 1, PRIMARY KEY (driver_id, kind)
  )`).run();
}

const passengerBookingOrigins = new Set([
  'https://venezuela.ruviconecta.com',
  'https://ruvi-prueba-venezuela.onrender.com',
]);
const passengerBookingMethods = {
  config: ['GET'], passenger: ['GET', 'POST'], quote: ['POST'], book: ['POST'],
  status: ['POST'], cancel: ['POST'], 'pickup-route': ['POST'],
};

async function renderPassengerBooking(request, env, endpoint) {
  const origin = request.headers.get('Origin');
  if (!passengerBookingOrigins.has(origin) || !Object.hasOwn(passengerBookingMethods, endpoint)) return fail('invalid', 403);
  const methods = passengerBookingMethods[endpoint];
  const cors = {
    'Access-Control-Allow-Origin': origin,
    'Access-Control-Allow-Methods': methods.join(', '),
    'Access-Control-Allow-Headers': 'Authorization, Content-Type',
    Vary: 'Origin',
  };
  if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors });

  async function handle() {
    if (!methods.includes(request.method)) return fail('invalid', 405);
    const headers = new Headers({ Origin: new URL(request.url).origin, 'Content-Type': 'application/json' });
    const token = request.headers.get('Authorization')?.match(/^Bearer ([A-Za-z0-9._-]{1,8192})$/)?.[1];
    if (token) {
      let claims;
      try {
        const parts = token.split('.');
        if (parts.length !== 3) return fail('signin', 401);
        claims = JSON.parse(atob(parts[1].replaceAll('-', '+').replaceAll('_', '/')));
      } catch { return fail('signin', 401); }
      if (claims?.aud !== 'ruvi-pasajeros' || claims.iss !== 'https://securetoken.google.com/ruvi-pasajeros'
        || !claims.sub || claims.exp <= Date.now() / 1000) return fail('signin', 401);
      const lookup = await fetch('https://identitytoolkit.googleapis.com/v1/accounts:lookup?key=AIzaSyAyPZNWaxf65QPb6qXQz211s6yjuP4NzQE', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken: token }), signal: AbortSignal.timeout(5000),
      });
      if (!lookup.ok) return fail(lookup.status >= 500 ? 'unavailable' : 'signin', lookup.status >= 500 ? 503 : 401);
      const [account] = (await lookup.json()).users ?? [];
      if (account?.localId !== claims.sub || account.disabled || !account.providerUserInfo?.some(({ providerId }) => ['google.com', 'password', 'phone'].includes(providerId))) return fail('signin', 401);
      headers.set('oai-authenticated-user-id', 'firebase-passenger:' + account.localId);
    } else if (endpoint !== 'config') return fail('signin', 401);

    let body;
    if (request.method === 'POST') {
      if (!request.headers.get('Content-Type')?.startsWith('application/json')) return fail('invalid');
      body = await request.text();
      if (body.length > 5000) return fail('invalid', 413);
      if (endpoint === 'quote') {
        let quote;
        try { quote = JSON.parse(body); } catch { return fail('invalid'); }
        if (quote?.zone !== 've') return fail('invalid');
      }
    }
    const path = '/api/ruvi/' + endpoint;
    return api(new Request(new URL(path, request.url), { method: request.method, headers, body }), env, path);
  }
  let response;
  try { response = await handle(); } catch { response = fail('unavailable', 503); }
  for (const [name, value] of Object.entries(cors)) response.headers.set(name, value);
  return response;
}

async function api(request, env, path) {
  const user = request.headers.get('oai-authenticated-user-id');
  const email = request.headers.get('oai-authenticated-user-email')?.trim().toLowerCase();
  const renderDriver = user?.startsWith('render-driver:');
  const approved = renderDriver
    ? (env.RUVI_DRIVER_IDS ?? '').split(',').some(item => item.trim() === user)
    : Boolean(email && (env.RUVI_DRIVER_EMAILS ?? '').split(',').some((item) => item.trim().toLowerCase() === email));
  const estimates = configuredRates(env);
  const tariffs = env.RUVI_ROUTING_KEY && env.DB ? estimates : {};
  if (path === '/api/ruvi/config' && request.method === 'GET') {
    const locationCountry = request.cf?.country ?? request.headers.get('CF-IPCountry');
    const country = /^[A-Z]{2}$/.test(locationCountry ?? '') && locationCountry !== 'XX' ? locationCountry : null;
    const connectionCity = request.cf?.city ?? request.headers.get('CF-IPCity');
    const city = country === 'VE' && /^(valencia|maracay|caracas)$/i.test(connectionCity?.trim() ?? '')
      ? connectionCity.trim().toLowerCase() : null;
    return json({ signedIn: Boolean(user), country, city, estimates, flightSearch: flightSearchEnabled(env), cardZones: cardZones(env), zones: Object.fromEntries(Object.entries(tariffs)
      .map(([zone, types]) => [zone, Object.keys(types)])) });
  }
  if (request.method === 'GET' && path.startsWith('/api/ruvi/solutions/')) return solutionsApi(request,env,path,user,email);
  if (request.method === 'GET' && path.startsWith('/api/ruvi/commerce/')) return commerceApi(request,env,path,user,email);
  if (request.method === 'GET' && path.startsWith('/api/ruvi/merchant/')) return merchantRead(request, env, path, user);
  if (request.method === 'GET' && path.startsWith('/api/ruvi/venues/')) {
    const response = await venueRead(request, env, path, user, email);
    const previewOrigin = 'https://ruvi-prueba-venezuela.onrender.com';
    if (path === '/api/ruvi/venues/list' && request.headers.get('Origin') === previewOrigin) {
      response.headers.set('Access-Control-Allow-Origin', previewOrigin);
      response.headers.append('Vary', 'Origin');
    }
    return response;
  }
  if (path === '/api/ruvi/driver/photos' && request.method === 'GET') {
    if (!user) return fail('signin', 401);
    if (!env.DB) return fail('unavailable', 503);
    const result = await sql(env.DB, 'SELECT kind, photo, version FROM ruvi_driver_photos WHERE driver_id = ?', user).all();
    await driverDocumentTable(env.DB);
    const documents = await sql(env.DB, 'SELECT kind, photo, version FROM ruvi_driver_documents WHERE driver_id = ?', user).all();
    return json({ photos: [...result.results, ...documents.results] });
  }
  if (path === '/api/ruvi/driver/profile' && request.method === 'GET') {
    if (!user || !email) return fail('signin', 401);
    if (!env.DB) return fail('unavailable', 503);
    const profile = await sql(env.DB, `
      SELECT name, city, zone, vehicle, car_details, plate FROM ruvi_drivers WHERE id = ?
    `, user).first();
    return json({ profile, approved });
  }
  if (path === '/api/ruvi/passenger' && request.method === 'GET') {
    if (!user) return fail('signin', 401);
    if (!env.DB) return fail('unavailable', 503);
    const profile = await sql(env.DB, 'SELECT name, payment FROM ruvi_passengers WHERE id = ?', user).first();
    return json({ profile: profile ?? null });
  }
  if (request.method !== 'POST' || request.headers.get('Origin') !== new URL(request.url).origin) return fail('invalid', 403);
  if (!user) return fail('signin', 401);
  if (!env.DB) return fail('unavailable', 503);
  if (!request.headers.get('Content-Type')?.startsWith('application/json')) return fail('invalid');
  const raw = await request.text();
  if (raw.length > (['/api/ruvi/merchant/product', '/api/ruvi/driver/photos','/api/ruvi/commerce/listing'].includes(path) ? 150000 : path.startsWith('/api/ruvi/solutions/') ? 15000 : 5000)) return fail('invalid', 413);
  let body;
  try { body = JSON.parse(raw); } catch { return fail('invalid'); }
  if (!body || typeof body !== 'object') return fail('invalid');

  const db = env.DB;
  const now = Date.now();
  if (path.startsWith('/api/ruvi/solutions/')) return solutionsApi(request,env,path,user,email,body,now);
  if (path.startsWith('/api/ruvi/commerce/')) return commerceApi(request,env,path,user,email,body,now);
  if (path.startsWith('/api/ruvi/merchant/')) return merchantWrite(request, env, path, user, body, now);
  if (path.startsWith('/api/ruvi/venues/')) return venueWrite(request, env, path, user, email, body, now);
  if (path === "/api/ruvi/group-rides") return groupRideApi(db, user, approved, body, now);
  if (path === '/api/ruvi/status') return status(db, user, approved, now);

  if (path === '/api/ruvi/driver/photos') {
    const { kind, photo, version } = body;
    const document = ['license', 'insurance', 'medical', 'marbete'].includes(kind);
    if ((!document && !['front', 'side', 'interior'].includes(kind)) || typeof photo !== 'string'
      || photo.length > 130000 || !/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(photo)
      || !Number.isSafeInteger(version) || version < 0) return fail('invalid');
    const profile = await ownDriver(db, user);
    if (!profile) return fail('profile', 403);
    if ((kind === 'medical' && profile.zone !== 've') || (kind === 'marbete' && (profile.zone !== 'pc' || profile.vehicle === 'mototaxi'))) return fail('invalid');
    const table = document ? 'ruvi_driver_documents' : 'ruvi_driver_photos';
    if (document) await driverDocumentTable(db);
    const result = version === 0
      ? await sql(db, 'INSERT OR IGNORE INTO ' + table + ' (driver_id, kind, photo) VALUES (?, ?, ?)', user, kind, photo).run()
      : await sql(db, 'UPDATE ' + table + ' SET photo = ?, version = version + 1 WHERE driver_id = ? AND kind = ? AND version = ?',
        photo, user, kind, version).run();
    return changed(result) ? json({ saved: true }) : fail('changed', 409);
  }

  if (path === '/api/ruvi/driver/profile') {
    if (!email) return fail('signin', 401);
    const country = body.country ?? 'VE';
    const vehicle = body.vehicle ?? 'carro';
    const cityInput = clean(body.city, 100);
    const cities = { caracas: 'Caracas', valencia: 'Valencia', maracay: 'Maracay' };
    const city = country === 'VE' ? cities[venueKey(cityInput)] : cityInput;
    const name = clean(body.name, 100);
    const phone = clean(body.phone, 30);
    const details = clean(body.carDetails, 100);
    const plate = clean(body.plate, 20).toUpperCase();
    if (!["VE", "DO", "US", "ES", "PT", "FR", "IT", "DE", "NL", "BE", "GB", "IE", "CH", "AT", "SE", "NO", "DK", "FI", "PL", "CZ", "GR", "RO", "HU", "BG", "HR", "SK", "SI", "EE", "LV", "LT", "LU", "MT", "CY", "IS", "AL", "AD", "BA", "LI", "MC", "ME", "MK", "RS", "SM", "VA", "MD", "UA", "BY"].includes(country) || !vehicles.includes(vehicle) || !city || !name || !details
      || !/^\+?[0-9 ()-]{7,29}$/.test(phone) || phone.replace(/\D/g, '').length < 7
      || !/^[A-Z0-9][A-Z0-9 -]{1,18}[A-Z0-9]$/.test(plate)) return fail('invalid');
    const result = await sql(db, `
      INSERT INTO ruvi_drivers (id, name, phone, city, zone, vehicle, car_details, plate)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(id) DO NOTHING
    `, user, name, phone, city, country === 'DO' ? 'pc' : country === 'VE' ? 've' : country === 'US' ? 'us' : 'eu:' + country, vehicle, details, plate).run();
    return changed(result) ? json({ registered: true }, 201) : fail('profile_exists', 409);
  }

  if (path === '/api/ruvi/passenger') {
    const name = clean(body.name, 100);
    const { payment } = body;
    if (!name || !['cash', 'card'].includes(payment)) return fail('invalid');
    await sql(db, `
      INSERT INTO ruvi_passengers (id, name, payment) VALUES (?, ?, ?)
      ON CONFLICT(id) DO UPDATE SET name = excluded.name, payment = excluded.payment
    `, user, name, payment).run();
    return json({ profile: { name, payment } });
  }

  if (path === '/api/ruvi/quote') {
    const { zone, vehicle, from, to } = body;
    const pickup = clean(body.pickup, 300);
    const dropoff = clean(body.dropoff, 300);
    const tariff = tariffs[zone]?.[vehicle];
    if (!quoteServices.includes(vehicle) || !Object.hasOwn(areas, zone) || !tariff) return fail('unavailable', 503);
    const quoteBounds = zone === 'pc' && vehicle === 'delivery' ? [18.40, -68.77, 18.92, -68.22] : areas[zone].bounds;
    if (!pickup || !dropoff || !within(from, quoteBounds) || !within(to, quoteBounds)) return fail('invalid');
    if (!await throttle(db, 'quote:' + user, now, 2500)) return fail('wait', 429);
    let route;
    try { route = await road(env, from, to); } catch { return fail('route', 502); }
    if (route.distance <= 0 || route.duration <= 0) return fail('route', 422);
    const amount = Math.round(100 * Math.max(tariff.minimum,
      tariff.base + route.distance * tariff.perKm / 1000 + route.duration * tariff.perMinute / 60));
    const id = crypto.randomUUID();
    const expires = now + quoteTime;
    await sql(db, 'DELETE FROM ruvi_quotes WHERE rider = ? AND expires <= ?', user, now).run();
    await sql(db, `
      INSERT INTO ruvi_quotes
        (id, rider, zone, vehicle, pickup, dropoff, from_lat, from_lng, to_lat, to_lng, amount, currency, distance, duration, expires)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, id, user, zone, vehicle, pickup, dropoff, ...from, ...to, amount, tariff.currency, route.distance, route.duration, expires).run();
    const [lat, lng] = from;
    const lngReach = nearbyLatitudeReach / Math.cos(lat * Math.PI / 180);
    const nearby = await sql(db, `
      SELECT 1 AS available FROM ruvi_drivers d
      WHERE d.zone = ? AND (d.vehicle = ? OR (? = 'delivery' AND d.accepts_delivery = 1))
        AND d.online = 1 AND d.seen > ? AND d.id != ?
        AND d.lat BETWEEN ? AND ? AND d.lng BETWEEN ? AND ?
        AND NOT EXISTS (SELECT 1 FROM ruvi_rides r WHERE r.driver_id = d.id AND r.state IN ${busy})
      LIMIT 1
    `, zone, vehicle, vehicle, now - recent, user,
    lat - nearbyLatitudeReach, lat + nearbyLatitudeReach, lng - lngReach, lng + lngReach).first();
    return json({ id, amount, currency: tariff.currency, expires, ...route, nearbyDrivers: Boolean(nearby) });
  }

  if (path === '/api/ruvi/book' || path === '/api/ruvi/ride-checkout') {
    const profile = await sql(db, 'SELECT id FROM ruvi_passengers WHERE id = ?', user).first();
    if (!profile) return fail('profile', 403);
  }

  if (path === '/api/ruvi/book') {
    const id = clean(body.id, 36);
    const payment = body.payment ?? 'cash';
    if (payment !== 'cash' && payment !== 'card') return fail('invalid');
    const quote = await sql(db, 'SELECT zone, vehicle FROM ruvi_quotes WHERE id = ? AND rider = ? AND expires > ?', id, user, now).first();
    if (!quote) {
      const existing = await sql(db, 'SELECT id FROM ruvi_rides WHERE id = ? AND rider = ?', id, user).first();
      return existing ? status(db, user, approved, now) : fail('expired', 409);
    }
    const deliveryNote = quote.vehicle === 'delivery' ? clean(body.deliveryNote, 300) || null : null;
    if (!tariffs[quote.zone]?.[quote.vehicle]) return fail('unavailable', 503);
    if (payment === 'card' && !cardZones(env).includes(quote.zone)) return fail('card_unavailable', 503);
    const result = await db.batch([
      sql(db, `
        UPDATE ruvi_rides SET state = 'unavailable', driver_id = NULL, offer_until = NULL
        WHERE rider = ? AND state IN ('searching', 'offered') AND created <= ?
      `, user, now - searchTime),
      sql(db, `
        INSERT OR IGNORE INTO ruvi_rides
          (id, rider, zone, vehicle, pickup, dropoff, from_lat, from_lng, to_lat, to_lng, amount, currency, distance, duration, created, state, payment_method, delivery_note)
        SELECT id, rider, zone, vehicle, pickup, dropoff, from_lat, from_lng, to_lat, to_lng, amount, currency, distance, duration, ?, 'searching', ?, ?
        FROM ruvi_quotes WHERE id = ? AND rider = ? AND expires > ?
      `, now, payment, deliveryNote, id, user, now),
      sql(db, `
        DELETE FROM ruvi_quotes WHERE id = ? AND rider = ? AND EXISTS (
          SELECT 1 FROM ruvi_rides WHERE id = ? AND rider = ?
        )
      `, id, user, id, user),
    ]);
    if (!changed(result[1]) && !await sql(db, 'SELECT id FROM ruvi_rides WHERE id = ? AND rider = ?', id, user).first()) return fail('active', 409);
    return status(db, user, approved, now);
  }

  if (path === '/api/ruvi/ride-checkout') {
    const ride = await sql(db, `
      SELECT * FROM ruvi_rides WHERE id = ? AND rider = ? AND payment_method = 'card' AND state = 'in_progress'
    `, clean(body.id, 36), user).first();
    if (!ride) return fail('changed', 409);
    if (!cardZones(env).includes(ride.zone)) return fail('card_unavailable', 503);
    return rideCheckout(env, ride, new URL(request.url).origin, now);
  }

  if (path === '/api/ruvi/cancel') {
    const result = await sql(db, `
      UPDATE ruvi_rides SET state = 'cancelled', driver_id = NULL, offer_until = NULL
      WHERE id = ? AND rider = ? AND state IN ('searching', 'offered', 'accepted', 'arrived')
    `, clean(body.id, 36), user).run();
    return changed(result) ? status(db, user, approved, now) : fail('changed', 409);
  }

  if (path === '/api/ruvi/pickup-route') {
    const ride = await sql(db, `
      SELECT r.from_lat, r.from_lng, d.lat, d.lng FROM ruvi_rides r JOIN ruvi_drivers d ON d.id = r.driver_id
      WHERE r.id = ? AND r.rider = ? AND r.state = 'accepted' AND d.online = 1 AND d.seen > ?
    `, clean(body.id, 36), user, now - recent).first();
    if (!ride) return fail('changed', 409);
    if (!await throttle(db, 'route:' + user, now, 20_000)) return fail('wait', 429);
    try {
      return json(await road(env, [ride.lat, ride.lng], [ride.from_lat, ride.from_lng], true));
    } catch { return fail('route', 502); }
  }

  if (!approved) return fail('approval', 403);
  const profile = await ownDriver(db, user);
  if (!profile) return fail('invalid');

  if (path === '/api/ruvi/driver/delivery') {
    if (typeof body.enabled !== 'boolean' || !tariffs[profile.zone]?.delivery) return fail('unavailable', 503);
    const result = await sql(db, `
      UPDATE ruvi_drivers SET accepts_delivery = ?
      WHERE id = ? AND NOT EXISTS (
        SELECT 1 FROM ruvi_rides WHERE driver_id = ? AND vehicle = 'delivery' AND state IN ${busy}
      )
    `, Number(body.enabled), user, user).run();
    return changed(result) ? status(db, user, approved, now) : fail('active', 409);
  }

  if (path === '/api/ruvi/driver/location') {
    if (renderDriver) {
      const photos = await sql(db, `SELECT count(*) AS total FROM ruvi_driver_photos WHERE driver_id = ?
        AND (? = 'carro' OR kind IN ('front', 'side'))`, user, profile.vehicle).first();
      if (photos.total < (profile.vehicle === 'mototaxi' ? 2 : 3)) return fail('photos', 403);
    }
    const point = body.position;
    const zoneRates = tariffs[profile.zone];
    if (!zoneRates?.[profile.vehicle] && !(profile.accepts_delivery && zoneRates?.delivery)) return fail('unavailable', 503);
    if (!within(point, areas[profile.zone].bounds)) return fail('area', 422);
    await sql(db, 'UPDATE ruvi_drivers SET online = 1, lat = ?, lng = ?, seen = ? WHERE id = ?',
      ...point, now, user).run();
    return status(db, user, approved, now);
  }

  if (path === '/api/ruvi/driver/offline') {
    await db.batch([
      sql(db, 'UPDATE ruvi_drivers SET online = 0, lat = NULL, lng = NULL, seen = 0 WHERE id = ?', user),
      sql(db, `UPDATE ruvi_rides SET state = 'searching', driver_id = NULL, offer_until = NULL
        WHERE driver_id = ? AND state = 'offered'`, user),
    ]);
    return status(db, user, approved, now);
  }

  if (path === '/api/ruvi/driver/action') {
    const job = await driverRide(db, user, now);
    if (!job || job.id !== body.id) return fail('changed', 409);
    const transitions = {
      accept: ['offered', 'accepted'], decline: ['offered', 'searching'], arrived: ['accepted', 'arrived'],
      start: ['arrived', 'in_progress'], paid: ['in_progress', 'completed'],
      complete: ['in_progress', 'completed'],
    };
    const transition = Object.hasOwn(transitions, body.action) && transitions[body.action];
    if (!transition || job.state !== transition[0]) return fail('changed', 409);
    if (body.action === 'accept' && (!profile.online || profile.seen <= now - recent)) return fail('offline', 409);
    const result = await sql(db, `
      UPDATE ruvi_rides SET state = ?, driver_id = ?, offer_until = NULL, cash_paid = ?
      WHERE id = ? AND driver_id = ? AND state = ? AND (offer_until IS NULL OR offer_until > ?)
        AND (? != 'paid' OR payment_method = 'cash')
        AND (? != 'complete' OR (payment_method = 'card' AND card_paid_at IS NOT NULL))
        AND (? != 'accept' OR EXISTS (
          SELECT 1 FROM ruvi_drivers d WHERE d.id = driver_id AND d.online = 1 AND d.seen > ?
        ))
    `, transition[1], body.action === 'decline' ? null : user, body.action === 'paid' ? 1 : 0,
    job.id, user, transition[0], now, body.action, body.action, body.action, now - recent).run();
    if (!changed(result)) return fail('changed', 409);
    if (body.action === 'decline') await dispatch(db, { ...job, state: 'searching' }, now);
    return status(db, user, approved, now);
  }

  return fail('invalid', 404);
}

export default {
  async fetch(request, env) {
    const { pathname } = new URL(request.url);
    if (pathname.startsWith('/api/ruvi/')) {
      try {
        if (pathname.startsWith('/api/ruvi/render-passenger/')) return await renderPassengerBooking(request, env, pathname.slice('/api/ruvi/render-passenger/'.length));
        if (pathname === '/api/ruvi/render-driver') return await renderDriverBridge(request, env);
        if (pathname === '/api/ruvi/assistant') return await assistantApi(request, env);
        if (pathname.startsWith('/api/ruvi/flights/')) return await flightsApi(request, env, pathname);
        if (pathname === '/api/ruvi/stripe-webhook') return await stripeWebhook(request, env);
        return await api(request, env, pathname);
      }
      catch (error) {
        console.error('RUVI request failed:', error.name);
        return fail('unavailable', 503);
      }
    }
    if (!['GET', 'HEAD'].includes(request.method)) return new Response(null, { status: 405 });
    if (pathname === '/conductor' || pathname === '/conductor/') {
      const region = new URL(request.url).searchParams.get('region');
      const welcome = new URL('/welcome/driver.html', request.url);
      welcome.searchParams.set('region', ['pc', 've', 'us', 'eu'].includes(region) ? region : 've');
      return Response.redirect(welcome.href, 302);
    }
    const assetPath = pathname.endsWith('/') ? pathname + 'index.html' : pathname;
    const file = Object.hasOwn(assets, assetPath) && assets[assetPath];
    if (!file) return new Response(null, { status: 404 });
    return new Response(request.method === 'HEAD' ? null : Uint8Array.from(atob(file.body), (byte) => byte.charCodeAt(0)), {
      headers: { 'Content-Type': file.type, 'Cache-Control': 'no-cache', 'X-Content-Type-Options': 'nosniff' },
    });
  },
};
