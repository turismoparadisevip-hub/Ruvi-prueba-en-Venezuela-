(() => {
  if (location.hostname !== 'ruvi-venezuela-piloto.onrender.com') return;
  const section = document.getElementById('arma-tu-salida');
  const form = document.getElementById('salida-form');
  const results = document.getElementById('salida-results');
  const status = document.getElementById('salida-status');
  const plans = [
    { name: 'Tarde de cine', type: 'familia', activity: 7, transfer: 16, pickup: '14:00', returnAt: '18:00' },
    { name: 'Café y paseo', type: 'pareja', activity: 10, transfer: 14, pickup: '16:00', returnAt: '19:00' },
    { name: 'Boliche con amigos', type: 'amigos', activity: 9, transfer: 18, pickup: '17:00', returnAt: '20:30' },
  ];
  const money = new Intl.NumberFormat('es-VE', { style: 'currency', currency: 'USD' });

  section.hidden = false;
  form.addEventListener('submit', event => {
    event.preventDefault();
    const filters = new FormData(form);
    const group = Number(filters.get('personas'));
    const budget = Number(filters.get('presupuesto'));
    const matches = plans
      .map(plan => ({ ...plan, total: plan.activity * group + plan.transfer }))
      .filter(plan => plan.total <= budget && plan.returnAt <= filters.get('regreso')
        && (!filters.get('tipo') || plan.type === filters.get('tipo')))
      .sort((a, b) => a.total - b.total);
    results.replaceChildren();
    status.textContent = matches.length
      ? 'Planes de demostración. Precios y horarios ilustrativos.'
      : 'No hay ejemplos que coincidan. Ajusta el presupuesto, el tipo de plan o la hora de regreso.';
    for (const plan of matches) {
      const card = document.createElement('article');
      card.className = 'card';
      const title = document.createElement('h4');
      title.textContent = plan.name;
      const detail = document.createElement('p');
      detail.textContent = money.format(plan.total) + ' para ' + group
        + (group === 1 ? ' persona' : ' personas') + '. Actividad, ida y regreso.';
      const schedule = document.createElement('p');
      schedule.textContent = 'Recogida ' + plan.pickup + ' · Regreso ' + plan.returnAt;
      card.append(title, detail, schedule);
      results.append(card);
    }
  });
})();
