(() => {
  const byId = (id) => document.getElementById(id);
  const text = localize;
  const money = (data) => new Intl.NumberFormat(locales[language], {
    style: 'currency', currency: data.currency,
  }).format(data.amount / 100);
  const zoneKey = () => zonePicker.querySelector(':checked').value;
  const isRide = () => ['carro', 'mototaxi', 'delivery'].includes(selected);
  const register = byId('ride-register');
  register.addEventListener('click', () => {
    const account = byId('ruvi-account');
    account.showModal();
    if (config?.signedIn && !passengerForm.hidden) passengerName.focus();
  });
  const book = byId('ride-book');
  const binanceLink = byId('ride-binance');
  const methodsDialog = byId('ride-methods');
  byId('ride-methods-binance-link').href = binanceLink.href;
  byId('ride-methods-open').addEventListener('click', () => methodsDialog.showModal());
  const ridePayment = byId('ride-payment');
  const cashOption = ridePayment.querySelector('[value="cash"]');
  const cardOption = byId('ride-card-option');
  const cardInput = cardOption.querySelector('input');
  const payCard = byId('ride-pay-card');
  const passengerForm = byId('passenger-profile');
  const passengerName = byId('passenger-name');
  const passengerPayment = byId('passenger-payment');
  const passengerSave = byId('passenger-save');
  const passengerStatus = byId('passenger-status');
  let profileRegistered = false;
  let preferredPayment = 'cash';
  let ridePaymentChosen = false;
  ridePayment.addEventListener('change', () => { ridePaymentChosen = true; });
  zonePicker.addEventListener('change', () => {
    ridePaymentChosen = false;
    renderQuote();
  });
  const note = byId('ride-quote-note');
  const nearbyDrivers = byId('nearby-drivers');
  const rideSection = byId('mi-carrera');
  const driverDelivery = byId('driver-delivery');
  const availability = byId('driver-availability');
  const trackingPanel = byId('tracking-panel');
  const activeStates = ['searching', 'offered', 'accepted', 'arrived', 'in_progress'];
  let config;
  let state;
  let quote;
  let quoteKey;
  let quoteTimer;
  let quoteRequest;
  let quoteError;
  let quoteLoading = false;
  let submitting = false;
  let openingCard = false;
  let statusBusy = false;
  let commandVersion = 0;
  let commandBusy = false;
  let sharing = false;
  let gpsBusy = false;
  let gpsTimer;
  let driverError;
  let statusError;
  let trackingMap;
  let pickupMarker;
  let driverMarker;
  let pathLine;
  let trackingRide;
  let trackingPath;
  let lastRouteAt = 0;
  let trackingRequest = false;
  let lastFit;

  const renderPilot = location.hostname === 'ruvi-venezuela-piloto.onrender.com';
  const renderPassenger = renderPilot || ['venezuela.ruviconecta.com', 'ruvi-prueba-venezuela.onrender.com'].includes(location.hostname);
  async function api(endpoint, body) {
    const headers = new Headers();
    if (body !== undefined) headers.set('Content-Type', 'application/json');
    if (renderPassenger) {
      const token = await window.ruviPassengerIdToken?.();
      if (token) headers.set('Authorization', 'Bearer ' + token);
    }
    const base = renderPilot ? '/api/ruvi/render-passenger/' : renderPassenger ? 'https://ruviconecta.com/api/ruvi/render-passenger/' : '/api/ruvi/';
    const response = await fetch(base + endpoint, {
      method: body === undefined ? 'GET' : 'POST', headers,
      body: body === undefined ? undefined : JSON.stringify(body),
      cache: 'no-store', signal: AbortSignal.timeout(17000),
    });
    const result = await response.json();
    if (!response.ok) throw new Error(result.error);
    return result;
  }

  function passengerNotice(message = '') {
    passengerStatus.textContent = message;
    passengerStatus.hidden = !message;
  }

  function applyPassengerProfile(profile) {
    profileRegistered = Boolean(profile);
    passengerName.value = profile?.name ?? '';
    preferredPayment = passengerPayment.value = profile?.payment ?? 'cash';
    renderQuote();
    renderStatus();
  }

  passengerForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (passengerSave.disabled) return;
    passengerSave.disabled = true;
    passengerNotice();
    try {
      const { profile } = await api('passenger', { name: passengerName.value, payment: passengerPayment.value });
      applyPassengerProfile(profile);
      passengerNotice(text('Perfil guardado.', 'Profile saved.'));
    } catch (error) {
      passengerNotice(message(error.message));
    } finally {
      passengerSave.disabled = false;
    }
  });

  function message(error) {
    const messages = {
      signin: text('Inicia sesión para continuar.', 'Sign in to continue.'),
      profile: text('Completa tu perfil de pasajero para pedir o pagar.', 'Complete your passenger profile to book or pay.'),
      route: text('No encontramos una ruta por carretera. Revisa los puntos o reintenta.', 'We could not find a road route. Check your points or try again.'),
      area: text('Tu ubicación está fuera de tu zona de trabajo.', 'Your location is outside your service area.'),
      gps: text('Activa el permiso de ubicación y vuelve a intentarlo.', 'Allow location access and try again.'),
      expired: text('El precio venció. Actualiza la cotización.', 'Your price expired. Refresh the quote.'),
      wait: text('Espera unos segundos y reintenta.', 'Wait a few seconds and try again.'),
      active: text('Ya tienes una carrera activa.', 'You already have an active ride.'),
      changed: text('El estado de la carrera cambió. Revisa la información actualizada.', 'The ride status changed. Check the latest details.'),
      offline: text('Ponte disponible y actualiza tu ubicación.', 'Go online and refresh your location.'),
      approval: text('Tu perfil todavía necesita aprobación de RUVI.', 'RUVI still needs to approve your profile.'),
      invalid: text('Revisa los datos ingresados.', 'Check the information you entered.'),
      card_unavailable: text('El pago con tarjeta no está disponible en esta zona.', 'Card payment is unavailable in this area.'),
    };
    return messages[error] || text('El servicio no está disponible en este momento. Reintenta.', 'The service is currently unavailable. Try again.');
  }

  function renderQuote() {
    const ride = isRide();
    const enabled = config?.zones?.[zoneKey()]?.includes(selected);
    const alreadyBooked = activeStates.includes(state?.ride?.state);
    byId('ride-checkout').hidden = !ride;
    binanceLink.hidden = !ride || !profileRegistered || zoneKey() !== 've';
    const delivery = selected === 'delivery';
    const legacy = byId('legacy-submit');
    const useLegacyQuote = !ride && selected !== 'vuelo';
    legacy.hidden = legacy.disabled = !useLegacyQuote;
    customer.hidden = !useLegacyQuote;
    for (const input of customer.querySelectorAll('input')) input.disabled = customer.hidden;
    if (!ride) {
      paymentOptions.disabled = paymentOptions.hidden = !useLegacyQuote;
      return;
    }
    paymentOptions.hidden = paymentOptions.disabled = true;
    rateHint.textContent = enabled
      ? text('El total se calcula con la ruta seleccionada.', 'Your total is calculated for the selected route.')
      : text('Las tarifas visibles son estimaciones donde estén disponibles.', 'Displayed fares are estimates where available.');
    retryRoute.hidden = !(routeFailed || (enabled && config.signedIn && quoteError && quoteKey));
    const estimateValue = estimateFare(selected, route).value;
    const visibleEstimate = estimateValue === translate('Por WhatsApp') ? '—' : estimateValue;
    price.value = quote ? money(quote) : visibleEstimate;
    const accountMarket = ['pc', 've'].includes(zoneKey());
    register.hidden = !enabled || !accountMarket || profileRegistered;
    register.textContent = config?.signedIn
      ? text('Completar perfil de pasajero', 'Complete passenger profile')
      : text('Registrarme o iniciar sesión', 'Register or sign in');
    book.textContent = delivery ? text('Solicitar envío', 'Request delivery') : text('Pedir carrera', 'Request ride');
    book.hidden = !enabled || !profileRegistered;
    book.disabled = book.hidden || !quote || submitting || alreadyBooked;
    const cardEnabled = config?.cardZones?.includes(zoneKey()) ?? false;
    ridePayment.hidden = ridePayment.disabled = book.hidden;
    cardOption.hidden = cardInput.disabled = !cardEnabled;
    if (!cardEnabled) cashOption.checked = true;
    else if (!ridePaymentChosen) {
      const preferred = preferredPayment === 'card' ? cardInput : cashOption;
      preferred.checked = true;
    }
    byId('ride-methods-price').textContent = price.value;
    byId('ride-methods-cash').textContent = enabled
      ? text('Al finalizar el servicio', 'At the end of the service')
      : text('Según disponibilidad de la reserva', 'Subject to booking availability');
    byId('ride-methods-card').textContent = enabled && cardEnabled
      ? text('Disponible al pagar', 'Available at checkout')
      : text('Aún no habilitada para este servicio', 'Not yet enabled for this service');
    byId('ride-methods-ve').hidden = zoneKey() !== 've';
    byId('ride-methods-binance').hidden = binanceLink.hidden;
    if (!enabled) {
      note.textContent = config
        ? delivery
          ? zone.country === 'VE'
            ? text('Puedes cotizar el envío. Los pedidos aún no están habilitados en esta zona.', 'You can estimate the delivery fare. Booking is not yet available in this area.')
            : text('Delivery aún no está habilitado en esta zona.', 'Delivery is not available in this area yet.')
          : text('Las reservas automáticas todavía no están habilitadas para esta zona y vehículo.', 'Automatic booking is not enabled yet for this area and vehicle.')
        : text('Comprobando disponibilidad de carreras…', 'Checking ride availability…');
      if (config === false) note.textContent = zone.country === 'VE'
        ? text('Cotización estimada. Las cuentas y los pedidos se gestionan en la app oficial.',
          'Estimated fare. Manage accounts and bookings in the official app.')
        : message('unavailable');
      routeStatus.textContent = translate(routeMessage || (visibleEstimate === '—'
        ? 'Tarifa por confirmar con RUVI.'
        : 'Precio estimado de la carrera según la ruta.'));
      return;
    }
    if (quote) {
      routeDistance.textContent = numberFormats[language].distance.format(quote.distance / 1000) + ' km';
      routeTime.textContent = formatRouteTime(quote.duration);
    }
    nearbyDrivers.hidden = typeof quote?.nearbyDrivers !== 'boolean';
    nearbyDrivers.textContent = nearbyDrivers.hidden ? '' : quote.nearbyDrivers
      ? text('Hay conductores disponibles cerca de tu punto de recogida.', 'Drivers are available near your pickup point.')
      : text('Por ahora no hay conductores disponibles cerca de tu punto de recogida.', 'No drivers are currently available near your pickup point.');
    routeStatus.textContent = quote
      ? delivery ? text('Total del envío. Válido por cinco minutos.', 'Delivery total. Valid for five minutes.')
        : text('Total de la carrera. Válido por cinco minutos.', 'Ride total. Valid for five minutes.')
      : quoteLoading ? text('Calculando precio…', 'Calculating price…')
        : translate(routeMessage || (visibleEstimate === '—' ? routePrompt : 'Precio estimado de la carrera según la ruta.'));
    note.textContent = quoteError ? message(quoteError)
      : alreadyBooked ? message('active')
      : !profileRegistered ? message('profile')
      : delivery
        ? cardInput.checked ? text('Paga con tarjeta durante el envío desde Mi envío.', 'Pay by card during delivery from My delivery.')
          : text('Pago en efectivo al finalizar el envío.', 'Pay in cash when delivery ends.')
      : cardInput.checked
        ? text('Paga con tarjeta durante la carrera desde Mis viajes.', 'Pay by card during the ride from My ride.')
        : text('Pago en efectivo al finalizar la carrera.', 'Pay in cash when the ride ends.');
  }

  function syncQuote(force = false) {
    const from = locations.get('origin').coordinates;
    const to = locations.get('destination').coordinates;
    const eligible = isRide() && config?.signedIn && config.zones[zoneKey()]?.includes(selected) && from && to;
    const data = eligible ? {
      zone: zoneKey(), vehicle: selected, from, to, pickup: origin.value.trim(), dropoff: destination.value.trim(),
    } : null;
    const key = data ? JSON.stringify(data) : undefined;
    if (force || key !== quoteKey) {
      clearTimeout(quoteTimer);
      quoteKey = key;
      quote = quoteError = undefined;
      quoteRequest = Symbol();
      quoteLoading = Boolean(data);
      if (data) {
        const request = quoteRequest;
        quoteTimer = setTimeout(async () => {
          try {
            const result = await api('quote', data);
            if (request !== quoteRequest) return;
            quote = result;
            quoteTimer = setTimeout(() => {
              quote = undefined;
              quoteError = 'expired';
              renderQuote();
            }, Math.max(0, result.expires - Date.now()));
          } catch (error) {
            if (request === quoteRequest) quoteError = error.message;
          } finally {
            if (request === quoteRequest) {
              quoteLoading = false;
              renderQuote();
            }
          }
        }, 350);
      }
    }
    renderQuote();
  }

  window.updateRideQuote = syncQuote;
  window.isRideService = isRide;
  retryRoute.addEventListener('click', () => {
    if (isRide() && config?.signedIn && config.zones[zoneKey()]?.includes(selected)) syncQuote(true);
  });

  function acceptState(result) {
    state = result;
    statusError = undefined;
    renderStatus();
    renderQuote();
  }

  async function poll() {
    if (!config?.signedIn || document.hidden || statusBusy || commandBusy) return;
    statusBusy = true;
    const version = commandVersion;
    try {
      const result = await api('status', {});
      if (!commandBusy && version === commandVersion) acceptState(result);
    } catch (error) {
      if (!commandBusy && version === commandVersion) {
        statusError = error.message;
        renderStatus();
      }
    } finally {
      statusBusy = false;
    }
  }

  async function command(endpoint, body) {
    if (commandBusy) throw new Error('wait');
    commandBusy = true;
    commandVersion++;
    try {
      acceptState(await api(endpoint, body));
    } finally {
      commandBusy = false;
    }
  }

  ridePayment.addEventListener('change', renderQuote);
  payCard.addEventListener('click', async () => {
    const ride = state?.ride;
    if (!ride || !profileRegistered || openingCard) return;
    openingCard = true;
    renderStatus();
    try {
      const result = await api('ride-checkout', { id: ride.id });
      if (result.checkoutUrl?.startsWith('https://checkout.stripe.com/')) {
        window.location.assign(result.checkoutUrl);
        return;
      }
      if (result.paid) await poll();
    } catch (error) {
      statusError = error.message;
    } finally {
      openingCard = false;
      renderStatus();
    }
  });

  form.addEventListener('submit', async (event) => {
    if (!isRide() || !quote || book.disabled) return;
    event.preventDefault();
    submitting = true;
    renderQuote();
    try {
      await command('book', {
        id: quote.id, payment: cardInput.checked ? 'card' : 'cash',
        deliveryNote: selected === 'delivery' ? byId('detail-0')?.value.trim() : undefined,
      });
      rideSection.scrollIntoView({ block: 'start' });
    } catch (error) {
      quoteError = error.message;
    } finally {
      submitting = false;
      renderQuote();
    }
  });

  byId('ride-cancel').addEventListener('click', async () => {
    const ride = state?.ride;
    if (!ride) return;
    const prompt = ride.vehicle === 'delivery' ? text('¿Cancelar este envío?', 'Cancel this delivery?')
      : text('¿Cancelar esta carrera?', 'Cancel this ride?');
    if (!window.confirm(prompt)) return;
    try { await command('cancel', { id: ride.id }); }
    catch (error) { statusError = error.message; renderStatus(); }
  });

  function getPosition() {
    return new Promise((resolve, reject) => {
      if (!navigator.geolocation) { reject(new Error('gps')); return; }
      navigator.geolocation.getCurrentPosition(
        ({ coords }) => resolve([coords.latitude, coords.longitude]),
        () => reject(new Error('gps')),
        { enableHighAccuracy: true, maximumAge: 8000, timeout: 9000 },
      );
    });
  }

  async function sendPosition() {
    if (!sharing || document.hidden || gpsBusy) return;
    gpsBusy = true;
    const tick = async () => {
      const position = await getPosition();
      if (!sharing || document.hidden || commandBusy) return;
      driverError = undefined;
      await command('driver/location', { position });
    };
    try { await tick(); }
    catch (error) {
      driverError = error.message;
      if (['gps', 'area', 'approval', 'unavailable'].includes(driverError)) {
        sharing = false;
        clearInterval(gpsTimer);
        try { await command('driver/offline', {}); } catch {}
      }
    } finally {
      gpsBusy = false;
      renderStatus();
    }
  }

  availability.addEventListener('click', async () => {
    if (commandBusy) return;
    driverError = undefined;
    if (sharing || state?.driver?.online) {
      sharing = false;
      clearInterval(gpsTimer);
      try { await command('driver/offline', {}); } catch (error) { driverError = error.message; }
    } else {
      sharing = true;
      gpsTimer = setInterval(sendPosition, 12000);
      await sendPosition();
    }
    renderStatus();
  });

  driverDelivery.addEventListener('change', async () => {
    try {
      driverError = undefined;
      await command('driver/delivery', { enabled: driverDelivery.checked });
    } catch (error) {
      driverError = error.message;
      renderStatus();
    }
  });

  function renderDriver() {
    const driver = state?.driver;
    const job = state?.job;
    byId('conductores').hidden = !driver?.approved;
    byId('driver-dashboard-link').hidden = !driver?.approved;
    const servicesInZone = config?.zones?.[driver?.zone] ?? [];
    const deliveryEnabled = servicesInZone.includes('delivery');
    byId('driver-delivery-option').hidden = !driver?.approved || !deliveryEnabled;
    driverDelivery.checked = Boolean(driver?.acceptsDelivery);
    driverDelivery.disabled = job?.vehicle === 'delivery';
    const enabled = servicesInZone.includes(driver?.vehicle) || (driver?.acceptsDelivery && deliveryEnabled);
    availability.hidden = !driver?.approved || !enabled;
    availability.disabled = gpsBusy && sharing;
    availability.textContent = sharing || driver?.online
      ? text('Dejar de estar disponible', 'Go offline')
      : text('Ponerme disponible', 'Go online');
    byId('driver-state').textContent = driverError ? message(driverError)
      : statusError ? message(statusError)
      : driver?.approved && !enabled ? text(
        'Perfil aprobado. Tu zona o vehículo todavía no recibe carreras automáticas.',
        'Profile approved. Automatic rides are not enabled for your area or vehicle yet.',
      )
      : driver?.approved ? driver.online
        ? text('Disponible. Mantén RUVI abierto para compartir tu ubicación y recibir solicitudes.', 'Online. Keep RUVI open to share your location and receive requests.')
        : sharing ? text('Actualizando ubicación…', 'Updating location…')
        : text('Estás fuera de línea.', 'You are offline.')
      : '';
    byId('driver-job').hidden = !job;
    if (!job) return;
    const delivery = job.vehicle === 'delivery';
    const actions = {
      offered: [['accept', text('Aceptar', 'Accept')], ['decline', text('Rechazar', 'Decline')]],
      accepted: [['arrived', text('Llegué a la recogida', 'I arrived at pickup')]],
      arrived: [['start', delivery ? text('Iniciar envío', 'Start delivery') : text('Iniciar carrera', 'Start ride')]],
      in_progress: job.paymentMethod === 'card'
        ? job.cardPaid ? [['complete', delivery ? text('Finalizar envío', 'Finish delivery') : text('Finalizar carrera', 'Finish ride')]] : []
        : [['paid', text('Finalizar y confirmar efectivo recibido', 'Finish and confirm cash received')]],
    };
    byId('job-state').textContent = job.state === 'offered'
      ? delivery ? text('Nuevo envío cercano', 'New delivery nearby') : text('Nueva carrera cercana', 'New ride nearby')
      : delivery ? text('Envío asignado', 'Assigned delivery') : text('Carrera asignada', 'Assigned ride');
    byId('job-detail').textContent = money(job) + ' · ' + numberFormats[language].distance.format(job.distance / 1000) + ' km'
      + (job.pickup ? '\n' + job.pickup + ' → ' + job.dropoff : '')
      + (job.deliveryNote ? '\n' + job.deliveryNote : '')
      + (job.paymentMethod === 'card' ? '\n' + cardStatus(job) : '');
    const navigation = byId('driver-navigation');
    const drivingToDropoff = job.state === 'in_progress';
    navigation.hidden = !job.from;
    if (job.from) {
      navigation.href = mapsUrl('dir', {
        destination: (drivingToDropoff ? job.to : job.from).join(','), travelmode: 'driving',
      });
      navigation.textContent = drivingToDropoff
        ? text('Abrir ruta al destino ↗', 'Open route to destination ↗')
        : text('Abrir ruta a la recogida ↗', 'Open route to pickup ↗');
    }
    const controls = byId('job-actions');
    const controlsKey = [job.id, job.state, job.cardPaid, language].join(':');
    if (controls.dataset.key === controlsKey) return;
    controls.dataset.key = controlsKey;
    controls.replaceChildren(...(actions[job.state] ?? []).map(([action, label]) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = 'ride-secondary';
      button.textContent = label;
      button.addEventListener('click', async () => {
        if (action === 'paid' && !window.confirm(text('¿Recibiste el pago completo en efectivo?', 'Did you receive the full cash payment?'))) return;
        driverError = undefined;
        try { await command('driver/action', { id: job.id, action }); }
        catch (error) { driverError = error.message; renderStatus(); }
      });
      return button;
    }));
  }

  function renderTracking(ride) {
    const accepted = ride?.state === 'accepted';
    trackingPanel.hidden = !accepted;
    if (!accepted) {
      trackingRide = trackingPath = lastFit = undefined;
      return;
    }
    const trackingNote = byId('tracking-note');
    if (trackingRide !== ride.id) {
      trackingRide = ride.id;
      trackingPath = lastFit = undefined;
      lastRouteAt = 0;
    }
    const position = ride.driver?.position;
    if (!position) trackingPath = undefined;
    trackingNote.textContent = !position
      ? text('Esperando una ubicación reciente del conductor.', 'Waiting for a recent driver location.')
      : trackingPath
        ? text('Llegada estimada: ', 'Estimated pickup: ') + Math.max(1, Math.ceil(trackingPath.duration / 60)) + ' min'
        : text('Ubicación del conductor actualizada. Calculando la ruta de recogida…', 'Driver location updated. Calculating pickup route…');
    if (!window.L) return;
    if (!trackingMap) {
      trackingMap = L.map('tracking-map', { scrollWheelZoom: false }).setView(ride.from, 14);
      L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      }).addTo(trackingMap);
      pickupMarker = L.circleMarker(ride.from, { radius: 9, color: '#29231b', fillColor: '#ffcf67', fillOpacity: 1 }).addTo(trackingMap);
      driverMarker = L.circleMarker(ride.from, { radius: 8, color: '#fff', fillColor: '#246fc8', fillOpacity: 1 });
      pathLine = L.polyline([], { color: '#246fc8', weight: 5 }).addTo(trackingMap);
    }
    trackingMap.invalidateSize();
    pickupMarker.setLatLng(ride.from).unbindTooltip().bindTooltip(text('Recogida', 'Pickup'));
    if (position) driverMarker.setLatLng(position).addTo(trackingMap).unbindTooltip().bindTooltip(text('Conductor', 'Driver'));
    else driverMarker.remove();
    pathLine.setLatLngs(trackingPath?.points ?? []);
    const fit = ride.id + ':' + (trackingPath ? 'route' : position ? 'both' : 'pickup');
    if (lastFit !== fit) {
      const points = trackingPath?.points?.length ? trackingPath.points : [ride.from, ...(position ? [position] : [])];
      trackingMap.fitBounds(points, { padding: [30, 30], maxZoom: 16 });
      lastFit = fit;
    }
    if (position && !trackingRequest && Date.now() - lastRouteAt >= 25000 && !document.hidden) {
      trackingRequest = true;
      lastRouteAt = Date.now();
      api('pickup-route', { id: ride.id }).then((result) => {
        if (trackingRide === ride.id && state?.ride?.driver?.position) trackingPath = result;
      }).catch(() => {
        if (trackingRide === ride.id) trackingNote.textContent = text(
          'La ubicación está disponible. No se pudo actualizar la ruta por carretera.',
          'Location is available. The road route could not be refreshed.',
        );
      }).finally(() => {
        trackingRequest = false;
        if (trackingPath) renderTracking(state?.ride);
      });
    }
  }

  function cardStatus(ride) {
    return ride.cardPaid
      ? text('Pago con tarjeta confirmado', 'Card payment confirmed')
      : text('Tarjeta · Pago pendiente', 'Card · Payment pending');
  }

  function renderStatus() {
    const ride = state?.ride;
    rideSection.hidden = !ride;
    payCard.hidden = !profileRegistered || ride?.state !== 'in_progress' || ride.paymentMethod !== 'card' || ride.cardPaid;
    payCard.disabled = openingCard;
    if (ride) {
      const delivery = ride.vehicle === 'delivery';
      byId('my-ride-title').textContent = delivery ? text('Mi envío', 'My delivery') : text('Mi carrera', 'My ride');
      byId('ride-cancel').textContent = delivery ? text('Cancelar envío', 'Cancel delivery') : text('Cancelar carrera', 'Cancel ride');
      const labels = delivery ? {
        searching: text('Buscando repartidor cercano…', 'Finding a nearby courier…'),
        offered: text('Esperando que un repartidor acepte…', 'Waiting for a courier to accept…'),
        accepted: text('El repartidor va al punto de recogida', 'The courier is on the way to pickup'),
        arrived: text('El repartidor llegó al punto de recogida', 'The courier arrived at pickup'),
        in_progress: text('Envío en camino', 'Delivery on the way'),
        completed: text('Envío entregado', 'Delivery completed'),
        unavailable: text('No encontramos un repartidor disponible. Puedes volver a solicitar el envío.', 'No courier was available. You can request the delivery again.'),
        cancelled: text('Envío cancelado', 'Delivery cancelled'),
      } : {
        searching: text('Buscando conductor cercano…', 'Finding a nearby driver…'),
        offered: text('Esperando que un conductor acepte…', 'Waiting for a driver to accept…'),
        accepted: text('Tu conductor va a recogerte', 'Your driver is on the way'),
        arrived: text('Tu conductor llegó', 'Your driver has arrived'),
        in_progress: text('Carrera en curso', 'Ride in progress'),
        completed: text('Carrera finalizada', 'Ride completed'),
        unavailable: text('No encontramos un conductor disponible. Puedes solicitar otra carrera.', 'We could not find an available driver. You can request another ride.'),
        cancelled: text('Carrera cancelada', 'Ride cancelled'),
      };
      byId('ride-state').textContent = statusError ? message(statusError) : labels[ride.state];
      byId('ride-detail').textContent = ride.pickup + ' → ' + ride.dropoff + '\n'
        + money(ride) + ' · ' + (ride.paymentMethod === 'card' ? cardStatus(ride)
          : ride.cashPaid ? text('Efectivo recibido', 'Cash received') : text('Efectivo', 'Cash'))
        + (ride.driver?.name ? '\n' + ride.driver.name : '');
      byId('ride-cancel').hidden = !['searching', 'offered', 'accepted', 'arrived'].includes(ride.state);
    }
    renderDriver();
    renderTracking(statusError ? undefined : ride);
  }

  window.renderRideStatus = renderStatus;
  let configRequest = 0;
  function loadRideConfig() {
    const request = ++configRequest;
    api('config').then((result) => {
      if (request !== configRequest) return;
      config = result;
      byId('account-signin').hidden = result.signedIn;
      publicRideRates = result.estimates ?? {};
      window.setFlightAvailability?.(result.flightSearch);
      if (!setDetectedLocation(result.country, result.city)) updateEstimate();
      renderStatus();
      poll();
      if (config.signedIn) {
        passengerNotice(text('Cargando perfil…', 'Loading profile…'));
        api('passenger').then(({ profile }) => {
          if (request !== configRequest) return;
          applyPassengerProfile(profile);
          passengerForm.hidden = false;
          passengerNotice();
        }).catch((error) => {
          if (request === configRequest) passengerNotice(message(error.message));
        });
      } else if (renderPassenger) {
        applyPassengerProfile(null);
        passengerForm.hidden = true;
      }
    }).catch(() => {
      if (request !== configRequest) return;
      config = false;
      window.setFlightAvailability?.(false);
      renderQuote();
      byId('driver-state').textContent = message('unavailable');
    });
    syncQuote();
  }
  setInterval(poll, 6000);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) { poll(); sendPosition(); }
  });
  if (renderPassenger) window.addEventListener('ruvi-passenger-auth', loadRideConfig);
  loadRideConfig();
})();
