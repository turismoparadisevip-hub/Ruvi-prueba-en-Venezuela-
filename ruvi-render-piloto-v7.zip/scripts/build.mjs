import { mkdir, readFile, readdir, writeFile } from 'node:fs/promises';

const mimeTypes = {
  html: 'text/html; charset=utf-8',
  js: 'application/javascript; charset=utf-8',
  css: 'text/css; charset=utf-8',
  webmanifest: 'application/manifest+json',
  png: 'image/png',
  webp: 'image/webp',
};
async function assetNames(directory = '') {
  const entries = await readdir('public/' + directory, { withFileTypes: true });
  return (await Promise.all(entries.map(entry => {
    const name = directory + entry.name;
    return entry.isDirectory() ? assetNames(name + '/') : name;
  }))).flat();
}

const assets = Object.fromEntries(await Promise.all((await assetNames()).map(async (name) => {
  const body = await readFile('public/' + name);
  const type = mimeTypes[name.split('.').at(-1)];
  if (!type) throw new Error('Unsupported asset: ' + name);
  return ['/' + name, { type, body: body.toString('base64') }];
})));
const worker = (await Promise.all(['index', 'venues', 'flights', 'assistant', 'render-driver', 'merchant', 'commerce', 'solutions', 'group-rides', 'real-estate'].map((file) => readFile('worker/' + file + '.mjs', 'utf8')))).join('\n');
await mkdir('dist/server', { recursive: true });
await writeFile('dist/server/index.js', 'const assets = ' + JSON.stringify(assets) + ';\n' + worker);
