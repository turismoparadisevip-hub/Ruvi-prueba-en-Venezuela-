const params = new URLSearchParams(location.search);
const driver = document.body.classList.contains('driver-welcome');
const region = params.get('region') || params.get('delivery') || 've';
const countries = {
  pc: { code: 'DO', flag: '🇩🇴', title: 'Muévete en República Dominicana', english: 'Get around the Dominican Republic' },
  ve: { code: 'VE', flag: '🇻🇪', title: 'Bienvenidos a RUVI', english: 'Welcome to RUVI' },
};
const otherDriverRegions = {
  us: { code: 'US', flag: '🇺🇸', name: 'Estados Unidos' },
  eu: { flag: '🇪🇺', name: 'Europa' },
};
const country = Object.hasOwn(countries, region) ? countries[region] : null;
const driverRegion = driver && Object.hasOwn(otherDriverRegions, region) ? otherDriverRegions[region] : null;

if (driverRegion) {
  const label = document.querySelector('.regional-flag');
  label.textContent = driverRegion.flag + ' ' + driverRegion.name;
  label.hidden = false;
  const note = document.querySelector('.driver-region-note');
  note.textContent = region === 'eu'
    ? 'Selecciona tu país europeo y tu ciudad al completar el registro.'
    : 'Indica tu ciudad y registra tu carro o moto.';
  note.hidden = false;
}

if (country) {
  document.body.dataset.welcomeCountry = country.code;
  const photo = document.querySelector('.regional-photo');
  photo.src = '/welcome/' + (driver ? 'driver' : 'passenger') + '-' + country.code.toLowerCase() + '.webp';
  photo.hidden = false;
  const flag = document.querySelector('.regional-flag');
  flag.textContent = country.flag + (region === 've' || driver ? (region === 've' ? ' Venezuela' : ' República Dominicana') : '');
  flag.hidden = false;
  if (!driver) {
    const heading = document.querySelector('#passenger-access-title');
    heading.textContent = country.title;
    heading.dataset.en = country.english;
  }
}

const driverCountryCode = driver && (country?.code || driverRegion?.code);
if (driverCountryCode) {
  for (const link of document.querySelectorAll('[data-account]')) {
    const url = new URL(link.href);
    url.searchParams.set('pais', driverCountryCode);
    link.href = url.href;
  }
}
