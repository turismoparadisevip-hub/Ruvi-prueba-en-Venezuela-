(() => {
  const root = document.getElementById('inmobiliaria');
  const search = document.getElementById('estate-search');
  const profile = document.getElementById('estate-profile');
  const listing = document.getElementById('estate-listing');
  const notice = document.getElementById('estate-status');
  const manager = document.getElementById('estate-manager');
  const fields = ['title', 'city', 'type', 'operation', 'price', 'location', 'photo'];
  const money = new Intl.NumberFormat('es-VE', { style: 'currency', currency: 'USD' });
  let currentKind = '';
  let requestNumber = 0;

  function node(tag, text) {
    const element = document.createElement(tag);
    if (text) element.textContent = text;
    return element;
  }
  async function api(path, body, privateRequest = false) {
    const headers = new Headers();
    if (privateRequest) {
      const token = await window.ruviPassengerIdToken?.();
      if (!token) throw new Error('Inicia sesión para gestionar tus propiedades.');
      headers.set('Authorization', 'Bearer ' + token);
    }
    if (body) headers.set('Content-Type', 'application/json');
    const response = await fetch('/api/ruvi/' + path, {
      headers, cache: 'no-store', signal: AbortSignal.timeout(15000),
      ...(body && { method: 'POST', body: JSON.stringify(body) }),
    });
    if (!response.ok) {
      if (response.status === 401) throw new Error('Inicia sesión de nuevo para continuar.');
      if (response.status === 409) throw new Error('No se pudo guardar. Revisa el tipo de cuenta o el límite de publicaciones.');
      throw new Error('No pudimos completar la operación. Revisa los datos y vuelve a intentar.');
    }
    return response.json();
  }
  const manage = body => api('render-passenger/estate-manage', body, true);
  async function run(button, work) {
    button.disabled = true;
    notice.textContent = '';
    try { await work(); }
    catch (error) { notice.textContent = error.message; }
    finally { button.disabled = false; }
  }
  function card(item) {
    const article = node('article');
    article.className = 'card estate-card';
    article.append(node('h3', item.title), node('p', item.city + ' · ' + item.property_type + ' · ' + item.operation),
      node('strong', money.format(item.price / 100)), node('p', item.location));
    if (item.photo) {
      const photo = node('img');
      photo.src = item.photo;
      photo.alt = item.title;
      photo.loading = 'lazy';
      photo.referrerPolicy = 'no-referrer';
      article.prepend(photo);
    }
    if (item.name) article.append(node('p', (item.kind === 'agency' ? 'Inmobiliaria: ' : 'Propietario: ') + item.name));
    if (item.catalog) {
      const link = node('a', 'Ver catálogo de la inmobiliaria ↗');
      link.href = item.catalog;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      article.append(link);
    }
    return article;
  }
  async function find() {
    const id = ++requestNumber;
    const params = new URLSearchParams(new FormData(search));
    const result = await api('estate-search?' + params);
    if (id !== requestNumber) return;
    const results = document.getElementById('estate-results');
    results.replaceChildren(...result.listings.map(card));
    if (!result.listings.length) results.append(node('p', 'No hay propiedades que coincidan con esta búsqueda.'));
  }
  function selectKind(kind) {
    profile.elements.kind.value = kind;
    const agency = kind === 'agency';
    document.getElementById('estate-agency-fields').hidden = !agency;
    profile.elements.registration.required = agency;
    profile.elements.catalog.required = agency;
    document.getElementById('estate-manager-title').textContent = agency ? 'Panel de inmobiliaria' : 'Panel de propietarios';
  }
  function clearListing() {
    listing.reset();
    listing.elements.id.value = '';
  }
  async function loadManager(kind) {
    const result = await manage();
    manager.hidden = false;
    currentKind = result.profile?.kind || kind;
    selectKind(currentKind);
    profile.elements.name.value = result.profile?.name || '';
    profile.elements.registration.value = result.profile?.registration || '';
    profile.elements.catalog.value = result.profile?.catalog || '';
    listing.hidden = !result.profile;
    document.getElementById('estate-mine').replaceChildren(...result.listings.map(item => {
      const article = card(item);
      const edit = node('button', 'Editar');
      edit.type = 'button';
      edit.addEventListener('click', () => {
        listing.elements.id.value = item.id;
        for (const key of fields) listing.elements[key].value = key === 'type' ? item.property_type : key === 'price' ? item.price / 100 : item[key];
        listing.elements.title.focus();
      });
      const remove = node('button', 'Retirar anuncio');
      remove.type = 'button';
      remove.addEventListener('click', () => {
        if (!window.confirm('¿Retirar esta propiedad del buscador?')) return;
        run(remove, async () => {
          await manage({ action: 'remove', id: item.id });
          if (listing.elements.id.value === item.id) clearListing();
          await Promise.all([loadManager(currentKind), find()]);
          notice.textContent = 'Anuncio retirado.';
        });
      });
      article.append(edit, remove);
      return article;
    }));
  }
  search.addEventListener('submit', event => { event.preventDefault(); run(event.submitter, find); });
  profile.addEventListener('submit', event => {
    event.preventDefault();
    run(event.submitter, async () => {
      await manage({ action: 'profile', ...Object.fromEntries(new FormData(profile)) });
      await Promise.all([loadManager(currentKind), find()]);
      notice.textContent = 'Perfil guardado.';
    });
  });
  listing.addEventListener('submit', event => {
    event.preventDefault();
    run(event.submitter, async () => {
      const data = Object.fromEntries(new FormData(listing));
      listing.elements.id.value ||= crypto.randomUUID();
      await manage({ ...data, action: 'listing', id: listing.elements.id.value, price: Math.round(Number(data.price) * 100) });
      clearListing();
      await Promise.all([loadManager(currentKind), find()]);
      notice.textContent = 'Propiedad publicada.';
    });
  });
  document.getElementById('estate-clear').addEventListener('click', clearListing);
  for (const button of document.querySelectorAll('[data-estate-kind]')) {
    button.addEventListener('click', () => {
      if (root.contains(button)) {
        run(button, () => loadManager(button.dataset.estateKind));
        return;
      }
      sessionStorage.setItem('ruvi-estate-role', button.dataset.estateKind);
      location.hash = 'inmobiliaria';
    });
  }
  async function openFromLocation() {
    if (location.hash !== '#inmobiliaria') return;
    try {
      await find();
      const role = sessionStorage.getItem('ruvi-estate-role');
      if (role && await window.ruviPassengerIdToken?.()) {
        await loadManager(role);
        sessionStorage.removeItem('ruvi-estate-role');
        root.scrollIntoView();
      }
    } catch (error) { notice.textContent = error.message; }
  }
  window.addEventListener('hashchange', openFromLocation);
  window.addEventListener('ruvi-passenger-auth', () => {
    manager.hidden = true;
    clearListing();
    openFromLocation();
  });
  openFromLocation();
})();
