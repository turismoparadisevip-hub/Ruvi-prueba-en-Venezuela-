(() => {
  const byId = (id) => document.getElementById(id);
  const searchRegion = byId('fun-region');
  const searchCity = byId('fun-city');
  const searchCategory = byId('fun-category');
  const searchStatus = byId('venue-search-status');
  const directory = byId('venue-directory');
  let directoryItems;
  let directoryMessage;
  let searchSequence = 0;

  function notice(key) {
    return ({
      empty: localize('Aún no hay fichas activas para esta búsqueda.', 'There are no active listings for this search yet.'),
      loading: localize('Buscando en el directorio…', 'Searching the directory…'),
      failed: localize('No pudimos completar la solicitud. Inténtalo de nuevo.', 'We could not complete the request. Try again.'),
    })[key] ?? '';
  }

  async function request(path) {
    const response = await fetch('/api/ruvi/venues/' + path, { cache: 'no-store' });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error);
    return data;
  }

  function selectLabel(select, value) {
    return [...select.options].find((option) => option.value === value)?.textContent ?? '';
  }

  function venueLocation(venue) {
    return [venue.address, venue.city, venue.country || selectLabel(searchRegion, venue.region)].filter(Boolean).join(', ');
  }

  function element(tag, content) {
    const node = document.createElement(tag);
    node.textContent = content;
    return node;
  }

  function renderDirectory() {
    searchStatus.textContent = notice(directoryMessage);
    directory.replaceChildren(...(directoryItems ?? []).map((venue) => {
      const card = document.createElement('article');
      card.className = 'card venue-card';
      const link = element('a', localize('Ver ubicación ↗', 'See location ↗'));
      link.href = mapsUrl('search', { query: venue.name + ', ' + venueLocation(venue) });
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      const ride = element('button', localize('Cotizar traslado aquí', 'Get a ride quote here'));
      ride.type = 'button';
      ride.className = 'ride-secondary';
      ride.addEventListener('click', () => {
        const market = venue.region === 'do' ? 'pc' : venue.region;
        goToRuviService('solicitud', 'carro', market);
        const destination = byId('destination');
        destination.value = venueLocation(venue).slice(0, destination.maxLength);
        destination.dispatchEvent(new Event('input', { bubbles: true }));
        destination.focus();
        document.querySelector('[data-search="destination"]').click();
      });
      card.append(element('strong', venue.name), element('small', selectLabel(searchCategory, venue.category)),
        element('p', venue.description), element('small', venueLocation(venue)), link, ride);
      if (venue.merchant_enrolled) {
        const menu = element('a', localize('Ver menú o catálogo ↗', 'View menu or catalog ↗'));
        menu.href = 'https://ruvi-conductor-venezuela.onrender.com/menu/' + encodeURIComponent(venue.id) + '/';
        card.append(menu);
      }
      return card;
    }));
  }

  for (const [field, event] of [[searchRegion, 'change'], [searchCity, 'input'], [searchCategory, 'change']]) {
    field.addEventListener(event, () => {
      searchSequence++;
      directoryItems = [];
      directoryMessage = undefined;
      byId('venue-results').hidden = true;
      renderDirectory();
    });
  }

  byId('fun-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const sequence = ++searchSequence;
    const query = new URLSearchParams({ region: searchRegion.value, city: searchCity.value.trim(), category: searchCategory.value });
    byId('venue-results').hidden = false;
    directoryItems = [];
    directoryMessage = 'loading';
    renderDirectory();
    try {
      const result = await request('list?' + query);
      if (sequence !== searchSequence) return;
      directoryItems = result.venues;
      directoryMessage = directoryItems.length ? undefined : 'empty';
    } catch {
      if (sequence !== searchSequence) return;
      directoryMessage = 'failed';
    }
    renderDirectory();
  });

  byId('fun-maps').addEventListener('click', () => {
    const city = searchCity.value.trim();
    const region = searchRegion.value === 'eu' ? '' : selectLabel(searchRegion, searchRegion.value);
    const category = searchCategory.value === 'properties'
      ? localize('Agencias inmobiliarias', 'Real estate agencies')
      : searchCategory.value ? selectLabel(searchCategory, searchCategory.value) : localize('Atracciones turísticas', 'Tourist attractions');
    window.location.assign(mapsUrl('search', { query: [category, city, region].filter(Boolean).join(', ') }));
  });

  const foodForm = byId('food-search-form');
  const foodRegion = byId('food-region');
  const foodCity = byId('food-city');
  const foodResults = byId('food-results');
  const foodStatus = byId('food-status');
  const foodDirectory = byId('food-directory');
  const foodMerchant = byId('food-merchant-link');
  let foodRequest = 0;
  let foodItems = [];
  let foodMessage;

  function renderFood() {
    foodMerchant.href = foodRegion.value === 've'
      ? 'https://ruvi-conductor-venezuela.onrender.com/negocios/'
      : 'https://wa.me/584122696073?text=Hola%2C%20RUVI.%20Quiero%20registrar%20mi%20restaurante%20en%20Rep%C3%BAblica%20Dominicana.';
    const messages = {
      loading: localize('Buscando restaurantes…', 'Finding restaurants…'),
      empty: localize('Aún no hay restaurantes publicados para esta búsqueda. También puedes explorar en Maps.',
        'No restaurants have been published for this search yet. You can also explore on Maps.'),
      failed: localize('El directorio no está disponible desde este enlace. Puedes explorar en Maps.',
        'The directory is unavailable from this link. You can explore on Maps.'),
    };
    foodStatus.textContent = messages[foodMessage] ?? '';
    foodDirectory.replaceChildren(...foodItems.map((venue) => {
      const card = document.createElement('article');
      card.className = 'card venue-card';
      const address = [venue.address, venue.city, selectLabel(foodRegion, venue.region)].filter(Boolean).join(', ');
      const link = element('a', localize('Ver ubicación ↗', 'See location ↗'));
      link.href = mapsUrl('search', { query: [venue.name, address].join(', ') });
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      card.append(element('strong', venue.name), element('p', venue.description), element('small', address), link);
      if (venue.merchant_enrolled) {
        const menu = element('a', localize('Ver menú y precios ↗', 'View menu and prices ↗'));
        menu.href = 'https://ruvi-conductor-venezuela.onrender.com/menu/' + encodeURIComponent(venue.id) + '/';
        card.append(menu);
      }
      return card;
    }));
  }

  function resetFood() {
    foodRequest++;
    foodItems = [];
    foodMessage = undefined;
    foodResults.hidden = true;
    renderFood();
  }

  function setFoodRegionFromQuote() {
    const market = zonePicker.querySelector(':checked').value;
    const region = { pc: 'do', ve: 've' }[market];
    if (region && foodRegion.value !== region) {
      foodRegion.value = region;
      resetFood();
    }
  }

  setFoodRegionFromQuote();
  renderFood();
  zonePicker.addEventListener('change', setFoodRegionFromQuote);
  foodRegion.addEventListener('change', resetFood);
  foodCity.addEventListener('input', resetFood);
  foodForm.addEventListener('submit', async (event) => {
    event.preventDefault();
    const sequence = ++foodRequest;
    const query = new URLSearchParams({ region: foodRegion.value, city: foodCity.value.trim(), category: 'food' });
    foodItems = [];
    foodMessage = 'loading';
    foodResults.hidden = false;
    renderFood();
    try {
      const endpoint = 'list?' + query;
      const isVenezuelaPreview = location.hostname === 'ruvi-prueba-venezuela.onrender.com';
      const result = isVenezuelaPreview
        ? await fetch('https://ruviconecta.com/api/ruvi/venues/' + endpoint, {
          credentials: 'omit', signal: AbortSignal.timeout(10000),
        }).then(response => {
          if (!response.ok) throw new Error('Directory unavailable');
          return response.json();
        })
        : await request(endpoint);
      const { venues } = result;
      if (sequence !== foodRequest) return;
      foodItems = venues;
      foodMessage = venues.length ? undefined : 'empty';
    } catch {
      if (sequence !== foodRequest) return;
      foodMessage = 'failed';
    }
    renderFood();
  });

  for (const button of foodForm.querySelectorAll('[data-food-map]')) {
    button.addEventListener('click', () => {
      const cuisines = {
        pizza: localize('Pizzerías', 'Pizza'),
        burgers: localize('Hamburguesas', 'Burgers'),
        chicken: localize('Restaurantes de pollo', 'Chicken restaurants'),
        local: localize('Restaurantes de comida local', 'Local food restaurants'),
      };
      const query = [cuisines[button.dataset.foodMap], foodCity.value.trim(), selectLabel(foodRegion, foodRegion.value)]
        .filter(Boolean).join(', ');
      window.open(mapsUrl('search', { query }), '_blank', 'noopener,noreferrer');
    });
  }

  window.renderVenues = () => {
    renderDirectory();
    renderFood();
  };
})();

(() => {
  const get = id => document.getElementById(id);
  const region = get('featured-region'), city = get('featured-city'), status = get('featured-status');
  let items = [], filter = 'all', sequence = 0;
  const el = (tag, text) => { const node = document.createElement(tag); node.textContent = text; return node; };
  function render() {
    const visible = items.filter(item => filter === 'all' || item.type === filter).slice(0, 6);
    get('featured-cards').replaceChildren(...visible.map(item => {
      const card = el('article', ''); card.className = 'featured-card';
      if (item.photo && /^data:image\/(jpeg|png|webp);base64,/.test(item.photo)) {
        const image = document.createElement('img'); image.src = item.photo; image.alt = item.name; image.loading = 'lazy'; card.append(image);
      } else { const art = el('div', ({food:'🍽️', cars:'🚘', products:'🛍️', experiences:'🎟️'})[item.type]); art.className = 'featured-art'; art.setAttribute('aria-hidden','true'); card.append(art); }
      const copy = el('div', ''); copy.className = 'featured-copy';
      copy.append(el('small', item.label),el('h3', item.name),el('p', item.description),el('small',item.city));
      if (item.amount) copy.append(el('strong',new Intl.NumberFormat(document.documentElement.lang || 'es',{style:'currency',currency:item.currency}).format(item.amount/100)));
      const action = el(item.type === 'cars' ? 'button' : 'a',item.action);
      if(item.type === 'cars') {action.type='button';action.addEventListener('click',()=>goToRuviService('solicitud','renta','pc'));}
      else action.href=item.href;
      copy.append(action);card.append(copy);return card;
    }));
    if (items.length && !visible.length) status.textContent=localize('Aún no hay publicaciones en esta categoría para tu ciudad.','No listings in this category for your city yet.');
    else if(items.length) status.textContent=localize('Publicaciones para ','Listings for ')+city.value.trim()+'.';
  }
  async function load() {
    const current=++sequence; items=[];get('featured-cards').replaceChildren();
    if(!city.value.trim()){status.textContent=localize('Elige tu ciudad para explorar las publicaciones.','Choose your city to explore listings.');return;}
    status.textContent=localize('Buscando publicaciones…','Finding listings…');
    const query=new URLSearchParams({region:region.value,city:city.value.trim()});
    const read=async path=>{const response=await fetch('/api/ruvi/'+path+'?'+query,{cache:'no-store',signal:AbortSignal.timeout(12000)});if(!response.ok)throw Error('unavailable');return response.json();};
    const results=await Promise.allSettled([read('venues/list'),['do','ve'].includes(region.value)?read('merchant/marketplace'):Promise.resolve({products:[]})]);
    if(current!==sequence)return;
    const venues=results[0].status==='fulfilled'?results[0].value.venues:[];
    const products=results[1].status==='fulfilled'?results[1].value.products:[];
    const experienceCategories=['tours','attractions','beaches','outdoors','amusement','culture','music','clubs','cinemas'];
    items=venues.filter(v=>v.category==='food'||experienceCategories.includes(v.category)).map(v=>({type:v.category==='food'?'food':'experiences',label:v.category==='food'?localize('Restaurante','Restaurant'):localize('Experiencia','Experience'),name:v.name,description:v.description,city:v.city,action:v.merchant_enrolled?localize('Ver menú o catálogo','View menu or catalogue'):localize('Ver lugar','View place'),href:v.merchant_enrolled?'https://ruvi-conductor-venezuela.onrender.com/menu/'+encodeURIComponent(v.id)+'/':mapsUrl('search',{query:[v.name,v.address,v.city,v.country].filter(Boolean).join(', ')})}));
    items.push(...products.map(p=>({type:'products',label:localize('Marketplace · ','Marketplace · ')+p.shop_name,name:p.name,description:p.description,city:p.city,photo:p.photo,amount:p.amount,currency:p.currency,action:localize('Ver producto','View product'),href:'https://ruvi-conductor-venezuela.onrender.com/menu/'+encodeURIComponent(p.venue_id)+'/'})));
    if(region.value==='do' && /^(punta cana|bavaro|cap cana)$/.test(city.value.trim().normalize('NFD').replace(/\p{Diacritic}/gu,'').toLowerCase())) items.unshift({type:'cars',label:localize('Vehículos en renta','Rental vehicles'),name:'ParadiseVIP Rent Cars',description:localize('Consulta modelos, tarifas y disponibilidad para tus fechas.','Ask about models, rates and availability for your dates.'),city:city.value.trim(),action:localize('Consultar disponibilidad','Check availability')});
    status.textContent=results.some(r=>r.status==='rejected')?localize('Algunas publicaciones no pudieron cargarse. Vuelve a pulsar Explorar para reintentar.','Some listings could not load. Select Explore to retry.'):items.length?'':localize('Aún no hay publicaciones para esta ciudad.','There are no listings for this city yet.');render();
  }
  get('featured-search').addEventListener('submit',event=>{event.preventDefault();load();});
  get('destacados').querySelectorAll('[data-featured-filter]').forEach(button=>button.addEventListener('click',()=>{filter=button.dataset.featuredFilter;get('destacados').querySelectorAll('[data-featured-filter]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));render();}));
  function syncRegion(){region.value={pc:'do',ve:'ve',us:'us',eu:'eu'}[zonePicker.querySelector(':checked').value]||'do';city.value=region.value==='ve'?venezuelaCity.name:'';load();}
  zonePicker.addEventListener('change',syncRegion);region.addEventListener('change',()=>{city.value='';load();});city.addEventListener('input',()=>{sequence++;items=[];render();status.textContent=localize('Pulsa Explorar para buscar en esta ciudad.','Select Explore to search this city.');});syncRegion();
})();
