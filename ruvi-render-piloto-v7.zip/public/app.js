const english = {
  'Clase de cabina': 'Cabin class',
  'Solo vuelos directos': 'Nonstop only',
  'Sí': 'Yes',
  'Renta de vehículos': 'Car rental',
  'Fecha de recogida': 'Pickup date',
  'Fecha de devolución': 'Return date',
  'Lugar de entrega': 'Pickup location',
  'Ej. Hotel, aeropuerto o dirección': 'E.g. Hotel, airport or address',
  'Tipo de vehículo (opcional)': 'Vehicle type (optional)',
  'Ej. Sedán o SUV': 'E.g. Sedan or SUV',
  'Moto': 'Motorcycle',
  'Delivery': 'Delivery',
  'Carro': 'Car',
  'Encomienda': 'Parcel delivery',
  'Traslado': 'Transfer',
  'Detalles de la entrega': 'Delivery details',
  'Ej. Qué necesitas enviar': 'E.g. What you need to send',
  'Detalles del paquete': 'Parcel details',
  'Contenido, peso y tamaño aproximado': 'Contents, approximate weight and size',
  'Fecha': 'Date',
  'Pasajeros': 'Passengers',
  'Ciudad': 'City',
  'Ej. Valencia': 'E.g. Valencia',
  'Ej. Maracay': 'E.g. Maracay',
  'Ej. Punta Cana': 'E.g. Punta Cana',
  'Ej. Miami': 'E.g. Miami',
  'Ej. Madrid, España': 'E.g. Madrid, Spain',
  'Punta Cana, República Dominicana': 'Punta Cana, Dominican Republic',
  'Estados Unidos': 'United States',
  'Europa': 'Europe',
  'Efectivo': 'Cash',
  'Tarjeta de crédito o débito': 'Credit or debit card',
  'Efectivo (RD$)': 'Cash (RD$)',
  'Efectivo (USD)': 'Cash (USD)',
  'Efectivo (Bs.)': 'Cash (Bs.)',
  'Tarjeta de débito': 'Debit card',
  'Pesos dominicanos': 'Dominican pesos',
  'Dólares': 'US dollars',
  'Tarjeta': 'Card',
  'Selecciona el origen y el destino para calcular la ruta.': 'Select your pickup and drop-off points to calculate the route.',
  'Ver ruta en Maps ↗': 'See route in Maps ↗',
  'Abrir en Maps ↗': 'Open in Maps ↗',
  'Por WhatsApp': 'Ask on WhatsApp',
  'Tarifa estimada según la distancia. El total se confirma al reservar.': 'Estimated fare based on distance. Confirm the total when booking.',
  'Tarifa por confirmar con RUVI.': 'Confirm this fare with RUVI.',
  'Reintentar cálculo': 'Retry estimate',
  'Calculando la distancia por carretera…': 'Calculating driving distance…',
  'Origen confirmado.': 'Pickup confirmed.',
  'Destino confirmado.': 'Drop-off confirmed.',
  'No encontramos un recorrido entre esos puntos. Prueba con otra ubicación.': 'We couldn’t find a route between those points. Try a different location.',
  'No se pudo calcular la ruta. Reintenta.': 'We could not calculate the route. Try again.',
  'Delivery en Punta Cana: RD$30 de base + RD$10 por km. Mínimo RD$50.': 'Punta Cana delivery: RD$30 base + RD$10 per km. RD$50 minimum.',
  'Estimado de envío por carretera.': 'Estimated delivery by road.',
  'Precio estimado de la carrera según la ruta.': 'Estimated ride fare for this route.',
  'Precio automático': 'Automatic price',
  'Escribe al menos tres caracteres.': 'Enter at least three characters.',
  'Buscando lugares…': 'Searching for places…',
  'No encontramos ese lugar. Prueba con el nombre de la villa o marca el punto en el mapa.': 'We couldn’t find that place. Try the neighborhood or add the city.',
  'Elige un resultado.': 'Choose a result.',
  'La búsqueda no está disponible ahora. Puedes marcar el punto en el mapa.': 'Search is currently unavailable. Please try again.',
  'Mapa interactivo de ': 'Interactive map of ',
  'Abre el mapa de {place} con el enlace de abajo.': 'Use the link below to open the map of {place}.',
  'Ej. Aeropuerto de Punta Cana': 'E.g. Punta Cana Airport',
  'Dirección o punto de partida': 'Address or pickup point',
  'Ej. Hotel en Bávaro': 'E.g. Hotel in Bávaro',
  'Dirección o punto de llegada': 'Address or drop-off point',
  'Busca un hotel, dirección o punto de referencia en República Dominicana. Agrega la ciudad.': 'Search for a hotel, address or landmark in the Dominican Republic. Include the city.',
  'Escribe el lugar y la ciudad, pulsa Buscar y elige un resultado para cada punto.': 'Enter the place and city, tap Search and choose a result for each point.',
  'Consulta el precio, la disponibilidad y las opciones de pago por WhatsApp.': 'Ask about pricing, availability and payment options on WhatsApp.',
  'Las tarifas por kilómetro se aplican a la distancia por carretera.': 'Per-kilometer rates apply to driving distance.',
  'Cotizar': 'Get a quote',
  'La ubicación no está disponible. Escribe la dirección.': 'Location is unavailable. Enter the address.',
  'Buscando tu ubicación…': 'Finding your location…',
  'Tu ubicación está fuera de la zona seleccionada. Busca una dirección o cambia de zona.': 'You’re outside the selected area. Search for an address or change the area.',
  'Ubicación actual agregada.': 'Current location added.',
  'No se pudo obtener tu ubicación. Escribe la dirección o revisa los permisos.': 'We couldn’t get your location. Enter the address or check your permissions.',
  'Hola, RUVI. Quisiera una cotización.': 'Hi RUVI, I’d like a quote.',
  'Hola, RUVI. Quiero registrarme gratis como conductor.': 'Hi RUVI, I’d like to sign up for free as a driver.',
  'Zona': 'Area',
  'Servicio': 'Service',
  'Origen': 'Pickup',
  'Destino': 'Drop-off',
  'Salida': 'Departure',
  'Llegada': 'Arrival',
  'Tipo de vuelo': 'Trip type',
  'Solo ida': 'One way',
  'Ida y vuelta': 'Round trip',
  'Fecha de ida': 'Departure date',
  'Fecha de regreso': 'Return date',
  'Equipaje o detalles': 'Baggage or extra details',
  'Nombre': 'Name',
  'Teléfono': 'Phone',
  'Método de pago': 'Payment method',
  'Distancia por carretera': 'Driving distance',
  'Precio calculado': 'Estimated price',
  'Acercar': 'Zoom in',
  'Alejar': 'Zoom out',
};

let language = 'es';
const locales = { es: 'es-VE', en: 'en-US', fr: 'fr-FR', de: 'de-DE', it: 'it-IT' };
const localize = (es, en) => language === 'es' ? es
  : language === 'en' ? en : ruviTranslations.get(en)?.[language] ?? en;
const translate = (text) => Object.hasOwn(english, text) ? localize(text, english[text]) : text;
const numberFormats = Object.fromEntries(
  Object.entries(locales).map(([lang, locale]) => [lang, {
    price: new Intl.NumberFormat(locale, { minimumFractionDigits: 2, maximumFractionDigits: 2 }),
    distance: new Intl.NumberFormat(locale, { maximumFractionDigits: 2 }),
  }]),
);

const services = {
  vuelo: { title: 'RUVI Vuelo' },
  renta: { title: 'Renta de vehículos', fields: [
    ['Fecha de recogida', 'date'], ['Fecha de devolución', 'date'],
    ['Lugar de entrega', 'text', 'Ej. Hotel, aeropuerto o dirección'],
    ['Tipo de vehículo (opcional)', 'text', 'Ej. Sedán o SUV', false],
  ] },
  mototaxi: { title: 'Moto', route: true },
  carro: { title: 'Carro', route: true },
  delivery: { title: 'Delivery', route: true, fields: [
    ['Detalles de la entrega', 'textarea', 'Ej. Qué necesitas enviar', false],
  ] },
  encomienda: { title: 'Encomienda', rate: 0.55, route: true, fields: [
    ['Detalles del paquete', 'textarea', 'Contenido, peso y tamaño aproximado'],
  ] },
  traslado: { title: 'Traslado', route: true, fields: [
    ['Fecha', 'date'], ['Pasajeros', 'number'],
  ] },
};

const venezuelaCities = {
  valencia: { name: 'Valencia', center: [10.19, -68.008], origin: 'Plaza Bolívar, Valencia', destination: 'Sambil Valencia' },
  maracay: { name: 'Maracay', center: [10.246, -67.596], origin: 'Plaza Bolívar, Maracay', destination: 'Las Delicias, Maracay' },
  caracas: { name: 'Caracas', center: [10.506, -66.9146], origin: 'Plaza Bolívar, Caracas', destination: 'Parque del Este, Caracas' },
};

const zones = {
  ve: {
    country: 'VE', label: 'Venezuela', bounds: [-73.5, 0.6, -59.7, 15.8], zoom: 13,
  },
  pc: {
    country: 'DO', label: 'República Dominicana', mapPlace: 'República Dominicana',
    center: [18.80, -70.25], bounds: [-72.02, 17.44, -68.18, 20.05], zoom: 8,
    cityExample: 'Ej. Punta Cana',
  },
  us: {
    country: 'US', label: 'Estados Unidos', mapPlace: 'Estados Unidos',
    center: [39.8, -98.6], bounds: [-180, 18.8, -66, 72], zoom: 4,
    cityExample: 'Ej. Miami',
  },
  eu: {
    label: 'Europa', mapPlace: 'Europa',
    countries: [
      'AD', 'AL', 'AT', 'AX', 'BA', 'BE', 'BG', 'BY', 'CH', 'CY', 'CZ', 'DE', 'DK', 'EE',
      'ES', 'FI', 'FO', 'FR', 'GB', 'GG', 'GI', 'GR', 'HR', 'HU', 'IE', 'IM', 'IS', 'IT',
      'JE', 'LI', 'LT', 'LU', 'LV', 'MC', 'MD', 'ME', 'MK', 'MT', 'NL', 'NO', 'PL', 'PT',
      'RO', 'RS', 'RU', 'SE', 'SI', 'SJ', 'SK', 'SM', 'TR', 'UA', 'VA', 'XK',
    ],
    center: [49.5, 11], bounds: [-32, 27, 66, 82], zoom: 4,
    cityExample: 'Ej. Madrid, España',
  },
};
const zonePicker = document.querySelector('.zone-picker');
const launchParams = new URLSearchParams(window.location.search);
const requestedZone = launchParams.get('region') || launchParams.get('delivery');
let regionChosen = Object.hasOwn(zones, requestedZone);
if (regionChosen) zonePicker.querySelector('[value="' + requestedZone + '"]').checked = true;
let zone = zones[zonePicker.querySelector(':checked').value];
let venezuelaCity = venezuelaCities.valencia;
const mapCenter = () => zone === zones.ve ? venezuelaCity.center : zone.center;
const mapLocation = () => zone === zones.ve ? venezuelaCity.name + ', Venezuela' : zone.mapPlace;
const form = document.querySelector('#form');
const fields = document.querySelector('#fields');
const flightFields = document.querySelector('#flight-fields');
const travelHub = document.querySelector('#travel-hub');
const rentalHint = document.querySelector('#rental-hint');
const flightType = document.querySelector('#flight-type');
const flightDeparture = document.querySelector('#flight-departure');
const flightReturn = document.querySelector('#flight-return');
const flightReturnField = document.querySelector('#flight-return-field');
const customer = document.querySelector('#customer');
const trips = document.querySelector('#trip-options');
const extras = document.querySelector('#extra-service');
const extraTitle = document.querySelector('#extra-title');
const back = document.querySelector('#back-to-trips');
const cards = document.querySelectorAll('[data-service]');
const routeFields = document.querySelector('#route-fields');
const mapPanel = document.querySelector('#map-panel');
const mapRoute = document.querySelector('#map-route');
const formRoute = document.querySelector('#form-route');
const origin = document.querySelector('#origin');
const destination = document.querySelector('#destination');
const estimate = document.querySelector('#estimate');
const price = document.querySelector('#price');
const routeDistance = document.querySelector('#route-distance');
const routeTime = document.querySelector('#route-time');
const routeStatus = document.querySelector('#route-status');
const retryRoute = document.querySelector('#retry-route');
const searchHint = document.querySelector('#search-hint');
const rateHint = document.querySelector('#rate-hint');
const paymentOptions = document.querySelector('#payment-options');
const paymentChoices = [...paymentOptions.querySelectorAll('.choice')].map((choice) => ({
  choice,
  input: choice.querySelector('input'),
  label: choice.querySelector('span'),
}));
const paymentsByCountry = {
  VE: ['Pago Móvil', 'Efectivo (USD)', 'Efectivo (Bs.)', 'Tarjeta de crédito o débito', 'Binance Pay'],
  DO: ['Efectivo (RD$)', 'Efectivo (USD)', 'Tarjeta de crédito o débito'],
  US: ['Efectivo', 'Tarjeta de crédito o débito'],
  EU: ['Efectivo', 'Tarjeta de crédito o débito'],
};
const locations = new Map([origin, destination].map((input) => [input.id, {
  input,
  results: document.getElementById(input.id + '-results'),
  status: document.getElementById(input.id + '-status'),
  searchButton: document.querySelector('[data-search="' + input.id + '"]'),
}]));
const favoriteList = document.querySelector('#favorite-places');
const favoriteStatus = document.querySelector('#favorite-status');
const favoriteButtons = [...locations.values()].map(location => ({
  location, button: document.getElementById('favorite-' + location.input.id),
}));
const favoriteStorageKey = 'ruvi-favorite-places';
let favoritePlaces = [];
try {
  const saved = JSON.parse(localStorage.getItem(favoriteStorageKey));
  if (Array.isArray(saved)) favoritePlaces = saved.filter(place => {
    const area = zones[place?.region];
    const [lat, lng] = Array.isArray(place?.coordinates) ? place.coordinates : [];
    return Object.hasOwn(zones, place?.region) && typeof place.label === 'string'
      && Number.isFinite(lat) && Number.isFinite(lng)
      && lng >= area.bounds[0] && lat >= area.bounds[1] && lng <= area.bounds[2] && lat <= area.bounds[3];
  }).slice(0, 12);
} catch {}

const trip = () => form.querySelector('[name="trip"]:checked');
let selected = trip().value;
let route;
let routeRequest;
const routePrompt = 'Selecciona el origen y el destino para calcular la ruta.';
let routeMessage = routePrompt;
let routeFailed = false;

const mapFallback = document.querySelector('#map-fallback');
const cityMap = document.querySelector('#city-map');
const mapPlace = document.querySelector('#map-place');
const map = window.L && L.map(cityMap, { scrollWheelZoom: false }).setView(mapCenter(), zone.zoom);
const markers = map && L.layerGroup().addTo(map);
const routeLine = map && L.polyline([], { color: '#854c05', weight: 5 }).addTo(map);
function addFallbackTiles() {
  L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
  }).on('tileload', () => { mapFallback.hidden = true; }).addTo(map);
}

window.addEventListener('ruvi-passenger-auth', () => {
  if (!document.querySelector('#passenger-app').hidden) {
    requestAnimationFrame(() => map?.invalidateSize());
  }
});
if (map && L.vectorGrid) {
  map.attributionControl.setPrefix(false);
  const styles = {
    water: { fill: true, fillColor: '#c0dbe5', fillOpacity: 1, stroke: false },
    waterway: { color: '#a9cbd9', weight: 1.5 },
    landcover: { fill: true, fillColor: '#dce5cf', fillOpacity: .72, stroke: false },
    landuse: { fill: true, fillColor: '#e6e2d5', fillOpacity: .65, stroke: false },
    park: { fill: true, fillColor: '#d9e5c9', fillOpacity: .7, stroke: false },
    building: { fill: true, fillColor: '#dbd6cb', fillOpacity: .7, stroke: false },
    transportation: (road) => {
      const major = ['motorway', 'trunk', 'primary'].includes(road.class);
      return { color: major ? '#d6ae66' : '#fffdf7', weight: major ? 2.8 : 1.4, opacity: 1 };
    },
  };
  try {
    const layer = L.vectorGrid.protobuf('https://tiles.openfreemap.org/planet/latest/{z}/{x}/{y}.pbf', {
      maxNativeZoom: 14,
      rendererFactory: L.canvas.tile,
      vectorTileLayerStyles: new Proxy(styles, { get: (layers, name) => layers[name] ?? [] }),
      attribution: '<a href="https://openfreemap.org/">OpenFreeMap</a> · &copy; OpenMapTiles · <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
    });
    layer.on('tileload', () => { mapFallback.hidden = true; });
    layer.once('tileerror', () => {
      map.removeLayer(layer);
      addFallbackTiles();
    });
    layer.addTo(map);
  } catch {
    addFallbackTiles();
  }
} else if (map) {
  addFallbackTiles();
}

function mapsUrl(action, params) {
  const url = new URL(action + '/', 'https://www.google.com/maps/');
  url.search = new URLSearchParams({ api: '1', ...params });
  return url.href;
}

function updateMaps() {
  const start = locations.get('origin').coordinates?.join(',') || origin.value.trim();
  const end = locations.get('destination').coordinates?.join(',') || destination.value.trim();
  const routeReady = Boolean(start && end);
  mapRoute.href = routeReady
    ? mapsUrl('dir', { origin: start, destination: end })
    : mapsUrl('search', { query: start || end || mapLocation() });
  mapRoute.textContent = translate(routeReady ? 'Ver ruta en Maps ↗' : 'Abrir en Maps ↗');
  formRoute.hidden = !routeReady;
  formRoute.href = mapRoute.href;
  for (const { location, button } of favoriteButtons) button.disabled = !location.coordinates;
}

function clearLocation(input) {
  markers?.eachLayer((marker) => {
    if (marker.options.pointId === input.id) markers.removeLayer(marker);
  });
}

function showLocation(input, coords) {
  if (!map) return;
  clearLocation(input);
  L.circleMarker(coords, {
    pointId: input.id,
    color: '#221b13',
    fillColor: input === origin ? '#efb93f' : '#397fd0',
    fillOpacity: 1,
    weight: 2,
    radius: 8,
  }).bindTooltip(translate(input.name)).addTo(markers);
  map.fitBounds(markers.getLayers().map((marker) => marker.getLatLng()), {
    maxZoom: 15, padding: [32, 32],
  });
}

function tripRate(key) {
  return zone.country === 'VE' ? services[key].rate : undefined;
}

function formatFare(amount, currency = 'USD ') {
  return currency + numberFormats[language].price.format(amount);
}

let publicRideRates = {};
const venezuelaEstimates = {
  carro: { base: 1.25, perKm: 0.40, perMinute: 0, minimum: 2.40 },
  mototaxi: { base: 0.50, perKm: 0.24, perMinute: 0, minimum: 0.85 },
  delivery: { base: 0, perKm: 0.45, perMinute: 0, minimum: 0 },
};

function estimateFare(service, roadRoute) {
  const km = roadRoute ? roadRoute.distance / 1000 : undefined;
  const rate = tripRate(service);
  if (rate) {
    const value = km === undefined ? '—' : formatFare(km * rate);
    return { value, label: km === undefined ? formatFare(rate) + '/km' : value };
  }
  const tariff = publicRideRates[zonePicker.querySelector(':checked').value]?.[service]
    ?? (zone.country === 'VE' ? venezuelaEstimates[service] : undefined);
  if (tariff) {
    const ready = roadRoute && (tariff.perMinute === 0 || Number.isFinite(roadRoute.duration));
    const duration = tariff.perMinute ? roadRoute?.duration : 0;
    const currency = tariff.currency === 'DOP' ? 'RD$' : 'USD ';
    const value = ready ? formatFare(Math.round(100 * Math.max(tariff.minimum,
      tariff.base + roadRoute.distance * tariff.perKm / 1000 + duration * tariff.perMinute / 60)) / 100, currency) : '—';
    return { value, label: ready ? value : translate('Precio automático') };
  }
  return { value: translate('Por WhatsApp'), label: translate('Cotizar') };
}

function formatRouteTime(seconds) {
  return Number.isFinite(seconds) && seconds > 0
    ? new Intl.NumberFormat(locales[language]).format(Math.ceil(seconds / 60)) + ' min' : '—';
}

function updateEstimate() {
  const km = route ? route.distance / 1000 : undefined;
  routeDistance.textContent = route ? numberFormats[language].distance.format(km) + ' km' : '—';
  routeTime.textContent = formatRouteTime(route?.duration);
  const fare = estimateFare(selected, route);
  price.value = fare.value;
  routeStatus.textContent = translate(routeMessage || (fare.value !== '—' && fare.value !== translate('Por WhatsApp')
      ? 'Precio estimado de la carrera según la ruta.'
      : 'Tarifa por confirmar con RUVI.'));
  retryRoute.hidden = !routeFailed;
  for (const option of trips.querySelectorAll('.choice')) {
    const optionFare = estimateFare(option.querySelector('input').value, route);
    option.querySelector('small').textContent = optionFare.label;
  }
  rateHint.textContent = translate(zone.country === 'VE' ? 'Las tarifas por kilómetro se aplican a la distancia por carretera.'
      : 'Consulta el precio, la disponibilidad y las opciones de pago por WhatsApp.');
  window.updateRideQuote?.();
}

retryRoute.addEventListener('click', calculateRoute);

async function calculateRoute() {
  routeRequest?.abort();
  route = undefined;
  routeFailed = false;
  routeLine?.setLatLngs([]);
  const points = [...locations.values()].map((location) => location.coordinates);
  if (!points.every(Boolean)) {
    routeMessage = routePrompt;
    updateEstimate();
    return;
  }

  const request = new AbortController();
  routeRequest = request;
  routeMessage = 'Calculando la distancia por carretera…';
  updateEstimate();
  try {
    const path = points.map(([latitude, longitude]) => longitude + ',' + latitude).join(';');
    const providers = [
      'https://routing.openstreetmap.de/routed-car',
      'https://router.project-osrm.org',
    ];
    let result;
    let noRoute = false;
    for (const provider of providers) {
      const timeout = new AbortController();
      const cancel = () => timeout.abort();
      request.signal.addEventListener('abort', cancel, { once: true });
      const timer = setTimeout(cancel, 6000);
      try {
        const url = provider + '/route/v1/driving/' + path + '?overview=simplified&geometries=geojson';
        const response = await fetch(url, { signal: timeout.signal });
        const data = await response.json();
        if (request.signal.aborted) return;
        if (data.code === 'NoRoute' || data.code === 'NoSegment') noRoute = true;
        const candidate = response.ok ? data.routes?.[0] : undefined;
        if (Number.isFinite(candidate?.distance) && candidate.distance > 0) {
          result = candidate;
          break;
        }
      } catch {
        if (request.signal.aborted) return;
      } finally {
        clearTimeout(timer);
        request.signal.removeEventListener('abort', cancel);
      }
    }
    if (!result) {
      routeFailed = true;
      routeMessage = noRoute
        ? 'No encontramos un recorrido entre esos puntos. Prueba con otra ubicación.'
        : 'No se pudo calcular la ruta. Reintenta.';
      return;
    }
    route = result;
    routeMessage = '';
    if (map && Array.isArray(route.geometry?.coordinates) && route.geometry.coordinates.length > 1) {
      routeLine.setLatLngs(route.geometry.coordinates.map(([longitude, latitude]) => [latitude, longitude]));
      if (services[selected].route) map.fitBounds(routeLine.getBounds(), { padding: [28, 28] });
    }
  } catch {
    if (!request.signal.aborted) {
      routeFailed = true;
      routeMessage = 'No se pudo calcular la ruta. Reintenta.';
    }
  } finally {
    if (!request.signal.aborted) updateEstimate();
  }
}

function setLocationStatus(location, message) {
  location.message = message;
  location.status.textContent = translate(message);
}

function usePoint(location, label, coordinates) {
  location.input.value = label;
  location.coordinates = coordinates;
  location.results.hidden = true;
  setLocationStatus(location, location.input === origin ? 'Origen confirmado.' : 'Destino confirmado.');
  updateMaps();
  if (services[selected].route) showLocation(location.input, coordinates);
  calculateRoute();
}

function showFavoriteStatus(message) {
  favoriteStatus.textContent = message;
  favoriteStatus.hidden = !message;
}

function saveFavoritePlaces(places) {
  try {
    localStorage.setItem(favoriteStorageKey, JSON.stringify(places));
  } catch {
    showFavoriteStatus(localize('No se pudo guardar el cambio en este dispositivo.', 'Could not save the change on this device.'));
    return false;
  }
  favoritePlaces = places;
  renderFavoritePlaces();
  return true;
}

function renderFavoritePlaces() {
  favoriteList.replaceChildren();
  const region = zonePicker.querySelector(':checked').value;
  for (const place of favoritePlaces.filter(item => item.region === region)) {
    const item = document.createElement('li');
    const label = document.createElement('strong');
    label.textContent = place.label;
    const actions = document.createElement('div');
    actions.className = 'favorite-place-actions';
    for (const [id, title] of [['origin', localize('Usar de origen', 'Use as origin')], ['destination', localize('Usar de destino', 'Use as destination')]]) {
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = title;
      button.addEventListener('click', () => {
        const location = locations.get(id);
        location.revision++;
        location.searchRequest?.abort();
        usePoint(location, place.label, place.coordinates);
        location.input.focus({ preventScroll: true });
      });
      actions.append(button);
    }
    const remove = document.createElement('button');
    remove.type = 'button';
    remove.textContent = localize('Quitar', 'Remove');
    remove.addEventListener('click', () => {
      if (saveFavoritePlaces(favoritePlaces.filter(item => item !== place))) {
        document.querySelector('#route-favorites summary').focus();
        showFavoriteStatus(localize('Lugar eliminado.', 'Place removed.'));
      }
    });
    actions.append(remove);
    item.append(label, actions);
    favoriteList.append(item);
  }
}

for (const { location, button } of favoriteButtons) {
  button.addEventListener('click', () => {
    if (!location.coordinates) return;
    const region = zonePicker.querySelector(':checked').value;
    const place = { region, label: location.input.value, coordinates: location.coordinates };
    const others = favoritePlaces.filter(item => item.region !== region
      || item.coordinates[0] !== place.coordinates[0] || item.coordinates[1] !== place.coordinates[1]);
    if (saveFavoritePlaces([place, ...others].slice(0, 12))) {
      showFavoriteStatus(localize('Lugar guardado.', 'Place saved.'));
    }
  });
}

function placeSearchKey(value) {
  return value.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase()
    .replace(/[^\p{L}\p{N}]+/gu, ' ').trim();
}

async function searchPlaces(location) {
  const query = location.input.value.trim();
  if (location.searchButton.disabled) return;
  location.results.hidden = true;
  if (query.length < 3) {
    setLocationStatus(location, 'Escribe al menos tres caracteres.');
    return;
  }
  location.searchButton.disabled = true;
  setLocationStatus(location, 'Buscando lugares…');
  const revision = location.revision;
  const request = new AbortController();
  location.searchRequest = request;
  try {
    const [latitude, longitude] = mapCenter();
    const countries = zone.countries || [zone.country];
    const url = zone === zones.ve
      ? new URL('/api/places', window.location.origin)
      : new URL('https://photon.komoot.io/api/');
    url.search = new URLSearchParams({
      bbox: zone.bounds.join(','), lon: longitude, lat: latitude, limit: '10',
    });
    for (const country of countries) url.searchParams.append('countrycode', country);

    const queries = [query];
    if (zone === zones.ve && !placeSearchKey(query).includes(placeSearchKey(venezuelaCity.name))) {
      queries.push(query + ' ' + venezuelaCity.name);
    }
    const puntaCanaPrefix = /^punta cana[ ,]+(.+)$/i.exec(query);
    if (zone === zones.pc && puntaCanaPrefix) queries.push(puntaCanaPrefix[1]);
    const timeout = setTimeout(() => request.abort(), 16000);
    let features = [];
    try {
      for (const term of queries) {
        url.searchParams.set('q', term);
        const response = await fetch(url, { signal: request.signal });
        if (!response.ok) throw new Error('Búsqueda no disponible');
        const data = await response.json();
        if (location.revision !== revision) return;
        features = (data.features || []).filter(feature => {
          const point = feature.geometry?.coordinates;
          const country = feature.properties?.countrycode?.toUpperCase();
          return feature.geometry?.type === 'Point' && Array.isArray(point)
            && point.length >= 2 && point.slice(0, 2).every(Number.isFinite)
            && (!country || countries.includes(country));
        });
        if (features.length) break;
      }
    } finally {
      clearTimeout(timeout);
    }
    location.results.replaceChildren();
    const exact = [];
    let single = null;
    const key = placeSearchKey(query);
    for (const feature of features) {
      const place = feature.properties || {};
      const street = [place.street, place.housenumber].filter(Boolean).join(' ');
      const labelParts = [place.name, street, place.district, place.city, place.state];
      if (zone.countries) labelParts.push(place.country);
      const label = [...new Set(labelParts.filter(Boolean))].join(', ');
      if (!label) continue;
      const [longitude, latitude] = feature.geometry.coordinates;
      const accept = () => usePoint(location, label, [latitude, longitude]);
      const names = [label, place.name];
      if (place.city) names.push([place.name, place.city].filter(Boolean).join(' '));
      if (key && names.some(name => name && placeSearchKey(name) === key)) exact.push(accept);
      if (place.name && key && (' ' + placeSearchKey(place.name) + ' ').includes(' ' + key + ' ')) single = accept;
      const item = document.createElement('li');
      const button = document.createElement('button');
      button.type = 'button';
      button.textContent = label;
      button.addEventListener('click', () => {
        accept();
        location.input.focus();
      });
      item.append(button);
      location.results.append(item);
    }
    if (zone.country === 'VE') {
      const accept = exact.length === 1 ? exact[0] : location.results.childElementCount === 1 ? single : null;
      if (accept) {
        accept();
        return;
      }
    }
    location.results.hidden = !location.results.childElementCount;
    setLocationStatus(location, location.results.hidden
      ? 'No encontramos ese lugar. Prueba con el nombre de la villa o marca el punto en el mapa.'
      : 'Elige un resultado.');
  } catch {
    if (location.revision === revision) setLocationStatus(location, 'La búsqueda no está disponible ahora. Puedes marcar el punto en el mapa.');
  } finally {
    location.searchButton.disabled = false;
  }
}

function selectService(key) {
  selected = key;
  const service = services[key];
  travelHub.hidden = flightFields.hidden = flightFields.disabled = key !== 'vuelo';
  rentalHint.hidden = key !== 'renta';
  const isTripOption = trip().value === key;
  trips.hidden = !isTripOption;
  extras.hidden = isTripOption;
  routeFields.hidden = !service.route;
  mapPanel.hidden = !service.route;
  routeFields.parentElement.hidden = !service.route;
  if (!service.route) closeMapPicker();
  if (service.route && map) map.invalidateSize();
  for (const input of [origin, destination]) input.disabled = !service.route;
  estimate.hidden = !service.route;

  fields.replaceChildren();
  for (const [index, [name, type, hint, required = true]] of (service.fields || []).entries()) {
    const field = document.createElement('div');
    if (type === 'textarea') field.className = 'wide';
    const label = document.createElement('label');
    const input = document.createElement(type === 'textarea' ? 'textarea' : 'input');
    input.id = 'detail-' + index;
    input.name = name;
    input.required = required;
    input.maxLength = 300;
    if (type !== 'textarea') input.type = type;
    if (type === 'number') input.min = '1';
    label.htmlFor = input.id;
    field.append(label, input);
    fields.append(field);
  }
  if (key === 'renta') {
    const pickupDate = fields.querySelector('[name="Fecha de recogida"]');
    const returnDate = fields.querySelector('[name="Fecha de devolución"]');
    pickupDate.addEventListener('input', () => { returnDate.min = pickupDate.value; });
  }
  updateServiceLabels();
  fields.hidden = !fields.childElementCount;
  for (const card of cards) {
    if (card.tagName === 'BUTTON') card.setAttribute('aria-pressed', String(card.dataset.service === key));
    else if (card.closest('.home-services')) card.classList.toggle('selected', card.dataset.service === key);
  }
  updateEstimate();
}

function updateServiceLabels() {
  const service = services[selected];
  extraTitle.textContent = translate(service.title);
  const titles = {
    mototaxi: 'RUVI Moto',
    delivery: localize('RUVI Exprés', 'RUVI Express'),
  };
  document.querySelector('#quote-title').textContent = titles[selected]
    ?? (service.route ? localize('Planifica tu viaje', 'Plan your ride') : translate(service.title));
  document.querySelector('.quote-heading p').hidden = !service.route;
  for (const [index, [name, , hint]] of (service.fields || []).entries()) {
    const [label, input] = fields.children[index].children;
    label.textContent = translate(name);
    if (hint) input.placeholder = translate(name === 'Ciudad' ? zone.cityExample || hint : hint);
  }
}

function updateZone() {
  const selectedRegion = zonePicker.querySelector(':checked + span');
  document.querySelector('#quote-region-label').textContent = selectedRegion.textContent;
  const isPuntaCana = zone.country === 'DO';
  const place = translate(mapLocation());
  mapPlace.textContent = place;
  cityMap.setAttribute('aria-label', translate('Mapa interactivo de ') + place);
  mapFallback.textContent = translate('Abre el mapa de {place} con el enlace de abajo.').replace('{place}', place);
  const isVenezuela = zone.country === 'VE';
  origin.placeholder = isVenezuela ? localize('Ej. ', 'E.g. ') + venezuelaCity.origin
    : translate(isPuntaCana ? 'Ej. Aeropuerto de Punta Cana' : 'Dirección o punto de partida');
  destination.placeholder = isVenezuela ? localize('Ej. ', 'E.g. ') + venezuelaCity.destination
    : localize('¿A dónde vas?', 'Where to?');
  searchHint.textContent = translate(isPuntaCana
    ? 'Busca un hotel, dirección o punto de referencia en República Dominicana. Agrega la ciudad.'
    : 'Escribe el lugar y la ciudad, pulsa Buscar y elige un resultado para cada punto.');
  const methods = paymentsByCountry[zone.country] ?? paymentsByCountry.EU;
  const selectedPayment = paymentChoices.find(({ input }) => input.checked)?.input.value;
  const payment = methods.includes(selectedPayment) ? selectedPayment : methods[0];
  for (const [index, { choice, input, label }] of paymentChoices.entries()) {
    input.value = methods[index] ?? '';
    choice.hidden = input.disabled = !methods[index];
    label.textContent = translate(input.value);
    input.checked = input.value === payment;
  }
}

const mapActions = document.querySelector('#map-actions');
const mapPicker = document.querySelector('#map-picker');
const mapCrosshair = document.querySelector('#map-crosshair');
const mapPointStatus = document.querySelector('#map-point-status');
let mapPoint;

function closeMapPicker() {
  mapPoint = null;
  mapPicker.hidden = mapCrosshair.hidden = true;
  mapActions.hidden = !map;
  mapPointStatus.textContent = '';
}

for (const button of mapActions.querySelectorAll('[data-map-point]')) {
  button.addEventListener('click', () => {
    mapPoint = locations.get(button.dataset.mapPoint);
    mapActions.hidden = true;
    mapPicker.hidden = mapCrosshair.hidden = false;
    cityMap.focus({ preventScroll: true });
    cityMap.scrollIntoView({ block: 'nearest' });
  });
}
document.querySelector('#map-point-cancel').addEventListener('click', () => {
  const point = mapPoint;
  closeMapPicker();
  point?.input.focus({ preventScroll: true });
});
document.querySelector('#map-point-confirm').addEventListener('click', () => {
  if (!mapPoint || !map) return;
  const { lat, lng } = map.getCenter().wrap();
  const [west, south, east, north] = zone.bounds;
  if (lng < west || lng > east || lat < south || lat > north) {
    mapPointStatus.textContent = localize('Elige un punto dentro de la región seleccionada.', 'Choose a point within the selected region.');
    return;
  }
  const point = mapPoint;
  closeMapPicker();
  point.revision++;
  point.searchRequest?.abort();
  usePoint(point, lat.toFixed(5) + ', ' + lng.toFixed(5), [lat, lng]);
  point.input.focus({ preventScroll: true });
});
closeMapPicker();

zonePicker.addEventListener('change', (event) => {
  regionChosen = true;
  zone = zones[event.target.value];
  closeMapPicker();
  zonePicker.closest('details').open = false;
  for (const location of locations.values()) {
    location.revision++;
    location.searchRequest?.abort();
    location.input.value = '';
    location.coordinates = undefined;
    setLocationStatus(location, '');
    location.results.replaceChildren();
    location.results.hidden = true;
  }
  markers?.clearLayers();
  map?.setView(mapCenter(), zone.zoom);
  updateZone();
  showFavoriteStatus('');
  renderFavoritePlaces();
  if (selected === 'renta' && zone !== zones.pc) selectService(trip().value);
  else updateServiceLabels();
  updateMaps();
  calculateRoute();
});

for (const location of locations.values()) {
  location.revision = 0;
  location.searchButton.addEventListener('click', () => searchPlaces(location));
  location.input.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter') return;
    event.preventDefault();
    searchPlaces(location);
  });
  location.input.addEventListener('input', () => {
    location.revision++;
    location.searchRequest?.abort();
    location.results.hidden = true;
    setLocationStatus(location, '');
    location.coordinates = undefined;
    clearLocation(location.input);
    updateMaps();
    calculateRoute();
  });
}
trips.addEventListener('change', () => selectService(trip().value));
back.addEventListener('click', () => {
  selectService(trip().value);
  trip().focus();
});
flightType.addEventListener('change', () => {
  flightReturnField.hidden = flightReturn.disabled = flightType.selectedIndex === 0;
});
flightDeparture.addEventListener('change', () => {
  flightReturn.min = flightDeparture.value;
});

for (const card of cards) {
  card.addEventListener('click', (event) => {
    const service = card.dataset.service;
    if (card.tagName === 'A') {
      if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
      event.preventDefault();
      goToRuviService('solicitud', service, zonePicker.querySelector(':checked').value);
      return;
    }
    if (service === 'renta' && zone !== zones.pc) zonePicker.querySelector('[value="pc"]').click();
    if (selected !== service) selectService(service);
    document.querySelector('#solicitud').scrollIntoView();
    const focusTarget = {
      vuelo: document.querySelector('#quote-title'),
      renta: fields.querySelector('input'),
    }[selected] || back;
    focusTarget.focus({ preventScroll: true });
  });
}

for (const button of document.querySelectorAll('[data-location]')) {
  button.addEventListener('click', () => {
    const location = locations.get(button.dataset.location);
    if (!navigator.geolocation) {
      setLocationStatus(location, 'La ubicación no está disponible. Escribe la dirección.');
      return;
    }
    const revision = ++location.revision;
    location.results.hidden = true;
    button.disabled = true;
    setLocationStatus(location, 'Buscando tu ubicación…');
    navigator.geolocation.getCurrentPosition(({ coords }) => {
      button.disabled = false;
      if (location.revision !== revision) return;
      const [west, south, east, north] = zone.bounds;
      if (coords.latitude < south || coords.latitude > north || coords.longitude < west || coords.longitude > east) {
        setLocationStatus(location, 'Tu ubicación está fuera de la zona seleccionada. Busca una dirección o cambia de zona.');
        return;
      }
      const label = [coords.latitude.toFixed(5), coords.longitude.toFixed(5)].join(', ');
      usePoint(location, label, [coords.latitude, coords.longitude]);
      setLocationStatus(location, 'Ubicación actual agregada.');
    }, () => {
      button.disabled = false;
      if (location.revision === revision) setLocationStatus(location, 'No se pudo obtener tu ubicación. Escribe la dirección o revisa los permisos.');
    }, { timeout: 10000 });
  });
}

form.addEventListener('invalid', (event) => {
  if (customer.contains(event.target)) customer.open = true;
}, true);

function openWhatsApp(form, message) {
  const url = new URL(form.action);
  url.searchParams.set('text', message.join('\n'));
  window.open(url, '_blank', 'noopener,noreferrer');
}

form.addEventListener('submit', (event) => {
  event.preventDefault();
  if (selected === 'vuelo' || window.isRideService?.()) return;
  const service = services[selected];
  const data = new FormData(form);
  const details = [...data]
    .filter(([name, value]) => !['trip', 'payment', 'ride-payment'].includes(name) && value.trim())
    .map(([name, value]) => {
      const detail = name === 'Clase de cabina' ? document.querySelector('#flight-cabin').selectedOptions[0].textContent
        : name === flightType.name || name === 'Solo vuelos directos' ? translate(value) : value.trim();
      return translate(name) + ': ' + detail;
    });
  const payment = data.get('payment');
  const message = [
    translate('Hola, RUVI. Quisiera una cotización.'),
    translate('Zona') + ': ' + translate(zone.label),
    translate('Servicio') + ': ' + translate(service.title),
    ...details,
  ];
  if (payment) message.push(translate('Método de pago') + ': ' + translate(payment));
  if (route && !estimate.hidden) {
    message.push(translate('Distancia por carretera') + ': ' + routeDistance.textContent);
    if (tripRate(selected)) message.push(translate('Precio calculado') + ': ' + price.value);
  }
  openWhatsApp(form, message);
});

const staticText = [...document.querySelectorAll('[data-en]')].map((element) => {
  const node = [...element.childNodes].find((child) => child.nodeType === Node.TEXT_NODE && child.nodeValue.trim());
  return { node, spanish: node.nodeValue, english: element.dataset.en };
});
const staticAttributes = ['aria-label', 'placeholder', 'content'].flatMap((attribute) =>
  [...document.querySelectorAll('[data-en-' + attribute + ']')].map((element) => ({
    element,
    attribute,
    spanish: element.getAttribute(attribute),
    english: element.getAttribute('data-en-' + attribute),
  })),
);
const languageSelect = document.querySelector('#app-language');
let detectedCountry;

function selectedLanguage() {
  if (languageSelect.value !== 'auto') return languageSelect.value;
  const preferred = navigator.languages?.length ? navigator.languages : [navigator.language || 'es'];
  return automaticLanguage(detectedCountry, preferred, locales);
}

function setDetectedLocation(country, city) {
  detectedCountry = country;
  const region = suggestedRegion(country);
  if (region && !regionChosen && !origin.value && !destination.value && selected !== 'renta') {
    if (region === 've' && Object.hasOwn(venezuelaCities, city)) venezuelaCity = venezuelaCities[city];
    const option = zonePicker.querySelector('[value="' + region + '"]');
    if (!option.checked) option.click();
    else if (region === 've') {
      map?.setView(mapCenter(), zone.zoom);
      updateZone();
      updateMaps();
    }
  }
  if (personalDialog.open && !personalRegionChosen) suggestPersonalRegion();
  const next = selectedLanguage();
  if (next === language) return false;
  setLanguage(next);
  return true;
}

function setLanguage(next) {
  language = next;
  document.documentElement.lang = language;
  for (const { node, spanish, english } of staticText) {
    node.nodeValue = spanish.replace(spanish.trim(), () => localize(spanish.trim(), english));
  }
  for (const { element, attribute, spanish, english } of staticAttributes) {
    element.setAttribute(attribute, localize(spanish, english));
  }
  for (const location of locations.values()) setLocationStatus(location, location.message || '');
  markers?.eachLayer((marker) => {
    marker.setTooltipContent(translate(locations.get(marker.options.pointId).input.name));
  });
  for (const [selector, title] of [['.leaflet-control-zoom-in', 'Acercar'], ['.leaflet-control-zoom-out', 'Alejar']]) {
    const control = cityMap.querySelector(selector);
    control?.setAttribute('aria-label', translate(title));
    control?.setAttribute('title', translate(title));
  }
  updateZone();
  renderFavoritePlaces();
  updateServiceLabels();
  updateEstimate();
  updateMaps();
  window.renderRideStatus?.();
  window.renderVenues?.();
  window.renderFlights?.();
  updatePersonalRegion();
  window.renderAssistant?.();
}

languageSelect.addEventListener('change', () => {
  setLanguage(selectedLanguage());
  try { localStorage.setItem('ruvi-language', languageSelect.value); } catch {}
});
window.addEventListener('languagechange', () => {
  if (languageSelect.value === 'auto') setLanguage(selectedLanguage());
});

const personalDialog = document.querySelector('#personal-service');
const personalRegion = document.querySelector('#personal-region');
const personalRegionNote = document.querySelector('#personal-region-note');
const personalRental = document.querySelector('#personal-rental');
let personalRegionChosen = false;

function suggestedRegion(country) {
  return Object.keys(zones).find((key) => country
    && (zones[key].country === country || zones[key].countries?.includes(country)));
}

function updatePersonalRegion() {
  personalRental.hidden = personalRegion.value !== 'pc';
  personalRegionNote.textContent = !personalRegionChosen && suggestedRegion(detectedCountry)
    ? localize('Región sugerida según tu conexión. Puedes cambiarla.', 'Region suggested from your connection. You can change it.')
    : localize('Elige la región donde necesitas el servicio.', 'Choose the region where you need the service.');
}

function suggestPersonalRegion() {
  personalRegion.value = suggestedRegion(detectedCountry) ?? zonePicker.querySelector(':checked').value;
  updatePersonalRegion();
}

document.querySelector('#personal-service-open').addEventListener('click', () => {
  if (!personalRegionChosen) suggestPersonalRegion();
  personalDialog.showModal();
});

personalRegion.addEventListener('change', () => {
  personalRegionChosen = true;
  updatePersonalRegion();
});

function currentServiceRegion() {
  return personalRegionChosen ? personalRegion.value
    : suggestedRegion(detectedCountry) ?? zonePicker.querySelector(':checked').value;
}

function goToRuviService(targetId, service, region, category) {
  if (service) {
    const zoneOption = zonePicker.querySelector('[value="' + region + '"]');
    if (!zoneOption.checked) zoneOption.click();
    const tripOption = trips.querySelector('[value="' + service + '"]');
    if (tripOption && !tripOption.checked) tripOption.click();
    if (selected !== service) selectService(service);
  } else {
    const selectors = {
      diversion: '#fun-region',
      'delivery-comida': '#food-region',
    };
    const marketSelect = selectors[targetId] ? document.querySelector(selectors[targetId]) : null;
    const market = region === 'pc' ? 'do' : region;
    if (marketSelect && [...marketSelect.options].some(option => option.value === market) && marketSelect.value !== market) {
      marketSelect.value = market;
      marketSelect.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }
  if (targetId === 'diversion') {
    const categorySelect = document.querySelector('#fun-category');
    categorySelect.value = category ?? '';
    categorySelect.dispatchEvent(new Event('change', { bubbles: true }));
  }
  const target = document.getElementById(targetId);
  const url = new URL(window.location.href);
  if (service === 'vuelo') url.searchParams.set('servicio', 'vuelos');
  else if (service === 'delivery') url.searchParams.set('servicio', 'delivery');
  else if (service === 'mototaxi') url.searchParams.set('servicio', 'moto');
  else url.searchParams.delete('servicio');
  url.hash = targetId;
  if (url.href !== window.location.href) window.history.pushState(null, '', url);
  target.tabIndex = -1;
  target.focus({ preventScroll: true });
  target.scrollIntoView();
}

travelHub.querySelector('[data-travel-flight]').addEventListener('click', () => {
  const field = document.querySelector('#flight-origin');
  field.focus({ preventScroll: true });
  field.scrollIntoView({ block: 'center' });
});
for (const button of travelHub.querySelectorAll('[data-travel-target]')) {
  button.addEventListener('click', () => {
    const { travelTarget, travelService, travelRegion, travelCategory, travelCity } = button.dataset;
    if (travelTarget === 'diversion') {
      const city = document.querySelector('#fun-city');
      city.value = travelCity ?? '';
      city.dispatchEvent(new Event('input', { bubbles: true }));
    }
    goToRuviService(travelTarget, travelService, travelRegion ?? zonePicker.querySelector(':checked').value, travelCategory);
  });
}

for (const button of personalDialog.querySelectorAll('[data-personal-target]')) {
  button.addEventListener('click', () => {
    personalDialog.close();
    goToRuviService(button.dataset.personalTarget, button.dataset.personalService, personalRegion.value, button.dataset.directoryCategory);
  });
}

const accountDialog = document.querySelector('#ruvi-account');
document.querySelector('#account-open').addEventListener('click', () => accountDialog.showModal());
document.querySelector('#home-passenger').addEventListener('click', (event) => {
  if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
  event.preventDefault();
  accountDialog.showModal();
});
if (window.location.hash === '#cuenta-pasajero') accountDialog.showModal();

document.querySelector('#activity-open').addEventListener('click', () => {
  if (document.querySelector('#mi-carrera').hidden) document.querySelector('#ruvi-activity').showModal();
  else goToRuviService('mi-carrera');
});

for (const link of document.querySelectorAll('[data-close-dialog]')) {
  link.addEventListener('click', (event) => {
    if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    event.preventDefault();
    link.closest('dialog').close();
    goToRuviService(link.hash.slice(1), link.dataset.service, currentServiceRegion());
  });
}

document.querySelector('.app-dock a').addEventListener('click', (event) => {
  if (event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
  event.preventDefault();
  goToRuviService('inicio', 'carro', zonePicker.querySelector(':checked').value);
});

const installButton = document.querySelector('#install-app');
const installDialog = document.querySelector('#install-dialog');
let installPrompt;

window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  installPrompt = event;
});
window.addEventListener('appinstalled', () => {
  installPrompt = undefined;
  installButton.hidden = true;
});
installButton.hidden = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true;
installButton.addEventListener('click', async () => {
  if (!installPrompt) {
    installDialog.showModal();
    return;
  }
  const prompt = installPrompt;
  installPrompt = undefined;
  try { await prompt.prompt(); } catch { installDialog.showModal(); }
});
if ('serviceWorker' in navigator) {
  const updateButton = document.querySelector('#update-app');
  let updateRequested = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (updateRequested) window.location.reload();
  });
  navigator.serviceWorker.register('./sw.js').then((registration) => {
    const showUpdate = () => {
      updateButton.hidden = !(registration.waiting && navigator.serviceWorker.controller);
    };
    showUpdate();
    registration.addEventListener('updatefound', () => {
      registration.installing?.addEventListener('statechange', showUpdate);
    });
    updateButton.addEventListener('click', () => {
      if (!registration.waiting) return;
      updateRequested = true;
      updateButton.disabled = true;
      registration.waiting.postMessage('activate-ruvi-update');
    });
  }).catch(() => {});
}

const requestedService = launchParams.get('servicio') || (launchParams.get('delivery') === 've' ? 'delivery' : null);
const requestedTrip = { delivery: 'delivery', moto: 'mototaxi' };
if (Object.hasOwn(requestedTrip, requestedService)) {
  trips.querySelector('[value="' + requestedTrip[requestedService] + '"]').checked = true;
}
selectService(requestedService === 'vuelos' ? 'vuelo' : trip().value);
if (requestedService === 'delivery' && window.location.hash === '#delivery') {
  document.querySelector('#solicitud').scrollIntoView();
}
if (window.location.hash === '#pedido-entre-vecinos') window.location.replace('#delivery');
if (window.location.hash === '#registrar-establecimiento') window.location.replace('#diversion');
let savedLanguage;
try { savedLanguage = localStorage.getItem('ruvi-language'); } catch {}
languageSelect.value = Object.hasOwn(locales, savedLanguage) ? savedLanguage : 'auto';
setLanguage(selectedLanguage());
