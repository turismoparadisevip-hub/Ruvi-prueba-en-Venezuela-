const driver = new URLSearchParams(location.search).has('conductor');
const requestForm = document.querySelector('#group-request');
const vehicleForm = document.querySelector('#group-vehicle');
const status = document.querySelector('#group-status');
const list = document.querySelector('#group-list');
const signin = document.querySelector('#group-signin');
const refresh = document.querySelector('#group-refresh');
const zone = new URLSearchParams(location.search).get('region');
if (zone === 've') requestForm.elements.zone.value = zone;
if (driver && location.hostname.endsWith('.onrender.com')) signin.href = '/cuenta/?destino=conductores';

async function call(action, data = {}) {
  const response = await fetch('/api/ruvi/group-rides', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action, ...data }),
  });
  if (!response.ok) {
    const { error } = await response.json();
    throw new Error({
      signin: 'Inicia sesión para continuar.',
      driver_required: 'Necesitas un perfil de conductor aprobado en Punta Cana o Venezuela.',
      unavailable: 'La solicitud u oferta ya no está disponible. Actualiza la lista.',
      wait: 'Espera unos segundos antes de volver a enviar.',
      invalid: 'Revisa los datos. La fecha de salida debe ser futura.',
    }[error] || 'No se pudo completar la operación. Inténtalo de nuevo.');
  }
  return response.json();
}

function add(parent, tag, label) {
  const node = document.createElement(tag);
  node.textContent = label;
  parent.append(node);
  return node;
}

async function run(button, task) {
  button.disabled = true;
  status.textContent = '';
  try { await task(); } catch (error) { status.textContent = error.message; }
  finally { button.disabled = false; }
}

function bindForm(form, action, convert) {
  form.addEventListener('submit', event => {
    event.preventDefault();
    const button = event.submitter || form.querySelector('button');
    const data = Object.fromEntries(new FormData(form));
    run(button, async () => {
      await call(action, convert(data, button));
      await load();
    });
  });
}

bindForm(requestForm, 'request', data => ({
  ...data, passengers: Number(data.passengers), departure: Date.parse(data.departure + '-04:00'),
}));
bindForm(vehicleForm, 'vehicle', (data, button) => ({
  ...data, seats: Number(data.seats), online: button.value === 'yes',
}));

function showRequest(item) {
  const card = add(list, 'article', '');
  const money = amount => new Intl.NumberFormat('es', {
    style: 'currency', currency: item.zone === 'pc' ? 'DOP' : 'USD',
  }).format(amount / 100);
  const pickup = new Intl.DateTimeFormat('es', {
    dateStyle: 'medium', timeStyle: 'short', timeZone: item.zone === 'pc' ? 'America/Santo_Domingo' : 'America/Caracas',
  }).format(item.departure);
  add(card, 'h3', item.vehicle === 'van' ? 'RUVI Van' : 'RUVI Camioneta');
  add(card, 'p', item.pickup + ' → ' + item.destination);
  add(card, 'p', [item.passengers + ' pasajeros', pickup, item.service === 'traslado' ? 'Traslado' : 'Excursión',
    { ida: 'Solo ida', regreso: 'Ida y vuelta', espera: 'Ida y vuelta con espera' }[item.trip]].join(' · '));
  if (driver) {
    if (item.offer) {
      add(card, 'p', (item.accepted ? 'Oferta aceptada · ' : 'Oferta enviada · ') + money(item.amount));
      return;
    }
    const form = add(card, 'form', '');
    const price = add(add(form, 'label', 'Precio total (' + (item.zone === 'pc' ? 'RD$' : 'USD') + ')'), 'input', '');
    Object.assign(price, { type: 'number', name: 'amount', min: '0.01', max: '1000000', step: '0.01', required: true });
    const note = add(add(form, 'label', 'Qué incluye el precio'), 'input', '');
    Object.assign(note, { name: 'note', maxLength: 240 });
    add(form, 'button', 'Enviar oferta').type = 'submit';
    bindForm(form, 'offer', data => ({ ...data, amount: Math.round(Number(data.amount) * 100), request: item.id }));
    return;
  }
  if (item.accepted) add(card, 'p', 'Viaje confirmado');
  if (!item.offers.length) add(card, 'p', item.departure > Date.now() ? 'Esperando ofertas' : 'Solicitud vencida');
  for (const offer of item.offers.filter(offer => !item.accepted || offer.id === item.accepted)) {
    add(card, 'p', [offer.name, money(offer.amount), offer.note].filter(Boolean).join(' · '));
    if (!item.accepted && item.departure > Date.now()) {
      const button = add(card, 'button', 'Aceptar oferta de ' + money(offer.amount));
      button.addEventListener('click', () => run(button, async () => {
        await call('accept', { request: item.id, offer: offer.id });
        await load();
      }));
    }
  }
}

async function load() {
  const data = await call(driver ? 'driver' : 'passenger');
  signin.hidden = true;
  requestForm.hidden = driver;
  vehicleForm.hidden = !driver;
  if (driver) {
    if (data.vehicle) {
      vehicleForm.elements.vehicle.value = data.vehicle.vehicle;
      vehicleForm.elements.seats.value = data.vehicle.seats;
    }
    status.textContent = data.vehicle?.active_until > Date.now() ? 'Estás disponible para grupos.' : 'Estás fuera de línea para grupos.';
  }
  list.replaceChildren();
  if (!data.requests.length) add(list, 'p', 'No hay solicitudes.');
  data.requests.forEach(showRequest);
}

refresh.addEventListener('click', () => run(refresh, load));
load().catch(error => {
  status.textContent = error.message;
  signin.hidden = error.message !== 'Inicia sesión para continuar.';
});
