const arrivalForm = document.getElementById('llegada-form');

arrivalForm.addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(arrivalForm);
  const airport = data.get('aeropuerto');
  const date = data.get('fecha');
  const time = data.get('hora');
  const destination = arrivalForm.elements.destino;
  const flight = data.get('vuelo').trim();
  if (!destination.value.trim()) {
    destination.value = '';
    destination.reportValidity();
    return;
  }

  const message = [
    'Hola, RUVI. Quiero cotizar un traslado desde un aeropuerto de Venezuela.',
    'Aeropuerto: ' + airport,
    'Llegada (hora de Venezuela): ' + date + ' ' + time,
    'Destino: ' + destination.value.trim(),
    'Pasajeros: ' + data.get('pasajeros'),
  ];
  if (flight) message.push('Vuelo: ' + flight);
  openRuviWhatsApp(message);
});

function openRuviWhatsApp(message) {
  const support = new URL('https://wa.me/584122696073');
  support.searchParams.set('text', message.join('\n'));
  window.open(support, '_blank', 'noopener,noreferrer');
}

const reunionForm = document.getElementById('reencuentro-form');

reunionForm.addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(reunionForm);
  const fields = [
    ['pais', 'País de recogida'],
    ['aeropuerto', 'Ciudad y aeropuerto'],
    ['fecha', 'Fecha de llegada'],
    ['hora', 'Hora local de llegada'],
    ['vuelo', 'Vuelo'],
    ['viajero', 'Quién viaja'],
    ['recibe', 'Quién recibe'],
    ['destino', 'Lugar del reencuentro'],
  ];
  const message = ['Hola, RUVI. Quiero organizar un reencuentro.'];
  for (const [name, label] of fields) {
    const input = reunionForm.elements.namedItem(name);
    const value = data.get(name).trim();
    if (!value && input.required) {
      input.value = '';
      input.reportValidity();
      return;
    }
    if (value) message.push(label + ': ' + value);
  }
  openRuviWhatsApp(message);
});

const eventQuoteForm = document.getElementById('event-quote-form');

eventQuoteForm?.addEventListener('submit', event => {
  event.preventDefault();
  const data = new FormData(eventQuoteForm);
  const city = eventQuoteForm.elements.ciudad;
  if (!city.value.trim()) {
    city.value = '';
    city.reportValidity();
    return;
  }
  const message = [
    'Hola, RUVI. Quiero cotizar un evento en Venezuela.',
    'Tipo de evento: ' + data.get('tipo'),
    'Ciudad: ' + city.value.trim(),
    'Invitados: ' + data.get('invitados'),
  ];
  const date = data.get('fecha');
  const details = data.get('detalles').trim();
  if (date) message.push('Fecha estimada: ' + date);
  if (details) message.push('Detalles: ' + details);
  openRuviWhatsApp(message);
});
