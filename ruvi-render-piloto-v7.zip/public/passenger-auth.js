const gate = document.querySelector('#passenger-access');
const app = document.querySelector('#passenger-app');
const googleButton = document.querySelector('#passenger-google');
const signOutButton = document.querySelector('#passenger-signout');
const status = document.querySelector('#passenger-access-status');
const welcome = gate.querySelector('[data-access-step="welcome"]');

const firebaseConfig = {
  apiKey: 'AIzaSyAyPZNWaxf65QPb6qXQz211s6yjuP4NzQE',
  authDomain: 'ruvi-pasajeros.firebaseapp.com',
  projectId: 'ruvi-pasajeros',
  appId: '1:559173860907:web:03ce30fced6e388e99346e',
};

function message(es, en) {
  status.textContent = document.documentElement.lang === 'en' ? en : es;
}

function loadFirebase() {
  return Promise.all([
    import('https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js'),
    import('https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js'),
  ]).then(async ([{ initializeApp }, sdk]) => {
    const auth = sdk.getAuth(initializeApp(firebaseConfig));
    await auth.authStateReady();
    sdk.onAuthStateChanged(auth, (user) => {
      const signedIn = user?.providerData.some(({ providerId }) => ['google.com', 'password', 'phone'].includes(providerId)) === true;
      const focusWasInside = (signedIn ? gate : app).contains(document.activeElement);
      if (!signedIn && gate.hidden) {
        history.splice(1);
        showAccessStep('welcome', false);
      }
      if (!signedIn && history.length === 1) welcome.hidden = false;
      gate.hidden = signedIn;
      app.hidden = !signedIn;
      app.inert = !signedIn;
      status.textContent = '';
      window.dispatchEvent(new Event('ruvi-passenger-auth'));
      if (focusWasInside) (signedIn ? signOutButton : welcome.querySelector('button')).focus();
    });
    return { auth, sdk };
  });
}

message('Comprobando tu sesión…', 'Checking your session…');
let firebase = loadFirebase();
window.ruviPassengerIdToken = async () => {
  const connection = await firebase;
  return connection?.auth.currentUser?.getIdToken() ?? null;
};
firebase.catch(() => {
  welcome.hidden = false;
  message('No pudimos conectar con el servicio de acceso. Vuelve a intentarlo.', 'Could not connect to the sign-in service. Try again.');
  firebase = null;
});

googleButton.addEventListener('click', async () => {
  googleButton.disabled = true;
  message('Abriendo Google…', 'Opening Google…');
  try {
    firebase ??= loadFirebase();
    let connection;
    try {
      connection = await firebase;
    } catch (error) {
      firebase = null;
      throw error;
    }
    const { auth, sdk } = connection;
    auth.languageCode = document.documentElement.lang;
    const provider = new sdk.GoogleAuthProvider();
    provider.setCustomParameters({ prompt: 'select_account' });
    await sdk.signInWithPopup(auth, provider);
    signOutButton.focus();
  } catch (error) {
    if (error.code === 'auth/popup-blocked') {
      message('Abre RUVI en Chrome o Safari y permite las ventanas emergentes.', 'Open RUVI in Chrome or Safari and allow pop-ups.');
    } else if (error.code === 'auth/popup-closed-by-user') {
      status.textContent = '';
    } else if (['auth/operation-not-allowed', 'auth/unauthorized-domain'].includes(error.code)) {
      message('El acceso con Google aún no está habilitado para este sitio.', 'Google sign-in is not enabled for this site yet.');
    } else {
      message('No pudimos iniciar sesión. Revisa tu conexión y vuelve a intentarlo.', 'Could not sign in. Check your connection and try again.');
    }
  } finally {
    googleButton.disabled = false;
  }
});

signOutButton.addEventListener('click', async () => {
  signOutButton.disabled = true;
  try {
    const { auth, sdk } = await firebase;
    await sdk.signOut(auth);
  } catch {
    // Firebase leaves the current session active if sign-out fails.
    window.alert(document.documentElement.lang === 'en'
      ? 'Could not sign out. Try again.'
      : 'No pudimos cerrar la sesión. Vuelve a intentarlo.');
  } finally {
    signOutButton.disabled = false;
  }
});

const steps = [...gate.querySelectorAll('[data-access-step]')];
const history = ['welcome'];

function showAccessStep(next, focus = true) {
  for (const step of steps) step.hidden = step.dataset.accessStep !== next;
  status.textContent = '';
  const active = steps.find(step => step.dataset.accessStep === next);
  if (focus) (active.querySelector('h2') || active.querySelector('button')).focus();
}

function advanceAccess(next) {
  history.push(next);
  showAccessStep(next);
}

gate.addEventListener('click', event => {
  const button = event.target.closest('button');
  if (button?.dataset.accessNext) advanceAccess(button.dataset.accessNext);
  if (button?.hasAttribute('data-access-back') && history.length > 1) {
    history.pop();
    showAccessStep(history.at(-1));
  }
});

const emailForm = document.querySelector('#passenger-email-form');
const email = document.querySelector('#access-email');
const password = document.querySelector('#access-password');
const phoneForm = document.querySelector('#passenger-phone-form');
const phone = document.querySelector('#access-phone');
const dial = document.querySelector('#access-dial');
function fullPhoneNumber() {
  const entered = phone.value.replace(/[\s().-]/g, '');
  return entered.startsWith('+') ? entered : dial.value + entered;
}
dial.addEventListener('change', () => phone.dispatchEvent(new Event('input')));
const codeForm = document.querySelector('#passenger-code-form');
const code = document.querySelector('#access-code');
let pendingSms;

async function submitAccess(event, action) {
  event.preventDefault();
  const buttons = [...event.currentTarget.querySelectorAll('button')];
  buttons.forEach(button => { button.disabled = true; });
  message('Un momento…', 'One moment…');
  try {
    firebase ??= loadFirebase().catch(error => {
      firebase = null;
      throw error;
    });
    const { auth, sdk } = await firebase;
    auth.languageCode = document.documentElement.lang;
    await action(auth, sdk);
  } catch (error) {
    switch (error.code) {
      case 'auth/operation-not-allowed':
      case 'auth/unauthorized-domain':
      case 'auth/billing-not-enabled':
        message('Este método todavía necesita activarse en RUVI.', 'This sign-in method still needs to be enabled for RUVI.');
        break;
      case 'auth/invalid-verification-code':
        message('El código SMS es incorrecto. Revisa los seis dígitos.', 'The SMS code is incorrect. Check the six digits.');
        break;
      case 'auth/code-expired':
      case 'auth/session-expired':
        message('El código venció. Solicita otro SMS.', 'The code expired. Request another SMS.');
        break;
      case 'auth/email-already-in-use':
        message('Ya existe una cuenta con ese correo. Inicia sesión o recupera la contraseña.', 'That email already has an account. Sign in or reset your password.');
        break;
      case 'auth/weak-password':
        message('Elige una contraseña más larga.', 'Choose a longer password.');
        break;
      case 'auth/invalid-credential':
        message('Revisa el correo y la contraseña.', 'Check your email and password.');
        break;
      default:
        message('No pudimos completar el acceso. Revisa los datos e intenta de nuevo.', 'Could not complete sign-in. Check your details and try again.');
    }
  } finally {
    buttons.forEach(button => { button.disabled = false; });
  }
}

emailForm.addEventListener('submit', event => {
  submitAccess(event, async (auth, sdk) => {
    const address = email.value.trim();
    if (event.submitter?.value === 'reset') {
      if (!email.reportValidity()) {
        message('Escribe tu correo electrónico.', 'Enter your email address.');
        return;
      }
      await sdk.sendPasswordResetEmail(auth, address);
      message('Si existe una cuenta con ese correo, recibirás un enlace para recuperar la contraseña.', 'If that email has an account, you will receive a password reset link.');

    } else {
      await sdk.signInWithEmailAndPassword(auth, address, password.value);
      emailForm.reset();
    }
  });
});

phone.addEventListener('input', () => {
  pendingSms = undefined;

  codeForm.reset();
});

phoneForm.addEventListener('submit', event => {
  submitAccess(event, async (auth, sdk) => {
    const number = fullPhoneNumber();
    if (!/^\+[1-9][0-9]{6,14}$/.test(number)) {
      message('Escribe el número con su código de país, por ejemplo +1 809 555 0123.', 'Enter the number with its country code, e.g. +1 809 555 0123.');
      return;
    }
    const verifier = new sdk.RecaptchaVerifier(auth, 'passenger-send-sms', { size: 'invisible' });
    let confirmation;
    try {
      confirmation = await sdk.signInWithPhoneNumber(auth, number, verifier);
    } finally {
      verifier.clear();
    }
    if (fullPhoneNumber() !== number) return;
    pendingSms = confirmation;
    codeForm.reset();
    if (history.at(-1) !== 'code') advanceAccess('code');
    message('Ingresa el código que recibiste por SMS.', 'Enter the code you received by SMS.');
    code.focus();
  });
});

codeForm.addEventListener('submit', event => {
  submitAccess(event, async () => {
    if (!pendingSms) {
      message('Primero solicita un código por SMS.', 'Request an SMS code first.');
      return;
    }
    await pendingSms.confirm(code.value);
    pendingSms = undefined;

    codeForm.reset();
    phoneForm.reset();
  });
});


const profileForm = document.querySelector('#access-profile-form');
const passwordForm = document.querySelector('#access-password-form');
profileForm.addEventListener('submit', event => {
  event.preventDefault();
  advanceAccess('password');
});
passwordForm.addEventListener('submit', event => {
  submitAccess(event, async (auth, sdk) => {
    const chosen = document.querySelector('#access-new-password').value;
    if (chosen !== document.querySelector('#access-confirm-password').value) {
      message('Las contraseñas deben coincidir.', 'The passwords must match.');
      return;
    }
    const address = document.querySelector('#access-register-email').value.trim();
    const displayName = ['#access-first', '#access-last']
      .map(selector => document.querySelector(selector).value.trim()).join(' ');
    const { user } = await sdk.createUserWithEmailAndPassword(auth, address, chosen);
    try {
      await sdk.updateProfile(user, { displayName });
    } finally {
      profileForm.reset();
      passwordForm.reset();
    }
  });
});

for (const toggle of gate.querySelectorAll('.access-password-toggle')) {
  const input = document.getElementById(toggle.getAttribute('aria-controls'));
  function setVisibility(visible) {
    input.type = visible ? 'text' : 'password';
    toggle.setAttribute('aria-pressed', String(visible));
  }
  toggle.addEventListener('click', () => setVisibility(input.type === 'password'));
  input.form.addEventListener('reset', () => setVisibility(false));
}
