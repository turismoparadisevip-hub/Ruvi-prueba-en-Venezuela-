(() => {
  const dialog = document.querySelector('#ruvi-assistant');
  const form = document.querySelector('#assistant-form');
  const input = document.querySelector('#assistant-question');
  const status = document.querySelector('#assistant-status');
  const actions = document.querySelector('#assistant-actions');
  const topics = {
    flights: ['solicitud', 'vuelo', 'RUVI Vuelo', 'RUVI Vuelo', 'Abre la sección de vuelos de RUVI.', 'Open the RUVI flights section.'],
    ride: ['solicitud', 'carro', 'Cotizar un viaje', 'Get a ride quote', 'Indica el punto de recogida y el destino para ver el estimado disponible.', 'Enter pickup and destination to see the available estimate.'],
    transfer: ['solicitud', 'traslado', 'Traslados', 'Transfers', 'Indica la ruta, la fecha y cuántas personas viajan.', 'Enter the route, date and number of travelers.'],
    delivery: ['delivery', null, 'RUVI Delivery', 'RUVI Delivery', 'Consulta la cobertura y cotiza un envío con recogida y entrega.', 'Check coverage and get a delivery quote with pickup and drop-off.'],
    parcel: ['solicitud', 'encomienda', 'Encomiendas', 'Parcel delivery', 'Indica la ruta y qué necesitas enviar para consultar el servicio.', 'Enter the route and what you need to send to inquire about the service.'],
    experiences: ['diversion', null, 'Sitios para divertirse', 'Things to do', 'Elige ciudad y tipo de plan para buscar discotecas, parques, tours y más.', 'Choose a city and activity to find nightclubs, parks, tours and more.', 'leisure'],
    hotels: ['diversion', null, 'Hoteles', 'Hotels', 'Elige una ciudad para buscar hoteles en el directorio.', 'Choose a city to find hotels in the directory.', 'hotels'],
    motels: ['diversion', null, 'Moteles', 'Motels', 'Elige una ciudad para buscar moteles en el directorio.', 'Choose a city to find motels in the directory.', 'motels'],
    properties: ['diversion', null, 'Bienes raíces', 'Real estate', 'Explora las fichas de propiedades por ciudad.', 'Browse property listings by city.', 'properties'],
    cinemas: ['diversion', null, 'Cines', 'Cinemas', 'Busca cines y consulta su ubicación.', 'Find cinemas and see their locations.', 'cinemas'],
    rent: ['solicitud', 'renta', 'Renta de vehículos en Punta Cana', 'Car rental in Punta Cana', 'Elige fechas y lugar de entrega para solicitar la cotización en Punta Cana.', 'Choose dates and a pickup location to request a quote in Punta Cana.'],
    payment: ['solicitud', null, 'Ver opciones en el cotizador', 'View options in the quote form', 'Las opciones de efectivo o tarjeta dependen del servicio y de la zona.', 'Cash and card options depend on the service and area.'],
    help: ['soporte-ruvi', null, 'Ir a soporte', 'Go to support', 'Puedes encontrar el enlace de soporte de RUVI al pie de la página.', 'You can find the RUVI support link at the bottom of the page.'],
  };
  const example = document.querySelector('#assistant-example');
  const exampleCities = { pc: 'Bávaro', ve: 'Valencia', eu: 'París', us: 'Miami' };
  let recommendation;
  let previous;
  let state = 'start';
  let sequence = 0;

  function renderExample() {
    const city = exampleCities[currentServiceRegion()];
    example.textContent = localize('¿Qué puedo hacer esta noche en {city}?', 'What can I do tonight in {city}?').replace('{city}', city);
  }

  function render() {
    renderExample();
    status.textContent = {
      start: '',
      loading: localize('Buscando la sección adecuada…', 'Finding the right section…'),
      noMatch: localize('¿Buscas vuelos, un traslado, delivery, encomiendas o un sitio para divertirte? Prueba con el nombre del servicio.', 'Looking for flights, a transfer, delivery, parcels or things to do? Try the service name.'),
      error: localize('La consulta no está disponible ahora. Puedes usar los botones de arriba.', 'Questions are unavailable right now. You can use the buttons above.'),
      results: localize('Elige la sección que te sirve.', 'Choose the section you need.'),
    }[state];
    form.querySelector('button').disabled = state === 'loading';
    actions.replaceChildren(...(recommendation?.intents ?? []).filter((topic) => Object.hasOwn(topics, topic)).map((topic) => {
      const [target, service, esLabel, enLabel, esDetail, enDetail, category] = topics[topic];
      const row = document.createElement('div');
      row.className = 'assistant-action';
      const label = document.createElement('button');
      label.type = 'button';
      label.className = 'primary';
      const city = target === 'diversion' ? recommendation.city : null;
      const filter = topic === 'experiences' ? recommendation.experienceCategory ?? category : category;
      label.textContent = city ? localize('Buscar en {city}', 'Search in {city}').replace('{city}', city) : localize(esLabel, enLabel);
      label.addEventListener('click', () => {
        const region = topic === 'rent' ? 'pc' : recommendation.region ?? currentServiceRegion();
        dialog.close();
        goToRuviService(target, service, region, filter);
        if (city) {
          document.querySelector('#fun-city').value = city;
          document.querySelector('#fun-form').requestSubmit();
        }
      });
      const detail = document.createElement('small');
      detail.textContent = city
        ? localize(esLabel, enLabel) + (topic === 'experiences'
          ? ' · ' + localize('Confirma el horario con el establecimiento.', 'Confirm opening hours with the venue.') : '')
        : localize(esDetail, enDetail);
      row.append(detail, label);
      return row;
    }));
  }

  function recommend(intents, region = null, city = null, experienceCategory = null) {
    recommendation = { intents, region, city, experienceCategory };
    if (intents.length === 1) previous = intents[0];
    state = intents.length ? 'results' : 'noMatch';
    render();
  }

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    const question = input.value.trim();
    if (question.length < 2) return;
    const request = ++sequence;
    recommendation = undefined;
    state = 'loading';
    render();
    try {
      const response = await fetch('/api/ruvi/assistant', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question, previous }), signal: AbortSignal.timeout(12000),
      });
      if (!response.ok) throw new Error('Unavailable');
      const data = await response.json();
      if (request === sequence) recommend(data.intents, data.region, data.city, data.experienceCategory);
    } catch {
      if (request !== sequence) return;
      state = 'error';
      render();
    }
  });

  for (const button of dialog.querySelectorAll('[data-assistant-topic]')) {
    button.addEventListener('click', () => {
      sequence++;
      recommend([button.dataset.assistantTopic]);
    });
  }
  example.addEventListener('click', () => {
    input.value = example.textContent;
    form.requestSubmit();
  });
  document.querySelector('#assistant-open').addEventListener('click', () => {
    renderExample();
    dialog.showModal();
  });
  window.renderAssistant = render;
})();
