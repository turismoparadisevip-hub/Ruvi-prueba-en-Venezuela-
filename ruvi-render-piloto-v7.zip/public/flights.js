(() => {
  const byId = (id) => document.getElementById(id);
  const start = byId('flight-origin');
  const end = byId('flight-destination');
  const find = byId('flight-search');
  const status = byId('flight-search-status');
  const results = byId('flight-results');
  const cabin = byId('flight-cabin');
  const travelers = byId('flight-passengers');
  const nonstop = byId('flight-nonstop');
  let enabled;
  let state = 'ready';
  const airports = [
    ['CCS', 'Caracas'], ['VLN', 'Valencia, Venezuela'], ['MAR', 'Maracaibo'],
    ['BLA', 'Barcelona, Venezuela'], ['BRM', 'Barquisimeto'], ['PMV', 'Isla de Margarita'],
    ['PUJ', 'Punta Cana'], ['SDQ', 'Santo Domingo'], ['STI', 'Santiago de los Caballeros'],
    ['POP', 'Puerto Plata'], ['LRM', 'La Romana'], ['BOG', 'Bogotá'], ['MDE', 'Medellín'],
    ['CTG', 'Cartagena'], ['CUC', 'Cúcuta'], ['PTY', 'Ciudad de Panamá'], ['MEX', 'Ciudad de México'],
    ['MIA', 'Miami'], ['FLL', 'Fort Lauderdale'], ['NYC', 'Nueva York / New York'],
    ['JFK', 'Nueva York / New York – JFK'], ['EWR', 'Newark'], ['MCO', 'Orlando'],
    ['ATL', 'Atlanta'], ['BDL', 'Hartford'], ['LAX', 'Los Ángeles'], ['CHI', 'Chicago'],
    ['MAD', 'Madrid'], ['BCN', 'Barcelona, España'], ['TCI', 'Tenerife'],
    ['PAR', 'París / Paris'], ['LON', 'Londres / London'], ['AMS', 'Ámsterdam'],
    ['BRU', 'Bruselas / Brussels'], ['LIS', 'Lisboa / Lisbon'], ['ROM', 'Roma / Rome'],
  ].map(([code, name]) => ({ code, name }));
  const normalize = (text) => text.trim().toLowerCase().normalize('NFD').replace(/\p{Diacritic}/gu, '');
  let offers = [];
  let search;

  function translateStatus(key) {
    return ({
      unavailable: localize('La búsqueda y compra de vuelos en RUVI aún están en preparación.', 'Flight search and booking in RUVI are coming soon.'),
      ready: localize('Busca por ciudad o código de aeropuerto. Los precios corresponden a todos los adultos del viaje.', 'Search by city or airport code. Prices cover all adults on the trip.'),
      invalid: localize('Elige dos aeropuertos o ciudades distintos y revisa las fechas.', 'Choose two different airports or cities and check the dates.'),
      loading: localize('Buscando vuelos…', 'Searching for flights…'),
      empty: localize('No encontramos vuelos para esta búsqueda. Prueba otras fechas o permite escalas.', 'No flights found for this search. Try other dates or allow connections.'),
      wait: localize('Espera unos segundos antes de buscar otra vez.', 'Wait a few seconds before searching again.'),
      error: localize('No pudimos consultar los vuelos. Vuelve a intentar.', 'We could not check flights. Please try again.'),
      results: localize('Precios del proveedor sujetos a disponibilidad. Horarios en la hora local de cada aeropuerto.', 'Provider prices are subject to availability. Times are local to each airport.'),
    })[key];
  }

  function element(tag, value) {
    const node = document.createElement(tag);
    node.textContent = value;
    return node;
  }

  function localTime(iso) {
    const date = new Date(iso.slice(0, 16) + 'Z');
    if (Number.isNaN(date.getTime())) return iso;
    return new Intl.DateTimeFormat(locales[language], { dateStyle: 'medium', timeStyle: 'short', timeZone: 'UTC' }).format(date);
  }

  function render() {
    find.hidden = !enabled;
    find.disabled = !enabled || state === 'loading';
    status.textContent = translateStatus(enabled ? state : 'unavailable');
    results.replaceChildren(...offers.filter((offer) => offer.expires > Date.now()).map((offer) => {
      const card = document.createElement('article');
      card.className = 'card flight-result';
      const amount = new Intl.NumberFormat(locales[language], { style: 'currency', currency: offer.currency,
        currencyDisplay: 'code' }).format(offer.amount);
      card.append(element('strong', offer.airline || localize('Aerolínea', 'Airline')), element('strong', amount));
      for (const slice of offer.slices) {
        const line = slice.origin + ' ' + localTime(slice.departure) + ' → ' + slice.destination + ' ' + localTime(slice.arrival);
        card.append(element('p', line), element('small', slice.stops
          ? localize('Escalas: {count}', 'Connections: {count}').replace('{count}', slice.stops)
          : localize('Vuelo directo', 'Nonstop flight')));
      }
      return card;
    }));
  }

  function iata(input) {
    const value = input.value.trim().toUpperCase();
    return (/^[A-Z]{3}$/.test(value) ? value : value.match(/\(([A-Z]{3})\)$/)?.[1])
      ?? airports.find(({ name }) => normalize(name) === normalize(value))?.code ?? '';
  }

  for (const input of [start, end]) {
    let timer;
    let controller;
    function showPlaces(places) {
      input.list.replaceChildren(...places.map(({ name, code }) => {
        const option = document.createElement('option');
        option.value = name + ' (' + code + ')';
        return option;
      }));
    }
    showPlaces(airports);
    input.addEventListener('input', () => {
      clearTimeout(timer);
      controller?.abort();
      const query = input.value.trim();
      showPlaces(airports);
      if (!enabled || query.length < 2 || /\([A-Z]{3}\)$/i.test(query)) return;
      timer = setTimeout(async () => {
        controller = new AbortController();
        const { signal } = controller;
        try {
          const response = await fetch('/api/ruvi/flights/places?' + new URLSearchParams({ q: query }), { signal });
          if (!response.ok) return;
          const { places } = await response.json();
          if (signal.aborted) return;
          if (places.length) showPlaces(places);
        } catch {}
      }, 450);
    });
  }

  for (const input of [start, end, flightType, flightDeparture, flightReturn, travelers, cabin, nonstop]) {
    input.addEventListener('input', () => {
      search?.abort();
      offers = [];
      state = 'ready';
      render();
    });
  }

  find.addEventListener('click', async () => {
    if (!enabled) return;
    const now = new Date();
    const today = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
    flightDeparture.min = today;
    flightReturn.min = flightDeparture.value || today;
    const returning = flightType.selectedIndex === 0 ? null : flightReturn.value;
    if (![start, end, travelers, flightDeparture, ...(returning !== null ? [flightReturn] : [])]
      .every((input) => input.reportValidity())) return;
    const origin = iata(start);
    const destination = iata(end);
    offers = [];
    if (!origin || !destination || origin === destination || (returning && returning < flightDeparture.value)) {
      state = 'invalid';
      render();
      return;
    }
    search?.abort();
    search = new AbortController();
    const { signal } = search;
    state = 'loading';
    render();
    try {
      const response = await fetch('/api/ruvi/flights/search', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, signal: AbortSignal.any([signal, AbortSignal.timeout(25000)]),
        body: JSON.stringify({ origin, destination, departure: flightDeparture.value, returning,
          passengers: travelers.valueAsNumber, cabin: cabin.value, nonstop: nonstop.checked }),
      });
      if (!response.ok) throw new Error(response.status === 429 ? 'wait' : response.status === 400 ? 'invalid' : 'error');
      const data = await response.json();
      if (signal.aborted) return;
      offers = data.offers;
      state = offers.length ? 'results' : 'empty';
    } catch (error) {
      if (signal.aborted) return;
      state = ['wait', 'invalid'].includes(error.message) ? error.message : 'error';
    }
    render();
  });

  window.setFlightAvailability = (available) => {
    enabled = Boolean(available);
    state = 'ready';
    render();
  };
  window.renderFlights = render;
  render();
})();
