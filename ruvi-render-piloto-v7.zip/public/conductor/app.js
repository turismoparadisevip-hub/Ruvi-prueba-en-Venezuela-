const byId = id => document.getElementById(id);
const notice = byId('notice');
const form = byId('profile-form');
const dashboard = byId('dashboard');
const availability = byId('availability');
const jobPanel = byId('job');
const controls = byId('job-actions');
const install = byId('install');
const driverCountries = {"VE": "Venezuela", "DO": "República Dominicana", "US": "Estados Unidos", "ES": "España", "PT": "Portugal", "FR": "Francia", "IT": "Italia", "DE": "Alemania", "NL": "Países Bajos", "BE": "Bélgica", "GB": "Reino Unido", "IE": "Irlanda", "CH": "Suiza", "AT": "Austria", "SE": "Suecia", "NO": "Noruega", "DK": "Dinamarca", "FI": "Finlandia", "PL": "Polonia", "CZ": "Chequia", "GR": "Grecia", "RO": "Rumanía", "HU": "Hungría", "BG": "Bulgaria", "HR": "Croacia", "SK": "Eslovaquia", "SI": "Eslovenia", "EE": "Estonia", "LV": "Letonia", "LT": "Lituania", "LU": "Luxemburgo", "MT": "Malta", "CY": "Chipre", "IS": "Islandia", "AL": "Albania", "AD": "Andorra", "BA": "Bosnia y Herzegovina", "LI": "Liechtenstein", "MC": "Mónaco", "ME": "Montenegro", "MK": "Macedonia del Norte", "RS": "Serbia", "SM": "San Marino", "VA": "Ciudad del Vaticano", "MD": "Moldavia", "UA": "Ucrania", "BY": "Bielorrusia"};
let config;
let registration;
let state;
let sharing = false;
let gpsPending = false;
let commandPending = false;
let polling = false;
let refreshTimer;
let gpsTimer;
let installPrompt;
let carPhotos = [];
let carPhotoRequest = 0;

const countryInput = byId('driver-country');
const requestedCountry = new URLSearchParams(location.search).get('pais');
countryInput.value = Object.hasOwn(driverCountries, requestedCountry) ? requestedCountry : 'VE';
function updateDriverCountry(clearCity = false) {
  if (clearCity) byId('driver-city').value = '';
  const cities = countryInput.value === 'VE' ? ['Caracas', 'Valencia', 'Maracay'] : countryInput.value === 'DO' ? ['Punta Cana', 'Bávaro', 'Santo Domingo', 'Santiago'] : [];
  byId('driver-cities').replaceChildren(...cities.map(city => {
    const option = document.createElement('option');
    option.value = city;
    return option;
  }));
  if (location.pathname.startsWith('/conductores/')) byId('signin').href = '/cuenta/?destino=conductores&pais=' + countryInput.value;
}
countryInput.addEventListener('change', () => updateDriverCountry(true));
updateDriverCountry();

function vehiclePhotoKinds() {
  return registration?.profile?.vehicle === 'mototaxi' ? ['front', 'side'] : ['front', 'side', 'interior'];
}

async function api(endpoint, body) {
  const response = await fetch('/api/ruvi/' + endpoint, {
    cache: 'no-store',
    signal: AbortSignal.timeout(12000),
    ...(body === undefined ? {} : {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    }),
  });
  const result = await response.json();
  if (!response.ok) throw new Error(result.error);
  return result;
}

function showError(error) {
  const messages = {
    signin: 'Vuelve a iniciar sesión para continuar.',
    invalid: 'Revisa el teléfono, la ciudad y la placa.',
    approval: 'Tu cuenta aún requiere la aprobación de RUVI.',
    unavailable: 'El servicio todavía no está disponible. Intenta de nuevo más tarde.',
    area: 'Tu ubicación está fuera de la zona habilitada.',
    changed: 'La solicitud cambió. Espera la siguiente actualización.',
    offline: 'Ponte disponible para aceptar solicitudes.',
    photos: 'Completa las fotos de tu vehículo antes de ponerte disponible.',
    gps: 'Activa el permiso de ubicación en tu navegador y reintenta.',
  };
  notice.textContent = messages[error.message] ?? 'No pudimos completar la operación. Reintenta.';
}

function renderJob(job) {
  jobPanel.hidden = !job;
  if (!job) {
    controls.replaceChildren();
    delete controls.dataset.key;
    return;
  }
  const labels = {
    offered: 'Nueva solicitud cercana',
    accepted: 'En camino a la recogida',
    arrived: 'En el punto de recogida',
    in_progress: 'Servicio en curso',
  };
  byId('job-title').textContent = labels[job.state];
  const currency = new Intl.NumberFormat('es-VE', { style: 'currency', currency: job.currency });
  const fare = currency.format(job.amount / 100);
  const payment = job.paymentMethod === 'card'
    ? job.cardPaid ? 'Tarjeta pagada' : 'Pago con tarjeta pendiente'
    : 'Efectivo';
  byId('job-details').textContent = [
    'Total: ' + fare + ' · ' + payment,
    Number.isInteger(job.commission) && 'Comisión RUVI (15 %): ' + currency.format(job.commission / 100),
    Number.isInteger(job.driverNet) && 'Tu ganancia neta: ' + currency.format(job.driverNet / 100),
    job.state === 'offered' && job.distance != null && job.distance + ' km',
    job.pickup && job.pickup + ' → ' + job.dropoff,
    job.deliveryNote,
  ].filter(Boolean).join('\n');

  const nav = byId('navigation');
  const point = job.state === 'in_progress' ? job.to : job.from;
  nav.hidden = !point;
  if (point) {
    const url = new URL('https://www.google.com/maps/dir/');
    url.search = new URLSearchParams({ api: '1', destination: point.join(','), travelmode: 'driving' });
    nav.href = url.href;
  }
  const actions = {
    offered: [['accept', 'Aceptar'], ['decline', 'Rechazar']],
    accepted: [['arrived', 'Llegué a la recogida']],
    arrived: [['start', 'Iniciar servicio']],
    in_progress: job.paymentMethod === 'cash' ? [['paid', 'Finalizar y confirmar efectivo']]
      : job.cardPaid ? [['complete', 'Finalizar servicio']] : [],
  };
  const key = [job.id, job.state, job.cardPaid].join(':');
  if (controls.dataset.key === key) return;
  controls.dataset.key = key;
  controls.replaceChildren(...(actions[job.state] ?? []).map(([action, label]) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'secondary';
    button.textContent = label;
    if (action === 'accept') button.dataset.offerUntil = job.offerUntil;
    button.addEventListener('click', async () => {
      if (commandPending) return;
      if (action === 'paid' && !window.confirm('¿Recibiste el pago completo en efectivo?')) return;
      const error = await runCommand('driver/action', { id: job.id, action });
      if (error) showError(error);
    });
    return button;
  }));
}

function updateOfferCountdown() {
  const accept = controls.querySelector('[data-offer-until]');
  if (!accept) return;
  const seconds = Math.max(0, Math.ceil((Number(accept.dataset.offerUntil) - Date.now()) / 1000));
  accept.textContent = seconds ? 'Aceptar · ' + seconds + ' s' : 'Oferta vencida';
  accept.disabled = commandPending || seconds === 0;
}

setInterval(updateOfferCountdown, 250);

function renderDashboard() {
  const profile = registration.profile;
  const driver = state?.driver;
  const approved = driver?.approved ?? registration.approved;
  const needsPhotos = vehiclePhotoKinds().some(kind => !carPhotos.some(photo => photo.kind === kind));
  const inService = ['accepted', 'arrived', 'in_progress'].includes(state?.job?.state);
  const enabled = approved && !needsPhotos && config.zones[profile.zone]?.includes(profile.vehicle);
  availability.hidden = !enabled;
  availability.disabled = commandPending || gpsPending;
  availability.textContent = inService ? (driver?.online ? 'Desconectarme al terminar' : 'Turno cerrado')
    : sharing || driver?.online ? 'Desconectarme' : 'Conectarme';
  if (inService && !driver?.online) availability.disabled = true;
  notice.textContent = (profile.zone === 'us' || profile.zone.startsWith('eu:'))
    ? 'Prerregistro recibido para el lanzamiento. Tu zona todavía no está habilitada para recibir solicitudes.'
    : !approved
    ? needsPhotos ? 'Registro recibido. Completa las fotos de tu vehículo para la revisión de tu perfil.'
      : 'Registro recibido. Tu perfil está pendiente de aprobación.'
    : needsPhotos ? 'Completa las fotos de tu vehículo para continuar.'
    : !enabled ? 'Perfil aprobado. Las reservas todavía están en preparación para tu vehículo.'
    : inService ? (driver?.online ? 'Estás en servicio.' : 'Puedes terminar este servicio. Tu turno está cerrado.')
    : driver?.online ? 'Estás disponible. Mantén la app abierta para recibir solicitudes.'
    : sharing ? 'Obteniendo tu ubicación…' : 'Estás fuera de línea.';
  renderJob(state?.job);
  updateOfferCountdown();
}

async function runCommand(endpoint, body) {
  if (commandPending) return;
  commandPending = true;
  availability.disabled = true;
  for (const button of controls.querySelectorAll('button')) button.disabled = true;
  let error;
  try { state = await api(endpoint, body); }
  catch (failure) { error = failure; }
  finally {
    commandPending = false;
    renderDashboard();
    for (const button of controls.querySelectorAll('button')) button.disabled = false;
    updateOfferCountdown();
  }
  return error;
}

async function poll() {
  if (!registration?.profile || document.hidden || commandPending || gpsPending || polling) return;
  polling = true;
  const previous = state;
  try {
    const current = await api('status', {});
    if (state !== previous || commandPending) return;
    state = current;
    renderDashboard();
  } catch (error) { showError(error); }
  finally { polling = false; }
}

function stopSharing() {
  sharing = false;
  clearInterval(gpsTimer);
}

function locate() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) { reject(new Error('gps')); return; }
    navigator.geolocation.getCurrentPosition(
      ({ coords }) => resolve([coords.latitude, coords.longitude]),
      () => reject(new Error('gps')),
      { enableHighAccuracy: true, maximumAge: 8000, timeout: 9000 },
    );
  });
}

async function updateLocation() {
  if (!sharing || document.hidden || gpsPending || commandPending) return;
  gpsPending = true;
  renderDashboard();
  let error;
  try {
    const position = await locate();
    if (sharing && !document.hidden && !commandPending) error = await runCommand('driver/location', { position });
  } catch (failure) { error = failure; }
  finally {
    gpsPending = false;
    if (error) {
      stopSharing();
      await runCommand('driver/offline', {});
    }
    renderDashboard();
    if (error) showError(error);
  }
}

availability.addEventListener('click', async () => {
  if (sharing || state?.driver?.online) {
    stopSharing();
    const error = await runCommand('driver/offline', {});
    if (error) showError(error);
    return;
  }
  sharing = true;
  gpsTimer = setInterval(updateLocation, 12000);
  await updateLocation();
});

async function loadAccount() {
  byId('retry').hidden = true;
  byId('signin').hidden = true;
  notice.textContent = 'Comprobando tu cuenta…';
  try {
    config = await api('config');
    if (!config.signedIn) {
      notice.textContent = 'Inicia sesión para registrar tu perfil y tu carro o moto.';
      byId('signin').hidden = false;
      return;
    }
    registration = await api('driver/profile');
    form.hidden = Boolean(registration.profile);
    dashboard.hidden = !registration.profile;
    if (!registration.profile) {
      notice.textContent = 'Completa el formulario para enviar tu registro.';
      return;
    }
    byId('account-title').textContent = 'Mi perfil de conductor';
    const profile = registration.profile;
    byId('summary').replaceChildren(...[
      ['Conductor', profile.name],
      ['País', driverCountries[profile.zone === 'pc' ? 'DO' : profile.zone === 've' ? 'VE' : profile.zone === 'us' ? 'US' : profile.zone.replace('eu:', '')] ?? 'Europa'],
      ['Ciudad', profile.city],
      ['Tipo', profile.vehicle === 'mototaxi' ? 'Moto' : 'Carro'],
      ['Vehículo', profile.car_details || (profile.vehicle === 'carro' ? 'Carro' : 'Moto')],
      ['Placa', profile.plate],
    ].filter(([, value]) => value).flatMap(([label, value]) => {
      const title = document.createElement('dt');
      title.textContent = label;
      const detail = document.createElement('dd');
      detail.textContent = value;
      return [title, detail];
    }));
    await loadCarPhotos();
    renderDashboard();
    await poll();
    clearInterval(refreshTimer);
    refreshTimer = setInterval(poll, 6000);
  } catch (error) {
    byId('retry').hidden = false;
    showError(error);
  }
}

async function loadCarPhotos() {
  const section = byId('car-photos');
  section.hidden = !registration?.profile;
  byId('interior-photo-field').hidden = registration?.profile?.vehicle === 'mototaxi';
  byId('driver-documents').hidden = section.hidden;
  if (section.hidden) return;
  const { zone, vehicle } = registration.profile;
  const documents = ['license', 'insurance'];
  if (zone === 've') documents.push('medical');
  if (zone === 'pc' && vehicle !== 'mototaxi') documents.push('marbete');
  for (const kind of ['medical', 'marbete']) byId('document-' + kind).hidden = !documents.includes(kind);
  const sequence = ++carPhotoRequest;
  try {
    const result = await api('driver/photos');
    if (sequence !== carPhotoRequest) return;
    carPhotos = result.photos;
    for (const kind of ['front', 'side', 'interior', ...documents]) {
      const image = byId('car-photo-' + kind);
      const photo = carPhotos.find(item => item.kind === kind);
      image.hidden = !photo;
      image.src = photo?.photo ?? '';
    }
    const kinds = vehiclePhotoKinds();
    const completed = kinds.filter(kind => carPhotos.some(photo => photo.kind === kind)).length;
    byId('car-photo-status').textContent = completed === kinds.length
      ? 'Las fotos están guardadas para la revisión.'
      : 'Fotos guardadas: ' + completed + ' de ' + kinds.length + '.';
    const saved = documents.filter(kind => carPhotos.some(photo => photo.kind === kind)).length;
    byId('driver-document-status').textContent = 'Documentos guardados: ' + saved + ' de ' + documents.length + '.';
    renderDashboard();
  } catch {
    if (sequence !== carPhotoRequest) return;
    byId('car-photo-status').textContent = 'No pudimos cargar tus fotos. Pulsa Actualizar fotos.';
  }
}

byId('car-photo-retry').addEventListener('click', loadCarPhotos);
for (const input of document.querySelectorAll('[data-car-photo]')) {
  input.addEventListener('change', async () => {
    const file = input.files[0];
    if (!file) return;
    input.disabled = true;
    const status = byId(input.closest('#driver-documents') ? 'driver-document-status' : 'car-photo-status');
    status.textContent = 'Guardando foto…';
    try {
      if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 8 * 1024 * 1024) {
        throw new Error('image');
      }
      const bitmap = await createImageBitmap(file);
      const scale = Math.min(1, 640 / Math.max(bitmap.width, bitmap.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(bitmap.width * scale));
      canvas.height = Math.max(1, Math.round(bitmap.height * scale));
      canvas.getContext('2d').drawImage(bitmap, 0, 0, canvas.width, canvas.height);
      bitmap.close();
      let photo = canvas.toDataURL('image/jpeg', 0.8);
      if (photo.length > 130000) photo = canvas.toDataURL('image/jpeg', 0.55);
      if (photo.length > 130000) throw new Error('image');
      const kind = input.dataset.carPhoto;
      const version = carPhotos.find(item => item.kind === kind)?.version ?? 0;
      await api('driver/photos', { kind, photo, version });
      await loadCarPhotos();
    } catch (error) {
      await loadCarPhotos();
      status.textContent = error.message === 'image'
        ? 'Elige una foto JPG, PNG o WebP de menos de 8 MB y con menor resolución.'
        : 'No pudimos guardar la foto. Actualiza las fotos y reintenta.';
    } finally {
      input.disabled = false;
      input.value = '';
    }
  });
}

const driverSteps = [...form.querySelectorAll('[data-driver-step]')];
let driverStep = 0;

function showDriverStep(index) {
  driverStep = index;
  driverSteps.forEach((step, position) => { step.hidden = position !== index; });
  (driverSteps[index].querySelector('h3') || driverSteps[index].querySelector('button')).focus();
}

function nextDriverStep() {
  const inputs = [...driverSteps[driverStep].querySelectorAll('input, select')];
  if (inputs.every(input => input.reportValidity())) showDriverStep(driverStep + 1);
}

form.addEventListener('click', event => {
  if (event.target.closest('[data-driver-next]')) nextDriverStep();
  if (event.target.closest('[data-driver-back]')) showDriverStep(driverStep - 1);
});

form.addEventListener('keydown', event => {
  if (event.key === 'Enter' && event.target.matches('input') && driverStep < driverSteps.length - 1) {
    event.preventDefault();
    nextDriverStep();
  }
});

form.addEventListener('submit', async event => {
  event.preventDefault();
  if (driverStep < driverSteps.length - 1) {
    nextDriverStep();
    return;
  }
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true;
  try {
    await api('driver/profile', Object.fromEntries(new FormData(form)));
    await loadAccount();
  } catch (error) {
    if (error.message === 'profile_exists') await loadAccount();
    else showError(error);
  } finally {
    button.disabled = false;
  }
});

byId('retry').addEventListener('click', loadAccount);
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) {
    poll();
    updateLocation();
  }
});
window.addEventListener('beforeinstallprompt', event => {
  event.preventDefault();
  installPrompt = event;
  install.hidden = false;
});
install.addEventListener('click', async () => {
  if (!installPrompt) return;
  await installPrompt.prompt();
  installPrompt = undefined;
  install.hidden = true;
});
if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});
loadAccount();
