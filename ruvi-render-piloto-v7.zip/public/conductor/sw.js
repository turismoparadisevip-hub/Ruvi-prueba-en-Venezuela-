const cacheName = 'ruvi-conductor-shell-v13';
const shell = ['./', './style.css', './app.js', '/icon-192.png'];
self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(cacheName).then(cache => cache.addAll(shell)));
});
self.addEventListener('activate', (event) => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys
    .filter(key => key.startsWith('ruvi-conductor-shell-') && key !== cacheName)
    .map(key => caches.delete(key)))));
});
const shellUrls = new Set(shell.map(path => new URL(path, self.registration.scope).href));
self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET' || !shellUrls.has(event.request.url)) return;
  event.respondWith(fetch(event.request).catch(async () =>
    (await (await caches.open(cacheName)).match(event.request)) || Response.error()));
});
