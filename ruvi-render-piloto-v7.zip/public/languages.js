// Each row contains the English message followed by French, German and Italian.
const ruviTranslations = new Map(`
Local deliveries~Livraisons locales~Lokale Lieferungen~Consegne locali
Quote a delivery~Estimer une livraison~Lieferpreis berechnen~Calcola il costo di consegna
Enter the pickup and drop-off addresses to see the price and request a courier where available.~Indiquez les adresses de collecte et de livraison pour voir le prix et demander un coursier si disponible.~Geben Sie Abhol- und Lieferadresse ein, um den Preis zu sehen und einen Kurier anzufordern, sofern verfügbar.~Inserisci gli indirizzi di ritiro e consegna per vedere il prezzo e richiedere un corriere dove disponibile.
Find cinemas, parks and things to do, then get a ride quote from the listing.~Trouvez des cinémas, des parcs et des activités, puis estimez le trajet depuis la fiche.~Finden Sie Kinos, Parks und Aktivitäten und berechnen Sie die Fahrt direkt aus dem Eintrag.~Trova cinema, parchi e attività e calcola il costo del viaggio dalla scheda.
Driver dashboard~Espace chauffeur~Fahrerbereich~Area conducenti
Go online to receive nearby requests.~Passez en ligne pour recevoir des demandes à proximité.~Gehen Sie online, um Anfragen in der Nähe zu erhalten.~Vai online per ricevere richieste nelle vicinanze.
Receive delivery requests~Recevoir des demandes de livraison~Lieferanfragen erhalten~Ricevi richieste di consegna
Sign in to request a delivery~Connectez-vous pour demander une livraison~Melden Sie sich an, um eine Lieferung anzufordern~Accedi per richiedere una consegna
Request delivery~Demander une livraison~Lieferung anfordern~Richiedi una consegna
Delivery is not available in this area yet.~La livraison est encore indisponible dans cette zone.~Lieferungen sind in dieser Region noch nicht verfügbar.~Le consegne non sono ancora disponibili in questa zona.
Bávaro · Dominican Republic~Bávaro · République dominicaine~Bávaro · Dominikanische Republik~Bávaro · Repubblica Dominicana
The Bávaro pilot is in preparation. We are recruiting local shops and orders will open once service is available.~Nous préparons le projet pilote à Bávaro et recrutons des commerces locaux. Les commandes ouvriront dès que le service sera disponible.~Wir bereiten das Pilotprojekt in Bávaro vor und gewinnen lokale Geschäfte. Bestellungen sind möglich, sobald der Service verfügbar ist.~Stiamo preparando il progetto pilota a Bávaro e coinvolgendo le attività locali. Gli ordini apriranno quando il servizio sarà disponibile.
Do you own a business in Bávaro?~Vous avez un commerce à Bávaro ?~Haben Sie ein Geschäft in Bávaro?~Hai un’attività a Bávaro?
Tell RUVI your business name, what you sell, and where you are located.~Indiquez à RUVI le nom de votre commerce, vos produits et votre emplacement.~Teilen Sie RUVI den Namen, das Angebot und den Standort Ihres Geschäfts mit.~Indica a RUVI il nome della tua attività, cosa vendi e dove ti trovi.
Contact RUVI about the pilot ↗~Contacter RUVI au sujet du pilote ↗~RUVI zum Pilotprojekt kontaktieren ↗~Contatta RUVI per il progetto pilota ↗
Try the delivery simulator~Essayer le simulateur de livraison~Liefersimulator ausprobieren~Prova il simulatore di consegna
Delivery simulator~Simulateur de livraison~Liefersimulator~Simulatore di consegna
Find routes and request quotes with RUVI in the Dominican Republic, Venezuela, Europe and the United States.~Trouvez des itinéraires et demandez des devis avec RUVI en République dominicaine, au Venezuela, en Europe et aux États-Unis.~Finden Sie Routen und holen Sie Angebote von RUVI in der Dominikanischen Republik, Venezuela, Europa und den USA ein.~Trova percorsi e richiedi preventivi con RUVI nella Repubblica Dominicana, in Venezuela, in Europa e negli Stati Uniti.
RUVI | Mobility and services~RUVI | Mobilité et services~RUVI | Mobilität und Dienstleistungen~RUVI | Mobilità e servizi
Skip to the quote form~Aller au formulaire de devis~Zum Preisrechner springen~Vai al modulo di preventivo
RUVI home~Accueil RUVI~RUVI-Startseite~Home di RUVI
Ride and flight quotes~Devis pour trajets et vols~Preise für Fahrten und Flüge~Preventivi per corse e voli
Dominican Republic, Venezuela, Europe and United States~République dominicaine, Venezuela, Europe et États-Unis~Dominikanische Republik, Venezuela, Europa und USA~Repubblica Dominicana, Venezuela, Europa e Stati Uniti
More services ↓~Autres services ↓~Weitere Dienste ↓~Altri servizi ↓
Language~Langue~Sprache~Lingua
Automatic~Automatique~Automatisch~Automatico
Install app~Installer l’application~App installieren~Installa l’app
Update RUVI~Mettre à jour RUVI~RUVI aktualisieren~Aggiorna RUVI
RUVI quick links~Raccourcis RUVI~RUVI-Schnellzugriff~Collegamenti rapidi RUVI
Passengers~Passagers~Fahrgäste~Passeggeri
Get a ride quote~Estimer un trajet~Fahrpreis berechnen~Calcola il prezzo di una corsa
Drivers~Chauffeurs~Fahrer~Conducenti
Sign up for free~Inscription gratuite~Kostenlos registrieren~Registrati gratis
RUVI Delivery shortcuts~Raccourcis RUVI Delivery~RUVI-Delivery-Schnellzugriff~Collegamenti rapidi RUVI Delivery
RUVI Delivery ↗~RUVI Delivery ↗~RUVI Delivery ↗~RUVI Delivery ↗
Order with neighbors ↗~Commander entre voisins ↗~Mit Nachbarn bestellen ↗~Ordina con i vicini ↗
Get a quote with RUVI~Estimer un trajet avec RUVI~Preis mit RUVI berechnen~Calcola un preventivo con RUVI
Choose your area, pickup and drop-off to see the price and request a ride where available.~Choisissez votre zone, le départ et l’arrivée pour voir le prix et demander un trajet selon les disponibilités.~Wählen Sie Region, Abholort und Ziel, um den Preis zu sehen und, falls verfügbar, eine Fahrt anzufragen.~Scegli zona, partenza e destinazione per vedere il prezzo e richiedere una corsa, se disponibile.
Where do you need service?~Où avez-vous besoin du service ?~Wo benötigen Sie den Service?~Dove ti serve il servizio?
United States~États-Unis~Vereinigte Staaten~Stati Uniti
Europe~Europe~Europa~Europa
Dominican Republic~République dominicaine~Dominikanische Republik~Repubblica Dominicana
Report a map issue~Signaler un problème sur la carte~Kartenfehler melden~Segnala un problema sulla mappa
Pickup~Départ~Abholort~Partenza
Use current location as pickup~Utiliser ma position comme départ~Aktuellen Standort als Abholort verwenden~Usa la posizione attuale come partenza
⌖ My location~⌖ Ma position~⌖ Mein Standort~⌖ La mia posizione
Search pickup locations~Rechercher un lieu de départ~Abholort suchen~Cerca un punto di partenza
Search~Rechercher~Suchen~Cerca
Pickup search results~Résultats pour le départ~Suchergebnisse für den Abholort~Risultati per la partenza
Drop-off~Destination~Ziel~Destinazione
Use current location as drop-off~Utiliser ma position comme destination~Aktuellen Standort als Ziel verwenden~Usa la posizione attuale come destinazione
Search drop-off locations~Rechercher une destination~Ziel suchen~Cerca una destinazione
Drop-off search results~Résultats pour la destination~Suchergebnisse für das Ziel~Risultati per la destinazione
See route and distance in Maps ↗~Voir l’itinéraire et la distance dans Maps ↗~Route und Entfernung in Maps ansehen ↗~Vedi percorso e distanza su Maps ↗
Service type~Type de service~Serviceart~Tipo di servizio
Motorcycle~Moto~Motorrad~Moto
Car~Voiture~Auto~Auto
Delivery~Livraison~Lieferung~Consegna
Parcel delivery~Envoi de colis~Paketversand~Spedizione pacchi
Back to rides~Retour aux trajets~Zurück zu den Fahrten~Torna alle corse
We confirm rental rates and availability via WhatsApp.~Nous confirmons les tarifs et la disponibilité de la location sur WhatsApp.~Mietpreise und Verfügbarkeit bestätigen wir über WhatsApp.~Confermiamo prezzi e disponibilità del noleggio su WhatsApp.
Flight details~Détails du vol~Flugdaten~Dettagli del volo
Departure city or airport~Ville ou aéroport de départ~Abflugort oder -flughafen~Città o aeroporto di partenza
E.g. Caracas (CCS)~Ex. Caracas (CCS)~Z. B. Caracas (CCS)~Es. Caracas (CCS)
Arrival city or airport~Ville ou aéroport d’arrivée~Ankunftsort oder -flughafen~Città o aeroporto di arrivo
E.g. Punta Cana (PUJ)~Ex. Punta Cana (PUJ)~Z. B. Punta Cana (PUJ)~Es. Punta Cana (PUJ)
Trip type~Type de voyage~Reiseart~Tipo di viaggio
One way~Aller simple~Nur Hinflug~Solo andata
Round trip~Aller-retour~Hin- und Rückflug~Andata e ritorno
Departure date~Date de départ~Abflugdatum~Data di partenza
Return date~Date de retour~Rückreisedatum~Data di ritorno
Baggage or extra details (optional)~Bagages ou précisions (facultatif)~Gepäck oder weitere Angaben (optional)~Bagagli o altri dettagli (facoltativo)
E.g. One 23 kg bag per person~Ex. un bagage de 23 kg par personne~Z. B. ein Gepäckstück à 23 kg pro Person~Es. un bagaglio da 23 kg a persona
We confirm fares and availability via WhatsApp.~Nous confirmons les tarifs et les disponibilités sur WhatsApp.~Preise und Verfügbarkeit bestätigen wir über WhatsApp.~Confermiamo tariffe e disponibilità su WhatsApp.
Route distance~Distance du trajet~Streckenlänge~Distanza del percorso
Estimated ride price~Prix estimé~Geschätzter Preis~Prezzo stimato
Retry estimate~Relancer le calcul~Berechnung wiederholen~Riprova il calcolo
Customer details~Coordonnées du client~Kundendaten~Dati del cliente
Required~Obligatoire~Erforderlich~Obbligatorio
Name~Nom~Name~Nome
Phone~Téléphone~Telefon~Telefono
Payment method~Mode de paiement~Zahlungsart~Metodo di pagamento
Sign in to request a ride~Connectez-vous pour demander un trajet~Anmelden und Fahrt anfragen~Accedi per richiedere una corsa
Ride support on WhatsApp~Assistance trajet sur WhatsApp~Hilfe zur Fahrt auf WhatsApp~Assistenza per la corsa su WhatsApp
Request ride~Demander un trajet~Fahrt anfragen~Richiedi corsa
You can view the estimate here. Online delivery orders are not open yet.~Consultez l’estimation ici. Les commandes de livraison en ligne ne sont pas encore ouvertes.~Hier sehen Sie den Schätzwert. Online-Bestellungen für Lieferungen sind noch nicht verfügbar.~Puoi vedere la stima qui. Gli ordini di consegna online non sono ancora disponibili.
Request a quote on WhatsApp~Demander un devis sur WhatsApp~Angebot auf WhatsApp anfragen~Richiedi un preventivo su WhatsApp
Open RUVI on WhatsApp~Ouvrir RUVI sur WhatsApp~RUVI in WhatsApp öffnen~Apri RUVI su WhatsApp
My ride~Mon trajet~Meine Fahrt~La mia corsa
Cancel ride~Annuler le trajet~Fahrt stornieren~Annulla corsa
Driver route to your pickup~Itinéraire du chauffeur vers votre départ~Route des Fahrers zum Abholort~Percorso del conducente verso la partenza
Pickup route map~Carte du trajet vers le départ~Karte der Anfahrt~Mappa del percorso verso la partenza
Country or region~Pays ou région~Land oder Region~Paese o regione
Country in Europe~Pays d’Europe~Land in Europa~Paese europeo
E.g. Spain~Ex. Espagne~Z. B. Spanien~Es. Spagna
Example currency code~Code de devise de l’exemple~Währungscode für das Beispiel~Codice valuta dell’esempio
City or area~Ville ou zone~Stadt oder Gebiet~Città o zona
Enter your city~Saisissez votre ville~Stadt eingeben~Inserisci la tua città
See how free delivery would work on orders of RD$350 or more and up to 3 km at participating shops. No membership required.~Simulez la livraison gratuite dès 350 RD$ et jusqu’à 3 km chez les commerçants participants. Sans abonnement.~Testen Sie die Gratislieferung ab 350 RD$ und bis zu 3 km bei teilnehmenden Geschäften. Ohne Mitgliedschaft.~Prova la consegna gratuita da 350 RD$ fino a 3 km nei negozi aderenti. Senza abbonamento.
Try a local delivery estimate in US dollars. Pick a RUVI meeting point or share the delivery fee with neighbors.~Simulez une livraison locale en dollars américains. Choisissez un point de rendez-vous RUVI ou partagez les frais entre voisins.~Testen Sie eine lokale Lieferung in US-Dollar. Wählen Sie einen RUVI-Treffpunkt oder teilen Sie die Lieferkosten mit Nachbarn.~Simula una consegna locale in dollari USA. Scegli un punto d’incontro RUVI o dividi le spese con i vicini.
Enter an example delivery fee to see your total, or split the fee with neighbors at a RUVI meeting point.~Saisissez des frais de livraison d’exemple pour voir le total, ou partagez-les entre voisins à un point RUVI.~Geben Sie Beispiel-Lieferkosten ein, um den Gesamtpreis zu sehen, oder teilen Sie die Kosten mit Nachbarn an einem RUVI-Treffpunkt.~Inserisci un costo di consegna di esempio per vedere il totale o dividilo con i vicini in un punto RUVI.
Simulation · Live delivery areas are not open yet~Simulation · Zones de livraison encore à ouvrir~Simulation · Liefergebiete noch nicht freigeschaltet~Simulazione · Zone di consegna ancora da attivare
Try an example~Essayer un exemple~Beispiel ausprobieren~Prova un esempio
Order subtotal~Sous-total de la commande~Zwischensumme der Bestellung~Subtotale dell’ordine
Delivery distance (km)~Distance de livraison (km)~Lieferentfernung (km)~Distanza di consegna (km)
Example delivery fee~Frais de livraison d’exemple~Beispiel-Lieferkosten~Costo di consegna di esempio
Progress toward RD$350~Progression vers 350 RD$~Fortschritt bis 350 RD$~Progresso verso 350 RD$
Service fee~Frais de service~Servicegebühr~Commissione di servizio
Example total~Total de l’exemple~Beispiel-Gesamtpreis~Totale dell’esempio
RUVI Pickup Point~Point de rendez-vous RUVI~RUVI-Treffpunkt~Punto d’incontro RUVI
Choose where you would meet your courier.~Choisissez où retrouver votre livreur.~Wählen Sie, wo Sie den Kurier treffen würden.~Scegli dove incontreresti il corriere.
Meeting point~Point de rendez-vous~Treffpunkt~Punto d’incontro
Residential gate~Portail de la résidence~Eingang der Wohnanlage~Ingresso del complesso residenziale
Hotel reception~Réception de l’hôtel~Hotelrezeption~Reception dell’hotel
Main entrance~Entrée principale~Haupteingang~Ingresso principale
Reference (optional)~Indication (facultatif)~Hinweis (optional)~Indicazione (facoltativa)
E.g. Next to the blue sign~Ex. près du panneau bleu~Z. B. neben dem blauen Schild~Es. accanto al cartello blu
Courier preview~Aperçu pour le livreur~Vorschau für den Kurier~Anteprima per il corriere
The amount only simulates the order subtotal plus delivery. This preview does not place an order.~Le montant simule le sous-total et la livraison. Cet aperçu ne passe aucune commande.~Der Betrag simuliert nur Zwischensumme und Lieferung. Es wird keine Bestellung aufgegeben.~L’importo simula solo il subtotale e la consegna. L’anteprima non invia ordini.
At participating shops, the shop covers the courier’s pay. This preview does not place an order.~Le commerçant participant prend en charge la rémunération du livreur. Cet aperçu ne passe aucune commande.~Teilnehmende Geschäfte übernehmen die Vergütung des Kuriers. Es wird keine Bestellung aufgegeben.~Il negozio aderente copre il compenso del corriere. L’anteprima non invia ordini.
Order with neighbors~Commander entre voisins~Mit Nachbarn bestellen~Ordina con i vicini
Each person would order and pay separately. Orders from the same shop would arrive together at one RUVI meeting point in the same delivery window.~Chacun commanderait et paierait séparément. Les commandes d’un même commerce arriveraient ensemble au même point RUVI et au même créneau.~Jede Person würde separat bestellen und bezahlen. Bestellungen desselben Geschäfts würden im selben Zeitfenster an einem RUVI-Treffpunkt ankommen.~Ognuno ordinerebbe e pagherebbe separatamente. Gli ordini dello stesso negozio arriverebbero insieme nello stesso punto RUVI e nella stessa fascia oraria.
Simulation · No orders or payments~Simulation · Sans commande ni paiement~Simulation · Ohne Bestellungen oder Zahlungen~Simulazione · Nessun ordine o pagamento
Try sharing a delivery~Essayer une livraison partagée~Gemeinsame Lieferung ausprobieren~Prova una consegna condivisa
People in the group (including you)~Personnes dans le groupe (vous compris)~Personen in der Gruppe (Sie eingeschlossen)~Persone nel gruppo (te compreso)
Example delivery window~Créneau de livraison d’exemple~Beispiel-Lieferzeitfenster~Fascia oraria di esempio
12:00–12:30 p.m.~12 h 00–12 h 30~12:00–12:30 Uhr~12:00–12:30
6:00–6:30 p.m.~18 h 00–18 h 30~18:00–18:30 Uhr~18:00–18:30
7:00–7:30 p.m.~19 h 00–19 h 30~19:00–19:30 Uhr~19:00–19:30
Shared meeting point~Point de rendez-vous commun~Gemeinsamer Treffpunkt~Punto d’incontro condiviso
Delivery per person~Livraison par personne~Lieferkosten pro Person~Consegna a persona
Savings per person on delivery~Économies de livraison par personne~Ersparnis pro Person bei der Lieferung~Risparmio sulla consegna a persona
Your example total~Votre total d’exemple~Ihr Beispiel-Gesamtpreis~Il tuo totale di esempio
Your total uses the order subtotal above. This example splits a paid delivery fee.~Le total reprend le sous-total ci-dessus. Cet exemple partage les frais d’une livraison payante.~Ihr Gesamtpreis verwendet die Zwischensumme oben. In diesem Beispiel werden Lieferkosten geteilt.~Il totale usa il subtotale qui sopra. In questo esempio si divide una consegna a pagamento.
City or neighborhood~Ville ou quartier~Stadt oder Viertel~Città o quartiere
Sign up for free as a driver~Inscrivez-vous gratuitement comme chauffeur~Kostenlos als Fahrer registrieren~Registrati gratis come conducente
Register your profile. Once RUVI approves it, go online to receive nearby rides.~Inscrivez votre profil. Après validation par RUVI, mettez-vous en ligne pour recevoir des demandes à proximité.~Registrieren Sie Ihr Profil. Nach der Freigabe durch RUVI gehen Sie online, um Fahrten in der Nähe zu erhalten.~Registra il tuo profilo. Dopo l’approvazione di RUVI, vai online per ricevere richieste nelle vicinanze.
Sign in as a driver~Connexion chauffeur~Als Fahrer anmelden~Accedi come conducente
Full name~Nom complet~Vollständiger Name~Nome completo
Phone with country code~Téléphone avec indicatif pays~Telefonnummer mit Ländervorwahl~Telefono con prefisso internazionale
Operating area~Zone de travail~Einsatzgebiet~Zona operativa
Select an area~Choisissez une zone~Gebiet auswählen~Seleziona una zona
City~Ville~Stadt~Città
Vehicle type~Type de véhicule~Fahrzeugtyp~Tipo di veicolo
Select a vehicle~Choisissez un véhicule~Fahrzeug auswählen~Seleziona un veicolo
Submit driver registration~Envoyer l’inscription chauffeur~Fahrerregistrierung absenden~Invia la registrazione del conducente
Enable JavaScript to use the driver dashboard.~Activez JavaScript pour utiliser l’espace chauffeur.~Aktivieren Sie JavaScript für den Fahrerbereich.~Attiva JavaScript per usare il pannello conducente.
More RUVI services~Autres services RUVI~Weitere RUVI-Dienste~Altri servizi RUVI
What else do you need?~De quoi d’autre avez-vous besoin ?~Was benötigen Sie noch?~Cos’altro ti serve?
Car rental in Punta Cana ↗~Location de voiture à Punta Cana ↗~Mietwagen in Punta Cana ↗~Noleggio auto a Punta Cana ↗
Request a quote for your dates and pickup location.~Demandez un devis pour vos dates et votre lieu de prise en charge.~Angebot für Ihre Reisedaten und den Abholort anfragen.~Richiedi un preventivo per le tue date e il luogo di ritiro.
Flights ↗~Vols ↗~Flüge ↗~Voli ↗
Domestic and international flights.~Vols nationaux et internationaux.~Inlands- und Auslandsflüge.~Voli nazionali e internazionali.
Transfers ↗~Transferts ↗~Transfers ↗~Trasferimenti ↗
Airport and intercity transfers.~Transferts aéroport et entre villes.~Flughafen- und Städte-Transfers.~Trasferimenti aeroportuali e tra città.
Transfer coverage~Zones de transfert~Transfergebiete~Zone dei trasferimenti
Where you can request a transfer~Où demander un transfert~Wo Sie einen Transfer anfragen können~Dove puoi richiedere un trasferimento
Check availability for your route and date.~Vérifiez la disponibilité pour votre trajet et votre date.~Verfügbarkeit für Ihre Strecke und Ihr Datum prüfen.~Verifica la disponibilità per il percorso e la data.
RUVI · Mobility and services~RUVI · Mobilité et services~RUVI · Mobilität und Dienstleistungen~RUVI · Mobilità e servizi
WhatsApp support ↗~Assistance sur WhatsApp ↗~Hilfe auf WhatsApp ↗~Assistenza su WhatsApp ↗
Install RUVI on your phone~Installer RUVI sur votre téléphone~RUVI auf dem Smartphone installieren~Installa RUVI sul telefono
On Android, open RUVI in Chrome. In the ⋮ menu, tap Add to Home screen and choose Install if prompted.~Sur Android, ouvrez RUVI dans Chrome. Dans le menu ⋮, choisissez Ajouter à l’écran d’accueil, puis Installer si demandé.~Öffnen Sie RUVI unter Android in Chrome. Wählen Sie im Menü ⋮ „Zum Startbildschirm hinzufügen“ und bei Aufforderung „Installieren“.~Su Android, apri RUVI in Chrome. Nel menu ⋮, tocca Aggiungi alla schermata Home e scegli Installa se richiesto.
On iPhone, open RUVI in Safari. Tap Share, then Add to Home Screen, then Add.~Sur iPhone, ouvrez RUVI dans Safari. Touchez Partager, Sur l’écran d’accueil, puis Ajouter.~Öffnen Sie RUVI auf dem iPhone in Safari. Tippen Sie auf „Teilen“, „Zum Home-Bildschirm“ und dann auf „Hinzufügen“.~Su iPhone, apri RUVI in Safari. Tocca Condividi, Aggiungi alla schermata Home, quindi Aggiungi.
Done~Terminé~Fertig~Fatto
Flights~Vols~Flüge~Voli
Car rental~Location de voiture~Mietwagen~Noleggio auto
Pickup date~Date de prise en charge~Abholdatum~Data di ritiro
Pickup location~Lieu de prise en charge~Abholort~Luogo di ritiro
E.g. Hotel, airport or address~Ex. hôtel, aéroport ou adresse~Z. B. Hotel, Flughafen oder Adresse~Es. hotel, aeroporto o indirizzo
Vehicle type (optional)~Type de véhicule (facultatif)~Fahrzeugtyp (optional)~Tipo di veicolo (facoltativo)
E.g. Sedan or SUV~Ex. berline ou SUV~Z. B. Limousine oder SUV~Es. berlina o SUV
Transfer~Transfert~Transfer~Trasferimento
Delivery details~Détails de livraison~Lieferdetails~Dettagli di consegna
E.g. What you need to send~Ex. ce que vous souhaitez envoyer~Z. B. was Sie versenden möchten~Es. cosa devi spedire
Parcel details~Détails du colis~Paketdetails~Dettagli del pacco
Contents, approximate weight and size~Contenu, poids et dimensions approximatifs~Inhalt, ungefähres Gewicht und Maße~Contenuto, peso e dimensioni approssimativi
Date~Date~Datum~Data
E.g. Valencia~Ex. Valencia~Z. B. Valencia~Es. Valencia
E.g. Maracay~Ex. Maracay~Z. B. Maracay~Es. Maracay
E.g. Punta Cana~Ex. Punta Cana~Z. B. Punta Cana~Es. Punta Cana
E.g. Miami~Ex. Miami~Z. B. Miami~Es. Miami
E.g. Madrid, Spain~Ex. Madrid, Espagne~Z. B. Madrid, Spanien~Es. Madrid, Spagna
Punta Cana, Dominican Republic~Punta Cana, République dominicaine~Punta Cana, Dominikanische Republik~Punta Cana, Repubblica Dominicana
Cash (RD$)~Espèces (RD$)~Bar (RD$)~Contanti (RD$)
Cash (USD)~Espèces (USD)~Bar (USD)~Contanti (USD)
Cash (Bs.)~Espèces (Bs.)~Bar (Bs.)~Contanti (Bs.)
Debit card~Carte de débit~Debitkarte~Carta di debito
Dominican pesos~Pesos dominicains~Dominikanische Pesos~Pesos dominicani
US dollars~Dollars américains~US-Dollar~Dollari USA
Card~Carte~Karte~Carta
Select your pickup and drop-off points to calculate the route.~Sélectionnez le départ et l’arrivée pour calculer l’itinéraire.~Wählen Sie Abholort und Ziel, um die Route zu berechnen.~Seleziona partenza e destinazione per calcolare il percorso.
See route in Maps ↗~Voir l’itinéraire dans Maps ↗~Route in Maps ansehen ↗~Vedi percorso su Maps ↗
Open in Maps ↗~Ouvrir dans Maps ↗~In Maps öffnen ↗~Apri su Maps ↗
Ask on WhatsApp~Demander sur WhatsApp~Auf WhatsApp anfragen~Chiedi su WhatsApp
Estimated fare based on distance. Confirm the total when booking.~Tarif estimé selon la distance. Confirmez le total à la réservation.~Geschätzter Preis nach Entfernung. Gesamtpreis bei der Buchung bestätigen.~Tariffa stimata in base alla distanza. Conferma il totale alla prenotazione.
Confirm this fare with RUVI.~Confirmez le tarif auprès de RUVI.~Preis bei RUVI bestätigen.~Conferma il prezzo con RUVI.
Calculating driving distance…~Calcul de la distance par la route…~Straßenentfernung wird berechnet…~Calcolo della distanza su strada…
We couldn’t find a route between those points. Try a different location.~Aucun itinéraire trouvé entre ces points. Essayez un autre lieu.~Keine Route zwischen diesen Punkten gefunden. Versuchen Sie einen anderen Ort.~Nessun percorso trovato tra questi punti. Prova un altro luogo.
We could not calculate the route. Try again.~Impossible de calculer l’itinéraire. Réessayez.~Route konnte nicht berechnet werden. Versuchen Sie es erneut.~Impossibile calcolare il percorso. Riprova.
Punta Cana delivery: RD$30 base + RD$10 per km. RD$50 minimum.~Livraison à Punta Cana (30 RD$ de base + 10 RD$/km, minimum 50 RD$).~Lieferung in Punta Cana (30 RD$ Grundpreis + 10 RD$ pro km, mindestens 50 RD$).~Consegna a Punta Cana (30 RD$ di base + 10 RD$ al km, minimo 50 RD$).
Estimated delivery by road.~Frais estimés pour une livraison par la route.~Geschätzte Lieferkosten nach Straßenstrecke.~Consegna stimata in base al percorso su strada.
Estimated ride fare for this route.~Tarif estimé pour cet itinéraire.~Geschätzter Fahrpreis für diese Route.~Tariffa stimata per questo percorso.
Automatic price~Prix automatique~Automatischer Preis~Prezzo automatico
Enter at least three characters.~Saisissez au moins trois caractères.~Geben Sie mindestens drei Zeichen ein.~Inserisci almeno tre caratteri.
Searching for places…~Recherche de lieux…~Orte werden gesucht…~Ricerca dei luoghi…
We couldn’t find that place. Try the neighborhood or add the city.~Lieu introuvable. Essayez le quartier ou ajoutez la ville.~Ort nicht gefunden. Versuchen Sie das Viertel oder ergänzen Sie die Stadt.~Luogo non trovato. Prova con il quartiere o aggiungi la città.
Choose a result.~Choisissez un résultat.~Wählen Sie ein Ergebnis.~Scegli un risultato.
Search is currently unavailable. Please try again.~La recherche est indisponible. Réessayez.~Suche derzeit nicht verfügbar. Versuchen Sie es erneut.~Ricerca non disponibile. Riprova.
Interactive map of ~Carte interactive de ~Interaktive Karte für ~Mappa interattiva di\u0020
Use the link below to open the map of {place}.~Utilisez le lien ci-dessous pour ouvrir la carte de {place}.~Öffnen Sie die Karte für {place} über den Link unten.~Usa il collegamento qui sotto per aprire la mappa di {place}.
E.g. Punta Cana Airport~Ex. aéroport de Punta Cana~Z. B. Flughafen Punta Cana~Es. aeroporto di Punta Cana
Address or pickup point~Adresse ou lieu de départ~Adresse oder Abholort~Indirizzo o punto di partenza
E.g. Hotel in Bávaro~Ex. hôtel à Bávaro~Z. B. Hotel in Bávaro~Es. hotel a Bávaro
Address or drop-off point~Adresse ou lieu d’arrivée~Adresse oder Zielort~Indirizzo o destinazione
Search for a hotel, address or landmark in Punta Cana, Bávaro, Cap Cana or nearby.~Recherchez un hôtel, une adresse ou un lieu à Punta Cana, Bávaro, Cap Cana ou aux alentours.~Suchen Sie ein Hotel, eine Adresse oder einen Orientierungspunkt in Punta Cana, Bávaro, Cap Cana oder Umgebung.~Cerca un hotel, un indirizzo o un punto di riferimento a Punta Cana, Bávaro, Cap Cana o nei dintorni.
Enter the place and city, tap Search and choose a result for each point.~Saisissez le lieu et la ville, touchez Rechercher et choisissez un résultat pour chaque point.~Geben Sie Ort und Stadt ein, tippen Sie auf Suchen und wählen Sie für jeden Punkt ein Ergebnis.~Inserisci luogo e città, tocca Cerca e scegli un risultato per ogni punto.
Ask about pricing, availability and payment options on WhatsApp.~Renseignez-vous sur les prix, les disponibilités et les moyens de paiement sur WhatsApp.~Fragen Sie über WhatsApp nach Preisen, Verfügbarkeit und Zahlungsarten.~Chiedi prezzi, disponibilità e metodi di pagamento su WhatsApp.
Per-kilometer rates apply to driving distance.~Le tarif au kilomètre s’applique à la distance par la route.~Der Kilometerpreis gilt für die Straßenentfernung.~La tariffa al chilometro si applica alla distanza su strada.
Get a quote~Obtenir un devis~Angebot anfragen~Richiedi un preventivo
Location is unavailable. Enter the address.~Position indisponible. Saisissez l’adresse.~Standort nicht verfügbar. Geben Sie die Adresse ein.~Posizione non disponibile. Inserisci l’indirizzo.
Finding your location…~Recherche de votre position…~Standort wird gesucht…~Ricerca della posizione…
You’re outside the selected area. Search for an address or change the area.~Vous êtes hors de la zone sélectionnée. Recherchez une adresse ou changez de zone.~Sie sind außerhalb des ausgewählten Gebiets. Suchen Sie eine Adresse oder wechseln Sie das Gebiet.~Sei fuori dalla zona selezionata. Cerca un indirizzo o cambia zona.
Current location added.~Position actuelle ajoutée.~Aktueller Standort hinzugefügt.~Posizione attuale aggiunta.
We couldn’t get your location. Enter the address or check your permissions.~Impossible d’obtenir votre position. Saisissez l’adresse ou vérifiez les autorisations.~Standort konnte nicht ermittelt werden. Geben Sie die Adresse ein oder prüfen Sie die Berechtigungen.~Impossibile ottenere la posizione. Inserisci l’indirizzo o verifica le autorizzazioni.
Hi RUVI, I’d like a quote.~Bonjour RUVI, je souhaite un devis.~Hallo RUVI, ich möchte ein Angebot.~Ciao RUVI, vorrei un preventivo.
Hi RUVI, I’d like to sign up for free as a driver.~Bonjour RUVI, je souhaite m’inscrire gratuitement comme chauffeur.~Hallo RUVI, ich möchte mich kostenlos als Fahrer registrieren.~Ciao RUVI, vorrei registrarmi gratis come conducente.
Area~Zone~Gebiet~Zona
Service~Service~Service~Servizio
Departure~Départ~Abflug~Partenza
Arrival~Arrivée~Ankunft~Arrivo
Baggage or extra details~Bagages ou précisions~Gepäck oder weitere Angaben~Bagagli o altri dettagli
Driving distance~Distance par la route~Straßenentfernung~Distanza su strada
Estimated price~Prix estimé~Geschätzter Preis~Prezzo stimato
Zoom in~Agrandir~Vergrößern~Ingrandisci
Zoom out~Réduire~Verkleinern~Riduci
Sign in to continue.~Connectez-vous pour continuer.~Melden Sie sich an, um fortzufahren.~Accedi per continuare.
We could not find a road route. Check your points or try again.~Aucun itinéraire routier trouvé. Vérifiez les points ou réessayez.~Keine Straßenroute gefunden. Prüfen Sie die Punkte oder versuchen Sie es erneut.~Nessun percorso su strada trovato. Controlla i punti o riprova.
Your location is outside your service area.~Votre position est hors de votre zone de service.~Ihr Standort liegt außerhalb Ihres Einsatzgebiets.~La tua posizione è fuori dalla zona di servizio.
Allow location access and try again.~Autorisez l’accès à la position, puis réessayez.~Erlauben Sie den Standortzugriff und versuchen Sie es erneut.~Consenti l’accesso alla posizione e riprova.
Your price expired. Refresh the quote.~Le prix a expiré. Actualisez le devis.~Der Preis ist abgelaufen. Aktualisieren Sie das Angebot.~Il prezzo è scaduto. Aggiorna il preventivo.
Wait a few seconds and try again.~Attendez quelques secondes, puis réessayez.~Warten Sie einige Sekunden und versuchen Sie es erneut.~Attendi qualche secondo e riprova.
You already have an active ride.~Vous avez déjà un trajet actif.~Sie haben bereits eine aktive Fahrt.~Hai già una corsa attiva.
The ride status changed. Check the latest details.~Le statut du trajet a changé. Consultez les dernières informations.~Der Fahrtstatus hat sich geändert. Prüfen Sie die aktuellen Details.~Lo stato della corsa è cambiato. Controlla i dettagli aggiornati.
Go online and refresh your location.~Mettez-vous en ligne et actualisez votre position.~Gehen Sie online und aktualisieren Sie Ihren Standort.~Vai online e aggiorna la posizione.
RUVI still needs to approve your profile.~RUVI doit encore approuver votre profil.~RUVI muss Ihr Profil noch freigeben.~RUVI deve ancora approvare il tuo profilo.
Check the information you entered.~Vérifiez les informations saisies.~Prüfen Sie Ihre Eingaben.~Controlla i dati inseriti.
The service is currently unavailable. Try again.~Le service est indisponible. Réessayez.~Der Service ist derzeit nicht verfügbar. Versuchen Sie es erneut.~Il servizio non è disponibile. Riprova.
Your total is calculated for the selected route.~Votre total est calculé pour l’itinéraire sélectionné.~Ihr Gesamtpreis wird für die gewählte Route berechnet.~Il totale viene calcolato per il percorso selezionato.
Displayed fares are estimates where available.~Les tarifs affichés sont des estimations, lorsqu’elles sont disponibles.~Angezeigte Preise sind, sofern verfügbar, Schätzwerte.~Le tariffe mostrate sono stime, quando disponibili.
Automatic booking is not enabled yet for this area and vehicle.~La réservation automatique n’est pas encore ouverte pour cette zone et ce véhicule.~Automatische Buchung ist für dieses Gebiet und Fahrzeug noch nicht freigeschaltet.~La prenotazione automatica non è ancora disponibile per questa zona e questo veicolo.
Checking ride availability…~Vérification des disponibilités…~Fahrtverfügbarkeit wird geprüft…~Verifica della disponibilità…
Ride total. Valid for five minutes.~Total du trajet valable cinq minutes.~Fahrtpreis, fünf Minuten gültig.~Totale della corsa valido cinque minuti.
Calculating price…~Calcul du prix…~Preis wird berechnet…~Calcolo del prezzo…
Pay in cash when the ride ends.~Payez en espèces à la fin du trajet.~Am Ende der Fahrt bar bezahlen.~Paga in contanti al termine della corsa.
Cancel this ride?~Annuler ce trajet ?~Diese Fahrt stornieren?~Annullare questa corsa?
Go offline~Se mettre hors ligne~Offline gehen~Vai offline
Go online~Se mettre en ligne~Online gehen~Vai online
Profile approved. Automatic rides are not enabled for your area or vehicle yet.~Profil approuvé. Les trajets automatiques ne sont pas encore ouverts pour votre zone ou votre véhicule.~Profil freigegeben. Automatische Fahrten sind für Ihr Gebiet oder Fahrzeug noch nicht freigeschaltet.~Profilo approvato. Le corse automatiche non sono ancora attive per la tua zona o il tuo veicolo.
Online. Keep RUVI open to share your location and receive requests.~Vous êtes en ligne. Gardez RUVI ouvert pour partager votre position et recevoir des demandes.~Sie sind online. Lassen Sie RUVI geöffnet, um Ihren Standort zu teilen und Anfragen zu erhalten.~Sei online. Tieni RUVI aperto per condividere la posizione e ricevere richieste.
Updating location…~Actualisation de la position…~Standort wird aktualisiert…~Aggiornamento della posizione…
You are offline.~Vous êtes hors ligne.~Sie sind offline.~Sei offline.
Registration received. RUVI needs to approve your profile.~Inscription reçue. RUVI doit valider votre profil.~Registrierung erhalten. RUVI muss Ihr Profil noch freigeben.~Registrazione ricevuta. RUVI deve approvare il tuo profilo.
Accept~Accepter~Annehmen~Accetta
Decline~Refuser~Ablehnen~Rifiuta
I arrived at pickup~Je suis au point de départ~Am Abholort angekommen~Sono al punto di partenza
Start ride~Démarrer le trajet~Fahrt starten~Avvia corsa
Finish and confirm cash received~Terminer et confirmer le paiement en espèces~Fahrt beenden und Barzahlung bestätigen~Termina e conferma il pagamento in contanti
New ride nearby~Nouveau trajet à proximité~Neue Fahrt in der Nähe~Nuova corsa nelle vicinanze
Assigned ride~Trajet attribué~Zugewiesene Fahrt~Corsa assegnata
Open route to destination ↗~Ouvrir l’itinéraire vers la destination ↗~Route zum Ziel öffnen ↗~Apri il percorso verso la destinazione ↗
Open route to pickup ↗~Ouvrir l’itinéraire vers le départ ↗~Route zum Abholort öffnen ↗~Apri il percorso verso la partenza ↗
Did you receive the full cash payment?~Avez-vous reçu le paiement intégral en espèces ?~Haben Sie den gesamten Betrag bar erhalten?~Hai ricevuto l’intero pagamento in contanti?
Waiting for a recent driver location.~En attente de la position du chauffeur.~Aktueller Fahrerstandort wird abgewartet.~In attesa di una posizione aggiornata del conducente.
Estimated pickup: ~Prise en charge estimée : ~Geschätzte Abholung: ~Arrivo previsto:\u0020
Driver location updated. Calculating pickup route…~Position du chauffeur actualisée. Calcul de l’itinéraire vers le départ…~Fahrerstandort aktualisiert. Anfahrt wird berechnet…~Posizione del conducente aggiornata. Calcolo del percorso verso la partenza…
Driver~Chauffeur~Fahrer~Conducente
Location is available. The road route could not be refreshed.~La position est disponible. L’itinéraire n’a pas pu être actualisé.~Standort verfügbar. Die Route konnte nicht aktualisiert werden.~Posizione disponibile. Impossibile aggiornare il percorso.
Finding a nearby driver…~Recherche d’un chauffeur à proximité…~Fahrer in der Nähe wird gesucht…~Ricerca di un conducente nelle vicinanze…
Waiting for a driver to accept…~En attente de l’acceptation d’un chauffeur…~Warten auf die Annahme durch einen Fahrer…~In attesa che un conducente accetti…
Your driver is on the way~Votre chauffeur est en route~Ihr Fahrer ist unterwegs~Il conducente è in arrivo
Your driver has arrived~Votre chauffeur est arrivé~Ihr Fahrer ist angekommen~Il conducente è arrivato
Ride in progress~Trajet en cours~Fahrt läuft~Corsa in corso
Ride completed~Trajet terminé~Fahrt abgeschlossen~Corsa completata
We could not find an available driver. You can request another ride.~Aucun chauffeur disponible. Vous pouvez demander un autre trajet.~Kein verfügbarer Fahrer gefunden. Sie können eine neue Fahrt anfragen.~Nessun conducente disponibile. Puoi richiedere un’altra corsa.
Ride cancelled~Trajet annulé~Fahrt storniert~Corsa annullata
Cash received~Espèces reçues~Bargeld erhalten~Contanti ricevuti
Cash~Espèces~Bargeld~Contanti
Choose a valid currency code, such as EUR or GBP.~Choisissez un code de devise valide, par exemple EUR ou GBP.~Wählen Sie einen gültigen Währungscode wie EUR oder GBP.~Scegli un codice valuta valido, come EUR o GBP.
Enter a valid subtotal and delivery fee, and a group of 2 to 20 people.~Saisissez un sous-total et des frais de livraison valides, ainsi qu’un groupe de 2 à 20 personnes.~Geben Sie eine gültige Zwischensumme, Lieferkosten und eine Gruppengröße von 2 bis 20 Personen ein.~Inserisci un subtotale e un costo di consegna validi e un gruppo da 2 a 20 persone.
Delivery on the House~Livraison offerte~Gratislieferung~Consegna offerta
Delivery in ~Livraison à ~Lieferung in ~Consegna a\u0020
Local delivery~Livraison locale~Lokale Lieferung~Consegna locale
Shared delivery~Livraison partagée~Gemeinsame Lieferung~Consegna condivisa
Enter a valid subtotal, distance and delivery fee.~Saisissez un sous-total, une distance et des frais de livraison valides.~Geben Sie eine gültige Zwischensumme, Entfernung und Lieferkosten ein.~Inserisci un subtotale, una distanza e un costo di consegna validi.
Enter a valid subtotal and distance.~Saisissez un sous-total et une distance valides.~Geben Sie eine gültige Zwischensumme und Entfernung ein.~Inserisci un subtotale e una distanza validi.
Delivery estimate at {rate}.~Livraison estimée à {rate}.~Geschätzte Lieferkosten von {rate}.~Consegna stimata a {rate}.
Total using the example delivery fee you entered.~Total selon les frais de livraison d’exemple saisis.~Gesamtpreis mit den eingegebenen Beispiel-Lieferkosten.~Totale con il costo di consegna di esempio inserito.
The offer covers deliveries up to 3 km.~L’offre couvre les livraisons jusqu’à 3 km.~Das Angebot gilt für Lieferungen bis zu 3 km.~L’offerta vale per consegne fino a 3 km.
Add {amount} to unlock free delivery.~Ajoutez {amount} pour bénéficier de la livraison gratuite.~Ab weiteren {amount} ist die Lieferung gratis.~Aggiungi {amount} per ottenere la consegna gratuita.
In this example, delivery is on the house!~Dans cet exemple, la livraison est offerte !~In diesem Beispiel ist die Lieferung gratis!~In questo esempio la consegna è offerta!
Explore with RUVI~Explorez avec RUVI~Mit RUVI entdecken~Esplora con RUVI
Things to do~Idées de sorties~Freizeit und Ausflüge~Cose da fare
Things to do ↗~Idées de sorties ↗~Freizeit und Ausflüge ↗~Cose da fare ↗
Choose a city and a type of outing to discover places on Google Maps.~Choisissez une ville et un type de sortie pour découvrir des lieux dans Google Maps.~Wählen Sie eine Stadt und eine Freizeitaktivität aus, um Orte in Google Maps zu entdecken.~Scegli una città e un tipo di attività per trovare luoghi su Google Maps.
E.g. Bávaro or Paris, France~Ex. Bávaro ou Paris, France~Z. B. Bávaro oder Paris, Frankreich~Es. Bávaro o Parigi, Francia
Type of outing~Type de sortie~Art der Freizeitaktivität~Tipo di attività
Tourist attractions~Attractions touristiques~Sehenswürdigkeiten~Attrazioni turistiche
Beaches~Plages~Strände~Spiagge
Parks and outdoor activities~Parcs et activités de plein air~Parks und Aktivitäten im Freien~Parchi e attività all’aperto
Amusement parks~Parcs d’attractions~Freizeitparks~Parchi divertimento
Restaurants and cafés~Restaurants et cafés~Restaurants und Cafés~Ristoranti e caffè
Museums and culture~Musées et culture~Museen und Kultur~Musei e cultura
Live music and shows~Musique live et spectacles~Live-Musik und Shows~Musica dal vivo e spettacoli
Find places in Google Maps ↗~Chercher des lieux dans Google Maps ↗~Orte in Google Maps suchen ↗~Cerca luoghi su Google Maps ↗
Explore places in Google Maps~Découvrir des lieux dans Google Maps~Orte in Google Maps entdecken~Esplora luoghi su Google Maps
Find beaches, parks, restaurants and more.~Trouvez des plages, des parcs, des restaurants et plus encore.~Finden Sie Strände, Parks, Restaurants und mehr.~Trova spiagge, parchi, ristoranti e altro ancora.
Preferred payment method~Mode de paiement préféré~Bevorzugte Zahlungsart~Metodo di pagamento preferito
Credit or debit card~Carte de crédit ou de débit~Kredit- oder Debitkarte~Carta di credito o di debito
Pay by card~Payer par carte~Mit Karte bezahlen~Paga con carta
Card payment is unavailable in this area.~Le paiement par carte n’est pas disponible dans cette zone.~Kartenzahlung ist in diesem Gebiet nicht verfügbar.~Il pagamento con carta non è disponibile in questa zona.
Pay by card during the ride from My ride.~Payez par carte pendant le trajet depuis Mon trajet.~Bezahlen Sie während der Fahrt unter Meine Fahrt mit Karte.~Paga con carta durante la corsa da La mia corsa.
Finish ride~Terminer le trajet~Fahrt beenden~Termina la corsa
Card payment confirmed~Paiement par carte confirmé~Kartenzahlung bestätigt~Pagamento con carta confermato
Card · Payment pending~Carte · Paiement en attente~Karte · Zahlung ausstehend~Carta · Pagamento in attesa
Discover local venues, tours and experiences.~Découvrez des lieux, visites et expériences locales.~Entdecken Sie lokale Orte, Touren und Erlebnisse.~Scopri locali, tour ed esperienze del posto.
List your venue or experience ↗~Inscrire votre établissement ou expérience ↗~Ort oder Erlebnis eintragen ↗~Registra il tuo locale o la tua esperienza ↗
E.g. Bávaro or Paris~Ex. Bávaro ou Paris~Z. B. Bávaro oder Paris~Es. Bávaro o Parigi
All outings~Toutes les sorties~Alle Aktivitäten~Tutte le attività
Tours and experiences~Visites et expériences~Touren und Erlebnisse~Tour ed esperienze
Nightclubs~Discothèques~Nachtclubs~Discoteche
Other experiences~Autres expériences~Weitere Erlebnisse~Altre esperienze
Search in RUVI~Rechercher dans RUVI~In RUVI suchen~Cerca in RUVI
For businesses and experience providers~Pour les établissements et prestataires d’expériences~Für Betriebe und Erlebnisanbieter~Per locali e organizzatori di esperienze
List your venue or experience~Inscrivez votre établissement ou expérience~Ort oder Erlebnis eintragen~Registra il tuo locale o la tua esperienza
Send your listing for review. Once approved, activate a monthly membership to appear in the RUVI directory.~Envoyez votre fiche pour examen. Une fois approuvée, activez un abonnement mensuel pour figurer dans l’annuaire RUVI.~Reichen Sie Ihren Eintrag zur Prüfung ein. Nach der Freigabe aktivieren Sie ein Monatsabo für das RUVI-Verzeichnis.~Invia la scheda per la revisione. Dopo l’approvazione attiva un abbonamento mensile per comparire nella directory RUVI.
Sign in to submit a listing~Connectez-vous pour envoyer une fiche~Melden Sie sich an, um einen Eintrag einzureichen~Accedi per inviare una scheda
Venue or experience name~Nom du lieu ou de l’expérience~Name des Ortes oder Erlebnisses~Nome del locale o dell’esperienza
Address or meeting point~Adresse ou point de rendez-vous~Adresse oder Treffpunkt~Indirizzo o punto d’incontro
Contact phone for RUVI review~Téléphone de contact pour la vérification RUVI~Kontakttelefon für die RUVI-Prüfung~Telefono di contatto per la verifica RUVI
Tell visitors what they can do~Dites aux visiteurs ce qu’ils peuvent faire~Beschreiben Sie, was Besucher unternehmen können~Spiega ai visitatori cosa possono fare
Send for review~Envoyer pour examen~Zur Prüfung senden~Invia per la revisione
Start a new listing~Créer une autre fiche~Weiteren Eintrag erstellen~Crea un’altra scheda
My listings~Mes fiches~Meine Einträge~Le mie schede
Review listings~Examiner les fiches~Einträge prüfen~Controlla le schede
Listing sent. We will review it before enabling membership.~Fiche envoyée. Nous l’examinerons avant d’activer l’abonnement.~Eintrag gesendet. Wir prüfen ihn, bevor das Abo aktiviert werden kann.~Scheda inviata. La esamineremo prima di abilitare l’abbonamento.
Listing status updated.~Statut de la fiche mis à jour.~Status des Eintrags aktualisiert.~Stato della scheda aggiornato.
There are no active listings for this search yet.~Aucune fiche active pour cette recherche pour le moment.~Für diese Suche gibt es noch keine aktiven Einträge.~Non ci sono ancora schede attive per questa ricerca.
Searching the directory…~Recherche dans l’annuaire…~Verzeichnis wird durchsucht…~Ricerca nella directory…
Check the details and try again.~Vérifiez les informations et réessayez.~Prüfen Sie die Angaben und versuchen Sie es erneut.~Controlla i dati e riprova.
The status changed. Refresh the page to see the latest listing.~Le statut a changé. Actualisez la page pour voir la fiche à jour.~Der Status hat sich geändert. Aktualisieren Sie die Seite für den aktuellen Eintrag.~Lo stato è cambiato. Aggiorna la pagina per vedere la scheda più recente.
We could not complete the request. Try again.~Impossible de traiter la demande. Réessayez.~Die Anfrage konnte nicht abgeschlossen werden. Versuchen Sie es erneut.~Non siamo riusciti a completare la richiesta. Riprova.
Monthly memberships are not open yet.~Les abonnements mensuels ne sont pas encore disponibles.~Monatsabos sind noch nicht verfügbar.~Gli abbonamenti mensili non sono ancora disponibili.
Membership status refreshed.~Statut de l’abonnement actualisé.~Abostatus aktualisiert.~Stato dell’abbonamento aggiornato.
See location ↗~Voir le lieu ↗~Standort ansehen ↗~Vedi posizione ↗
Pending review~En attente d’examen~Prüfung ausstehend~In attesa di revisione
Listing not published~Fiche non publiée~Eintrag nicht veröffentlicht~Scheda non pubblicata
Published · Active membership~Publiée · Abonnement actif~Veröffentlicht · Abo aktiv~Pubblicata · Abbonamento attivo
Approved · Membership pending~Approuvée · Abonnement en attente~Freigegeben · Abo ausstehend~Approvata · Abbonamento in attesa
Edit listing~Modifier la fiche~Eintrag bearbeiten~Modifica scheda
Manage membership~Gérer l’abonnement~Abo verwalten~Gestisci abbonamento
Activate monthly membership~Activer l’abonnement mensuel~Monatsabo aktivieren~Attiva l’abbonamento mensile
Approve~Approuver~Freigeben~Approva
Do not publish~Ne pas publier~Nicht veröffentlichen~Non pubblicare
Travel~Voyages~Reisen~Viaggi
Flight search~Recherche de vols~Flugsuche~Ricerca voli
Flight search ↗~Recherche de vols ↗~Flugsuche ↗~Ricerca voli ↗
Adults~Adultes~Erwachsene~Adulti
Cabin class~Classe de voyage~Reiseklasse~Classe di viaggio
Economy~Économique~Economy~Economica
Premium economy~Économique premium~Premium Economy~Economica premium
Business class~Affaires~Business Class~Business
First class~Première classe~First Class~Prima classe
Nonstop only~Vols directs uniquement~Nur Direktflüge~Solo voli diretti
Yes~Oui~Ja~Sì
Search flights~Rechercher des vols~Flüge suchen~Cerca voli
Flight search and booking in RUVI are coming soon.~La recherche et la réservation de vols dans RUVI seront bientôt disponibles.~Flugsuche und Buchung in RUVI sind bald verfügbar.~La ricerca e la prenotazione dei voli su RUVI saranno presto disponibili.
Search by city or airport code. Prices cover all adults on the trip.~Recherchez par ville ou code d’aéroport. Les prix incluent tous les adultes du voyage.~Suchen Sie nach Stadt oder Flughafencode. Die Preise gelten für alle Erwachsenen der Reise.~Cerca per città o codice aeroporto. I prezzi includono tutti gli adulti del viaggio.
Choose two different airports or cities and check the dates.~Choisissez deux aéroports ou villes différents et vérifiez les dates.~Wählen Sie zwei verschiedene Flughäfen oder Städte und prüfen Sie die Daten.~Scegli due aeroporti o città diversi e controlla le date.
Searching for flights…~Recherche de vols…~Flüge werden gesucht…~Ricerca voli…
No flights found for this search. Try other dates or allow connections.~Aucun vol trouvé. Essayez d’autres dates ou autorisez les correspondances.~Keine Flüge gefunden. Versuchen Sie andere Daten oder erlauben Sie Umstiege.~Nessun volo trovato. Prova altre date o consenti gli scali.
Wait a few seconds before searching again.~Attendez quelques secondes avant de relancer la recherche.~Warten Sie einige Sekunden vor der nächsten Suche.~Attendi qualche secondo prima di cercare di nuovo.
We could not check flights. Please try again.~Impossible de consulter les vols. Réessayez.~Flüge konnten nicht abgerufen werden. Versuchen Sie es erneut.~Impossibile consultare i voli. Riprova.
Provider prices are subject to availability. Times are local to each airport.~Les prix du fournisseur dépendent de la disponibilité. Les horaires sont ceux de chaque aéroport.~Anbieterpreise gelten je nach Verfügbarkeit. Zeiten sind Ortszeiten der Flughäfen.~I prezzi del fornitore sono soggetti a disponibilità. Gli orari sono locali per ciascun aeroporto.
Airline~Compagnie aérienne~Fluggesellschaft~Compagnia aerea
Connections: {count}~Correspondances : {count}~Umstiege: {count}~Scali: {count}
Nonstop flight~Vol direct~Direktflug~Volo diretto
Personalized service~Service personnalisé~Persönlicher Service~Servizio personalizzato
Close menu~Fermer le menu~Menü schließen~Chiudi il menu
Your service region~Votre région de service~Ihre Serviceregion~La tua zona di servizio
Getting around and deliveries~Déplacements et livraisons~Mobilität und Lieferungen~Mobilità e consegne
Travel and experiences~Voyages et expériences~Reisen und Erlebnisse~Viaggi ed esperienze
Transfers~Transferts~Transfers~Trasferimenti
RUVI Delivery~RUVI Delivery~RUVI Delivery~RUVI Delivery
Car rental in Punta Cana~Location de voiture à Punta Cana~Mietwagen in Punta Cana~Noleggio auto a Punta Cana
Region suggested from your connection. You can change it.~Région suggérée d’après votre connexion. Vous pouvez la modifier.~Die Region wurde anhand Ihrer Verbindung vorgeschlagen. Sie können sie ändern.~Regione suggerita in base alla connessione. Puoi cambiarla.
Choose the region where you need the service.~Choisissez la région où vous avez besoin du service.~Wählen Sie die Region, in der Sie den Service benötigen.~Scegli la regione in cui ti serve il servizio.
Ask RUVI~Demandez à RUVI~RUVI fragen~Chiedi a RUVI
RUVI Assistant~Assistant RUVI~RUVI-Assistent~Assistente RUVI
Ask about a RUVI service and open the right section here.~Posez une question sur un service RUVI et ouvrez ici la section adaptée.~Fragen Sie nach einem RUVI-Service und öffnen Sie hier den passenden Bereich.~Fai una domanda su un servizio RUVI e apri qui la sezione giusta.
What do you need?~De quoi avez-vous besoin ?~Was brauchen Sie?~Di cosa hai bisogno?
E.g. Where can I find nightclubs in Bávaro?~Ex. Où trouver des discothèques à Bávaro ?~Z. B. Wo finde ich Nachtclubs in Bávaro?~Es. Dove trovo discoteche a Bávaro?
Ask~Demander~Fragen~Chiedi
Quick topics~Sujets rapides~Schnellauswahl~Argomenti rapidi
Rides~Trajets~Fahrten~Corse
Open the RUVI flights section.~Ouvrez la section vols de RUVI.~Öffnen Sie den Flugbereich von RUVI.~Apri la sezione voli di RUVI.
Enter pickup and destination to see the available estimate.~Indiquez le départ et la destination pour voir l’estimation disponible.~Geben Sie Abholort und Ziel ein, um die verfügbare Schätzung zu sehen.~Indica partenza e destinazione per vedere la stima disponibile.
Enter the route, date and number of travelers.~Indiquez l’itinéraire, la date et le nombre de voyageurs.~Geben Sie Route, Datum und Anzahl der Reisenden ein.~Indica percorso, data e numero di viaggiatori.
Explore the delivery simulator, RUVI meeting points and options in your region.~Découvrez le simulateur, les points de rendez-vous RUVI et les options dans votre région.~Entdecken Sie den Liefersimulator, RUVI-Treffpunkte und Optionen in Ihrer Region.~Esplora il simulatore, i punti d’incontro RUVI e le opzioni nella tua zona.
See how much each person would pay when sharing a delivery.~Estimez la part de chacun pour une livraison partagée.~Berechnen Sie den Anteil pro Person bei einer gemeinsamen Lieferung.~Calcola quanto pagherebbe ogni persona per una consegna condivisa.
Enter the route and what you need to send to inquire about the service.~Indiquez l’itinéraire et le contenu à envoyer pour vous renseigner.~Geben Sie die Route und den Versandinhalt für eine Anfrage an.~Indica il percorso e cosa vuoi spedire per chiedere informazioni.
Choose a city and activity to find nightclubs, parks, tours and more.~Choisissez une ville et une activité pour trouver des discothèques, des parcs, des visites et plus encore.~Wählen Sie eine Stadt und Aktivität, um Nachtclubs, Parks, Touren und mehr zu finden.~Scegli una città e un’attività per trovare discoteche, parchi, tour e altro.
Choose dates and a pickup location to request a quote in Punta Cana.~Choisissez les dates et le lieu de prise en charge pour un devis à Punta Cana.~Wählen Sie Datum und Abholort für ein Mietwagenangebot in Punta Cana.~Scegli date e luogo di ritiro per un preventivo a Punta Cana.
Sign in and submit your venue details for review.~Connectez-vous et soumettez les informations de votre établissement pour examen.~Melden Sie sich an und reichen Sie die Angaben zum Betrieb zur Prüfung ein.~Accedi e invia i dati del tuo locale per la revisione.
Sign up as a driver~Inscrivez-vous comme chauffeur~Als Fahrer registrieren~Registrati come conducente
Sign in to submit your driver registration.~Connectez-vous pour envoyer votre inscription chauffeur.~Melden Sie sich an, um Ihre Fahrerregistrierung einzureichen.~Accedi per inviare la registrazione come conducente.
View options in the quote form~Voir les options dans le formulaire de devis~Optionen im Angebotsformular ansehen~Vedi le opzioni nel modulo di preventivo
Cash and card options depend on the service and area.~Les options espèces et carte dépendent du service et de la zone.~Bar- und Kartenzahlung hängen von Service und Gebiet ab.~Il pagamento in contanti o con carta dipende dal servizio e dalla zona.
Go to support~Ouvrir l’assistance~Zum Support~Vai all’assistenza
You can find the RUVI support link at the bottom of the page.~Le lien d’assistance RUVI se trouve en bas de la page.~Den Link zum RUVI-Support finden Sie unten auf der Seite.~Il link all’assistenza RUVI è in fondo alla pagina.
Finding the right section…~Recherche de la section adaptée…~Passender Bereich wird gesucht…~Ricerca della sezione giusta…
Looking for flights, a transfer, delivery, parcels or things to do? Try the service name.~Vous cherchez un vol, un transfert, une livraison, un envoi de colis ou une sortie ? Essayez le nom du service.~Suchen Sie Flüge, Transfers, Lieferungen, Paketversand oder Freizeitaktivitäten? Geben Sie den Servicenamen ein.~Cerchi voli, un trasferimento, consegne, spedizioni o cose da fare? Prova con il nome del servizio.
Questions are unavailable right now. You can use the buttons above.~Les questions sont indisponibles pour le moment. Utilisez les boutons ci-dessus.~Fragen sind derzeit nicht verfügbar. Nutzen Sie die Schaltflächen oben.~Le domande non sono disponibili al momento. Usa i pulsanti qui sopra.
Choose the section you need.~Choisissez la section qui vous convient.~Wählen Sie den passenden Bereich.~Scegli la sezione che ti serve.
RUVI directory~Annuaire RUVI~RUVI-Verzeichnis~Elenco RUVI
Places and experiences directory~Annuaire des lieux et activités~Verzeichnis für Orte und Erlebnisse~Elenco di luoghi ed esperienze
Find places to stay, properties, cinemas and things to do in your city.~Trouvez des hébergements, des biens immobiliers, des cinémas et des activités dans votre ville.~Finden Sie Unterkünfte, Immobilien, Kinos und Aktivitäten in Ihrer Stadt.~Trova alloggi, immobili, cinema e attività nella tua città.
Category~Catégorie~Kategorie~Categoria
All categories~Toutes les catégories~Alle Kategorien~Tutte le categorie
Hotels~Hôtels~Hotels~Hotel
Motels~Motels~Motels~Motel
Real estate~Immobilier~Immobilien~Immobili
Cinemas~Cinémas~Kinos~Cinema
Describe the place, property or experience~Décrivez le lieu, le bien ou l’activité~Beschreiben Sie den Ort, die Immobilie oder das Erlebnis~Descrivi il luogo, l’immobile o l’esperienza
Get a ride quote here~Estimer le trajet jusqu’ici~Fahrpreis hierher berechnen~Calcola il prezzo per arrivare qui
Choose a city to find hotels in the directory.~Choisissez une ville pour trouver des hôtels dans l’annuaire.~Wählen Sie eine Stadt, um Hotels im Verzeichnis zu finden.~Scegli una città per trovare gli hotel nell’elenco.
Choose a city to find motels in the directory.~Choisissez une ville pour trouver des motels dans l’annuaire.~Wählen Sie eine Stadt, um Motels im Verzeichnis zu finden.~Scegli una città per trovare i motel nell’elenco.
Browse property listings by city.~Consultez les annonces immobilières par ville.~Durchsuchen Sie Immobilienangebote nach Stadt.~Consulta gli annunci immobiliari per città.
Find cinemas and see their locations.~Trouvez des cinémas et consultez leur emplacement.~Finden Sie Kinos und sehen Sie, wo sie liegen.~Trova i cinema e vedi dove si trovano.
Real estate agencies~Agences immobilières~Immobilienagenturen~Agenzie immobiliari
Where to?~Où allez-vous ?~Wohin soll es gehen?~Dove vuoi andare?
Add your pickup and destination to see an estimate.~Indiquez le départ et la destination pour obtenir une estimation.~Geben Sie Start und Ziel ein, um den Preis zu schätzen.~Inserisci partenza e destinazione per vedere un preventivo.
Mobility and services~Mobilité et services~Mobilität und Dienste~Mobilità e servizi
Explore~Explorer~Entdecken~Esplora
Home~Accueil~Startseite~Home
Main navigation~Navigation principale~Hauptnavigation~Navigazione principale
Services~Services~Dienste~Servizi
Activity~Activité~Aktivität~Attività
Account~Compte~Konto~Account
Support~Assistance~Support~Assistenza
Service region~Région du service~Serviceregion~Regione del servizio
Travel and stays~Voyages et hébergements~Reisen und Unterkünfte~Viaggi e alloggi
Explore your city~Explorez votre ville~Entdecken Sie Ihre Stadt~Esplora la tua città
You have no active ride to track here.~Vous n’avez aucun trajet en cours à suivre ici.~Sie haben keine laufende Fahrt, die Sie hier verfolgen können.~Non hai corse in corso da seguire qui.
Plan your ride~Planifiez votre trajet~Plane deine Fahrt~Pianifica la corsa
Set pickup on map~Placer le départ sur la carte~Abholort auf der Karte markieren~Segna la partenza sulla mappa
Set drop-off on map~Placer l’arrivée sur la carte~Ziel auf der Karte markieren~Segna la destinazione sulla mappa
Move the map until the crosshair is over your location.~Déplacez la carte pour centrer le repère sur votre point.~Verschiebe die Karte, bis das Fadenkreuz über dem Ort liegt.~Sposta la mappa finché il mirino è sul punto scelto.
Use this point~Utiliser ce point~Diesen Punkt verwenden~Usa questo punto
Cancel~Annuler~Abbrechen~Annulla
Choose a point within the selected region.~Choisissez un point dans la région sélectionnée.~Wähle einen Punkt in der ausgewählten Region.~Scegli un punto nella regione selezionata.
Review example order~Vérifier la commande d’exemple~Beispielbestellung prüfen~Rivedi l’ordine di esempio
Review your order~Vérifiez votre commande~Prüfe deine Bestellung~Rivedi il tuo ordine
Back~Retour~Zurück~Indietro
How to get your order~Comment recevoir votre commande~So erhältst du deine Bestellung~Come ricevere l’ordine
Home delivery~Livraison à domicile~Lieferung nach Hause~Consegna a domicilio
Pickup from the shop~À emporter~Abholung im Geschäft~Ritiro in negozio
Delivery address (example)~Adresse de livraison (exemple)~Lieferadresse (Beispiel)~Indirizzo di consegna (esempio)
Delivery instructions (optional)~Instructions de livraison (facultatif)~Lieferhinweise (optional)~Istruzioni di consegna (facoltative)
Delivery options~Options de livraison~Lieferoptionen~Opzioni di consegna
Standard delivery~Livraison standard~Standardlieferung~Consegna standard
Priority delivery~Livraison prioritaire~Prioritätslieferung~Consegna prioritaria
Add an example surcharge~Ajoutez un supplément d’exemple~Beispielzuschlag hinzufügen~Aggiungi un supplemento di esempio
Schedule delivery~Planifier la livraison~Lieferung planen~Programma la consegna
Choose a date and time~Choisissez une date et une heure~Wähle Datum und Uhrzeit~Scegli data e ora
Example priority surcharge~Supplément prioritaire d’exemple~Beispiel für einen Prioritätszuschlag~Supplemento prioritario di esempio
Delivery date and time~Date et heure de livraison~Datum und Uhrzeit der Lieferung~Data e ora di consegna
You would pick up your order at the shop.~Vous retireriez votre commande en magasin.~Du würdest deine Bestellung im Geschäft abholen.~Ritireresti l’ordine in negozio.
A delivery estimate is unavailable with the current example details. You can try pickup or edit the example.~Aucune estimation de livraison pour cet exemple. Essayez le retrait ou modifiez l’exemple.~Für dieses Beispiel ist kein Lieferpreis verfügbar. Wähle Abholung oder ändere das Beispiel.~Per questo esempio manca una stima di consegna. Prova il ritiro o modifica l’esempio.
Simulation complete. No order was sent and no payment was collected.~Simulation terminée. Aucune commande envoyée et aucun paiement prélevé.~Simulation abgeschlossen. Es wurde nichts bestellt oder bezahlt.~Simulazione completata. Nessun ordine inviato e nessun pagamento riscosso.
Confirm simulation~Confirmer la simulation~Simulation bestätigen~Conferma la simulazione
Enter an example address.~Saisissez une adresse d’exemple.~Gib eine Beispieladresse ein.~Inserisci un indirizzo di esempio.
Choose a future date and time.~Choisissez une date et une heure futures.~Wähle Datum und Uhrzeit in der Zukunft.~Scegli data e ora future.
Search in {city}~Chercher à {city}~In {city} suchen~Cerca a {city}
Entertainment and activities~Divertissements et activités~Unterhaltung und Aktivitäten~Intrattenimento e attività
Confirm opening hours with the venue.~Vérifiez les horaires auprès de l’établissement.~Bestätige die Öffnungszeiten beim Anbieter.~Verifica gli orari con il locale.
What can I do tonight in {city}?~Que faire ce soir à {city} ?~Was kann ich heute Abend in {city} unternehmen?~Cosa posso fare stasera a {city}?
E.g. Where can I find cinemas in my city?~Ex. Où trouver des cinémas dans ma ville ?~Z. B. Wo finde ich Kinos in meiner Stadt?~Es. Dove trovo cinema nella mia città?
`.trimStart().trimEnd().split('\n').map((row) => {
  const [en, fr, de, it] = row.split('~');
  return [en, { fr, de, it }];
}));

const countryLanguageGroups = [
  ['DO VE ES MX AR BO CL CO CR CU EC SV GQ GT HN NI PA PY PE PR UY', ['es']],
  ['US GB IE AU NZ JM TT BS BB BZ GY AG DM GD KN LC VC', ['en']],
  ['FR MC GP MQ GF RE YT HT BF BJ CD CF CG CI GA GN ML NE SN TG', ['fr']],
  ['DE AT LI', ['de']],
  ['IT SM VA', ['it']],
  ['CA', ['en', 'fr']],
  ['CH', ['de', 'fr', 'it']],
  ['BE LU', ['fr', 'de']],
];

function automaticLanguage(country, browserLanguages, supported) {
  const preferred = browserLanguages
    .map((tag) => tag.toLowerCase().split('-')[0])
    .filter((code) => Object.hasOwn(supported, code));
  const local = countryLanguageGroups.find(([codes]) => codes.split(' ').includes(country))?.[1];
  if (local) return preferred.find((code) => local.includes(code)) ?? local[0];
  return preferred[0] ?? 'en';
}
