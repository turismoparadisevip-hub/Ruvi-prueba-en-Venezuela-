const http = require('node:http');
const net = require('node:net');
const { spawn } = require('node:child_process');
const port = Number(process.env.PORT || 10000);
const upstreamPort = port + 1;
let closing = false;
let readyTimer;
const child = spawn(process.execPath, ['scripts/serve-render.mjs'], {
  env: { ...process.env, PORT: String(upstreamPort) },
  stdio: 'inherit',
});
const server = http.createServer((request, response) => {
  const path = new URL(request.url, 'http://localhost').pathname;
  if (path === '/signin-with-chatgpt') {
    response.writeHead(302, {
      Location: 'https://ruvi-conductor-venezuela.onrender.com/',
      'Cache-Control': 'no-store',
    });
    response.end();
    return;
  }
  const upstream = http.request({
    hostname: '127.0.0.1', port: upstreamPort,
    path: request.url, method: request.method, headers: request.headers,
  }, incoming => {
    response.writeHead(incoming.statusCode, incoming.headers);
    incoming.pipe(response);
  });
  upstream.setTimeout(30000, () => upstream.destroy());
  upstream.on('error', () => {
    if (response.headersSent) response.destroy();
    else {
      response.writeHead(503, { 'Content-Type': 'text/plain; charset=utf-8', 'Cache-Control': 'no-store' });
      response.end('RUVI se está iniciando. Actualiza la página en unos segundos.');
    }
  });
  request.on('aborted', () => upstream.destroy());
  request.pipe(upstream);
});
const started = Date.now();
function waitForUpstream() {
  if (closing) return;
  const socket = net.connect(upstreamPort, '127.0.0.1');
  socket.once('connect', () => {
    socket.destroy();
    server.listen(port, '0.0.0.0');
  });
  socket.once('error', () => {
    socket.destroy();
    if (Date.now() - started > 60000) {
      child.kill('SIGTERM');
      process.exit(1);
    }
    readyTimer = setTimeout(waitForUpstream, 200);
  });
}
child.on('error', () => process.exit(1));
child.on('exit', code => {
  clearTimeout(readyTimer);
  if (!closing) process.exit(code || 1);
});
process.on('SIGTERM', () => {
  closing = true;
  clearTimeout(readyTimer);
  server.close();
  child.kill('SIGTERM');
  setTimeout(() => process.exit(0), 25000).unref();
});
waitForUpstream();
