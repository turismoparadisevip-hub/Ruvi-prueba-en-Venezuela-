const cacheName = 'ruvi-shell-v96';
const shell = ['./', './languages.js', './app.js', './passenger-auth.js', './assistant.js', './rides.js', './flights.js', './venues.js', './style.css', '/welcome/welcome.css', '/welcome/welcome.js', './ruvi.png'];
const homeUrl = new URL('./', self.registration.scope).href;
const shellUrls = new Set(shell.map((path) => new URL(path, self.registration.scope).href));

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(cacheName).then((cache) => cache.addAll(shell)));
});

self.addEventListener('message', (event) => {
  if (event.data === 'activate-ruvi-update') event.waitUntil(self.skipWaiting());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith('ruvi-shell-') && key !== cacheName).map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  const homeNavigation = request.mode === 'navigate' && url.origin + url.pathname === homeUrl;
  if (!homeNavigation && !shellUrls.has(request.url)) return;
  event.respondWith(fetch(request).catch(async () => {
    const cache = await caches.open(cacheName);
    return (await cache.match(homeNavigation ? homeUrl : request)) || Response.error();
  }));
});
