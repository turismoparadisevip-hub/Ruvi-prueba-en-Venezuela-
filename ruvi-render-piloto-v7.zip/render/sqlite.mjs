import { DatabaseSync } from 'node:sqlite';
import { readdirSync, readFileSync } from 'node:fs';

export function openDatabase(path) {
  const db = new DatabaseSync(path);
  db.exec('PRAGMA busy_timeout = 5000; PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON');
  db.exec('CREATE TABLE IF NOT EXISTS render_migrations (name TEXT PRIMARY KEY)');
  function transaction(work) {
    db.exec('BEGIN IMMEDIATE');
    try {
      const result = work();
      db.exec('COMMIT');
      return result;
    } catch (error) {
      db.exec('ROLLBACK');
      throw error;
    }
  }
  const migrations = new URL('../drizzle/', import.meta.url);
  for (const name of readdirSync(migrations).filter(name => name.endsWith('.sql')).sort()) {
    transaction(() => {
      if (db.prepare('SELECT name FROM render_migrations WHERE name = ?').get(name)) return;
      db.exec(readFileSync(new URL(name, migrations), 'utf8'));
      db.prepare('INSERT INTO render_migrations VALUES (?)').run(name);
    });
  }
  return {
    prepare(query) {
      const statement = db.prepare(query);
      const bind = (...args) => ({
        first: column => {
          const row = statement.get(...args);
          return column === undefined ? row ?? null : row?.[column] ?? null;
        },
        all: () => ({ results: statement.all(...args), success: true }),
        run: () => {
          if (statement.columns().length === 0) {
            return { success: true, meta: statement.run(...args), results: [] };
          }
          const results = statement.all(...args);
          const { changes } = db.prepare('SELECT changes() AS changes').get();
          return { success: true, results, meta: { changes } };
        },
      });
      return { ...bind(), bind };
    },
    batch: statements => transaction(() => statements.map(statement => statement.run())),
  };
}
