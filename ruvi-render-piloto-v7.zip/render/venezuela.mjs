import { createServer } from 'node:http';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import worker from '../dist/server/index.js';
import { openDatabase } from './sqlite.mjs';

const port = Number(process.env.PORT || 10000);
const origin = new URL(process.env.RENDER_EXTERNAL_URL || 'http://localhost:' + port);
if (!process.env.RUVI_DATABASE_PATH) throw new Error('RUVI_DATABASE_PATH is required');
const env = { ...process.env, RUVI_RENDER_PILOT: '1', DB: openDatabase(process.env.RUVI_DATABASE_PATH) };

createServer(async (incoming, outgoing) => {
  try {
    if (!incoming.url?.startsWith('/') || incoming.url.startsWith('//')) {
      outgoing.writeHead(400).end();
      return;
    }
    const url = new URL(incoming.url, origin);
    if (url.origin !== origin.origin) {
      outgoing.writeHead(400).end();
      return;
    }
    if (url.pathname === '/healthz') {
      env.DB.prepare('SELECT 1').first();
      outgoing.writeHead(200).end('ok');
      return;
    }
    if (url.pathname === '/api/places' && incoming.method === 'GET') {
      const query = url.searchParams.get('q')?.trim();
      if (!query || query.length < 3 || query.length > 240) {
        outgoing.writeHead(400).end();
        return;
      }
      const upstream = new URL('https://photon.komoot.io/api/');
      upstream.searchParams.set('q', query);
      upstream.searchParams.set('bbox', '-73.5,0.6,-59.7,15.8');
      upstream.searchParams.set('limit', '10');
      for (const key of ['lat', 'lon']) {
        const value = url.searchParams.get(key);
        if (value && Number.isFinite(Number(value))) upstream.searchParams.set(key, value);
      }
      try {
        const result = await fetch(upstream, { signal: AbortSignal.timeout(7000) });
        if (!result.ok) throw new Error('Geocoder unavailable');
        const data = await result.json();
        outgoing.writeHead(200, { 'content-type': 'application/json', 'cache-control': 'private, no-store' });
        outgoing.end(JSON.stringify(data));
      } catch {
        outgoing.writeHead(502).end();
      }
      return;
    }
    const method = incoming.method;
    const headers = new Headers();
    for (const name of ['authorization', 'content-type', 'cookie', 'origin', 'stripe-signature']) {
      if (typeof incoming.headers[name] === 'string') headers.set(name, incoming.headers[name]);
    }
    const options = { method, headers };
    if (method !== 'GET' && method !== 'HEAD') {
      options.body = Readable.toWeb(incoming);
      options.duplex = 'half';
    }
    const response = await worker.fetch(new Request(url, options), env);
    for (const [name, value] of response.headers) {
      if (name !== 'set-cookie') outgoing.setHeader(name, value);
    }
    const cookies = response.headers.getSetCookie();
    if (cookies.length) outgoing.setHeader('set-cookie', cookies);
    outgoing.writeHead(response.status);
    if (response.body) await pipeline(Readable.fromWeb(response.body), outgoing);
    else outgoing.end();
  } catch {
    if (outgoing.headersSent) outgoing.destroy();
    else outgoing.writeHead(503).end();
  }
}).listen(port);
