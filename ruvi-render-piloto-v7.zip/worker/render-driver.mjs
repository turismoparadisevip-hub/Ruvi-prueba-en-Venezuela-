async function renderDriverBridge(request, env) {
  if (!env.RUVI_RENDER_DRIVER_KEY || !env.DB || request.method !== 'POST') return fail('unavailable', 503);
  const supplied = request.headers.get('Authorization') ?? '';
  const encoder = new TextEncoder();
  const expectedDigest = new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode('Bearer ' + env.RUVI_RENDER_DRIVER_KEY)));
  const suppliedDigest = new Uint8Array(await crypto.subtle.digest('SHA-256', encoder.encode(supplied)));
  let difference = 0;
  for (let index = 0; index < expectedDigest.length; index++) difference |= expectedDigest[index] ^ suppliedDigest[index];
  if (difference) return fail('invalid', 403);
  const raw = await request.text();
  if (raw.length > 160000) return fail('invalid', 413);
  let body;
  try { body = JSON.parse(raw); } catch { return fail('invalid'); }
  if (!body || typeof body !== 'object') return fail('invalid');
  const db = env.DB;
  const now = Date.now();
  const validHash = value => typeof value === 'string' && /^[a-f0-9]{64}$/.test(value);

  if (body.operation === 'gate') {
    if (!validHash(body.key)) return fail('invalid');
    // Persistent rate limits survive Render restarts and apply before password hashing.
    const results = await db.batch([
      sql(db, `
        INSERT INTO ruvi_driver_auth_limits (id, attempts, resets) VALUES (?, 1, ?)
        ON CONFLICT(id) DO UPDATE SET
          attempts = CASE WHEN resets <= ? THEN 1 ELSE attempts + 1 END,
          resets = CASE WHEN resets <= ? THEN excluded.resets ELSE resets END
        RETURNING attempts
      `, body.key, now + 900000, now, now),
      sql(db, `
        INSERT INTO ruvi_driver_auth_limits (id, attempts, resets) VALUES ('global', 1, ?)
        ON CONFLICT(id) DO UPDATE SET
          attempts = CASE WHEN resets <= ? THEN 1 ELSE attempts + 1 END,
          resets = CASE WHEN resets <= ? THEN excluded.resets ELSE resets END
        RETURNING attempts
      `, now + 60000, now, now),
    ]);
    if (results[0].results[0].attempts > 5 || results[1].results[0].attempts > 20) return fail('wait', 429);
    return json({ allowed: true });
  }

  if (body.operation === 'lookup') {
    const account = await sql(db, 'SELECT id, password_hash FROM ruvi_driver_accounts WHERE email = ?', clean(body.email, 254)).first();
    return json({ account });
  }
  if (body.operation === 'signup') {
    const email = clean(body.email, 254);
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
      || typeof body.passwordHash !== 'string'
      || !/^scrypt:[a-f0-9]{32}:[a-f0-9]{128}$/.test(body.passwordHash)) return fail('invalid');
    const id = 'render-driver:' + crypto.randomUUID();
    const result = await sql(db, `
      INSERT INTO ruvi_driver_accounts (id, email, password_hash, created) VALUES (?, ?, ?, ?)
      ON CONFLICT(email) DO NOTHING
    `, id, email, body.passwordHash, now).run();
    return changed(result) ? json({ id }, 201) : fail('account_exists', 409);
  }
  if (body.operation === 'session') {
    if (typeof body.accountId !== 'string' || !validHash(body.tokenHash)) return fail('invalid');
    const results = await db.batch([
      sql(db, 'DELETE FROM ruvi_driver_sessions WHERE expires <= ?', now),
      sql(db, `
        INSERT INTO ruvi_driver_sessions (token_hash, account_id, expires)
        SELECT ?, id, ? FROM ruvi_driver_accounts WHERE id = ?
      `, body.tokenHash, now + 604800000, body.accountId),
    ]);
    return changed(results[1]) ? json({ ok: true }) : fail('invalid');
  }
  if (body.operation === 'logout') {
    if (validHash(body.tokenHash)) await sql(db, 'DELETE FROM ruvi_driver_sessions WHERE token_hash = ?', body.tokenHash).run();
    return json({ ok: true });
  }

  const account = validHash(body.tokenHash) ? await sql(db, `
    SELECT a.id, a.email FROM ruvi_driver_sessions s JOIN ruvi_driver_accounts a ON a.id = s.account_id
    WHERE s.token_hash = ? AND s.expires > ?
  `, body.tokenHash, now).first() : null;
  const allowed = new Set(['group-rides', 'config', 'driver/profile', 'driver/photos', 'status', 'driver/location', 'driver/offline', 'driver/action', 'driver/delivery', 'merchant/profile', 'merchant/register', 'merchant/product', 'merchant/archive', 'merchant/menu', 'merchant/marketplace']);
  const endpoint = typeof body.endpoint === 'string' ? body.endpoint.split('?')[0] : '';
  if (body.operation !== 'api' || !allowed.has(endpoint)) return fail('invalid');
  if (!account && !['config', 'merchant/menu', 'merchant/marketplace'].includes(endpoint)) return fail('signin', 401);
  const origin = new URL(request.url).origin;
  const headers = new Headers({ 'Content-Type': 'application/json', Origin: origin });
  if (account) {
    headers.set('oai-authenticated-user-id', account.id);
    headers.set('oai-authenticated-user-email', account.email);
  }
  const method = ['config', 'driver/profile', 'driver/photos', 'merchant/profile', 'merchant/menu', 'merchant/marketplace'].includes(endpoint) && body.payload === undefined ? 'GET' : 'POST';
  const internal = new Request(origin + '/api/ruvi/' + body.endpoint, {
    method, headers, ...(method === 'POST' ? { body: JSON.stringify(body.payload ?? {}) } : {}),
  });
  return api(internal, env, new URL(internal.url).pathname);
}
