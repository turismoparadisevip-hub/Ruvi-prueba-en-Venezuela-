const venueRegions = ['do', 've', 'eu', 'us'];
const venueCategories = ['tours', 'attractions', 'beaches', 'outdoors', 'amusement', 'food', 'culture', 'music', 'clubs', 'hotels', 'motels', 'properties', 'cinemas', 'shopping', 'other'];
const venueFields = 'id, name, category, region, country, city, address, description, merchant_enrolled';
const venueKey = (text) => text.normalize('NFD').replace(/\p{Diacritic}/gu, '').toLowerCase();
const venueAdmin = (env, email) => Boolean(email && (env.RUVI_VENUE_ADMIN_EMAILS ?? '')
  .split(',').some((value) => value.trim().toLowerCase() === email));
const venueBilling = (env) => Boolean(env.STRIPE_SECRET_KEY && env.STRIPE_WEBHOOK_SECRET
  && /^price_[a-zA-Z0-9]+$/.test(env.RUVI_VENUE_MONTHLY_PRICE_ID ?? ''));

async function venueRead(request, env, path, user, email) {
  if (!env.DB) return fail('unavailable', 503);
  if (path === '/api/ruvi/venues/list') {
    const params = new URL(request.url).searchParams;
    const city = venueKey(clean(params.get('city'), 100));
    const region = params.get('region');
    const category = params.get('category') ?? '';
    const leisure = category === 'leisure';
    if (!venueRegions.includes(region) || (category && !leisure && !venueCategories.includes(category))) return fail('invalid');
    const result = await sql(env.DB, `
      SELECT ${venueFields} FROM ruvi_venues
      WHERE status = 'approved' AND (membership_active = 1 OR merchant_enrolled = 1) AND region = ?
        AND (? = '' OR category = ?)
        AND (? = 0 OR category NOT IN ('hotels', 'motels', 'properties'))
        AND (? = '' OR instr(city_key, ?) > 0)
      ORDER BY updated_at DESC LIMIT 30
    `, region, leisure ? '' : category, category, Number(leisure), city, city).all();
    return json({ venues: result.results });
  }
  if (path === '/api/ruvi/venues/mine') {
    if (!user) return json({ signedIn: false });
    const mine = await sql(env.DB, `
      SELECT ${venueFields}, phone, status, membership_active, stripe_subscription IS NOT NULL AS subscribed, updated_at
      FROM ruvi_venues WHERE owner = ? ORDER BY updated_at DESC LIMIT 50
    `, user).all();
    const review = venueAdmin(env, email) ? await sql(env.DB, `
      SELECT ${venueFields}, phone, status, membership_active, updated_at FROM ruvi_venues
      ORDER BY CASE status WHEN 'pending' THEN 0 ELSE 1 END, updated_at DESC LIMIT 50
    `).all() : null;
    return json({ signedIn: true, venues: mine.results, review: review?.results, billing: venueBilling(env) });
  }
  return fail('invalid', 404);
}

async function venueWrite(request, env, path, user, email, body, now) {
  const db = env.DB;
  const id = clean(body.id, 36);
  if (!/^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(id)) return fail('invalid');
  if (path === '/api/ruvi/venues/save') {
    const { category, region } = body;
    const name = clean(body.name, 100);
    const country = region === 'eu' ? clean(body.country, 100) : '';
    const city = clean(body.city, 100);
    const address = clean(body.address, 180);
    const description = clean(body.description, 450);
    const phone = clean(body.phone, 40);
    if (!venueRegions.includes(region) || !venueCategories.includes(category) || !name || !city || !address
      || !description || !phone || (region === 'eu' && !country)) return fail('invalid');
    const values = [name, category, region, country, city, venueKey(city), address, description, phone, now];
    if (!Number.isSafeInteger(body.updated_at)) return fail('unavailable', 403);
    const result = await sql(db, `
      UPDATE ruvi_venues SET name = ?, category = ?, region = ?, country = ?, city = ?, city_key = ?,
        address = ?, description = ?, phone = ?, status = 'pending', updated_at = ?
      WHERE id = ? AND owner = ? AND updated_at = ?
    `, ...values, id, user, body.updated_at).run();
    if (!changed(result)) return fail('changed', 409);
    return json({ saved: true });
  }
  if (path === '/api/ruvi/venues/review') {
    if (!venueAdmin(env, email)) return fail('forbidden', 403);
    if (!['approved', 'rejected'].includes(body.status) || !Number.isSafeInteger(body.updated_at)) return fail('invalid');
    const result = await sql(db, 'UPDATE ruvi_venues SET status = ?, updated_at = ? WHERE id = ? AND updated_at = ?',
      body.status, now, id, body.updated_at).run();
    return changed(result) ? json({ saved: true }) : fail('changed', 409);
  }
  if (path === '/api/ruvi/venues/subscribe' || path === '/api/ruvi/venues/billing') {
    if (!venueBilling(env)) return fail('unavailable', 503);
    const venue = await sql(db, 'SELECT * FROM ruvi_venues WHERE id = ? AND owner = ?', id, user).first();
    if (!venue) return fail('forbidden', 403);
    const origin = new URL(request.url).origin;
    if (path.endsWith('/billing')) {
      if (!venue.stripe_subscription) return fail('changed', 409);
      const subscription = await getVenueSubscription(env, venue.stripe_subscription);
      const portal = await stripeRequest(env, '/billing_portal/sessions', new URLSearchParams({
        customer: subscription.customer, return_url: new URL('/#registrar-establecimiento', origin).href,
      }));
      return typeof portal.url === 'string' && portal.url.startsWith('https://billing.stripe.com/')
        ? json({ checkoutUrl: portal.url }) : fail('unavailable', 503);
    }
    if (venue.status !== 'approved') return fail('forbidden', 403);
    return venueCheckout(env, venue, origin);
  }
  return fail('invalid', 404);
}

const getVenueSubscription = (env, id) => stripeRequest(env, '/subscriptions/' + encodeURIComponent(id));
const venueSubscriptionEnded = (subscription) => ['canceled', 'incomplete_expired'].includes(subscription.status);

async function venueCheckout(env, venue, origin) {
  const db = env.DB;
  if (venue.stripe_subscription) {
    const subscription = await getVenueSubscription(env, venue.stripe_subscription);
    if (!venueSubscriptionEnded(subscription)) return fail('changed', 409);
    const reset = await sql(db, `
      UPDATE ruvi_venues SET stripe_subscription = NULL, membership_active = 0, checkout_session = NULL,
        checkout_attempt = checkout_attempt + 1 WHERE id = ? AND stripe_subscription = ?
    `, venue.id, subscription.id).run();
    if (!changed(reset)) return fail('changed', 409);
    venue.checkout_session = null;
    venue.checkout_attempt++;
  }
  if (venue.checkout_session) {
    const session = await stripeRequest(env, '/checkout/sessions/' + encodeURIComponent(venue.checkout_session));
    if (session.status === 'open') return stripeCheckoutLink(session.url);
    if (session.status === 'complete') {
      await attachVenueSubscription(env, session);
      return json({ refreshed: true });
    }
    if (session.status !== 'expired') return fail('changed', 409);
    const reset = await sql(db, `
      UPDATE ruvi_venues SET checkout_session = NULL, checkout_attempt = checkout_attempt + 1
      WHERE id = ? AND checkout_session = ? AND stripe_subscription IS NULL
    `, venue.id, session.id).run();
    if (!changed(reset)) return fail('changed', 409);
    venue.checkout_attempt++;
  }
  const price = await stripeRequest(env, '/prices/' + encodeURIComponent(env.RUVI_VENUE_MONTHLY_PRICE_ID));
  if (!price.active || price.recurring?.interval !== 'month' || price.recurring.interval_count !== 1
    || price.recurring.usage_type !== 'licensed' || !Number.isInteger(price.unit_amount) || price.unit_amount <= 0) return fail('unavailable', 503);
  const returnToVenue = new URL('/#registrar-establecimiento', origin).href;
  const session = await stripeRequest(env, '/checkout/sessions', new URLSearchParams({
    mode: 'subscription', 'payment_method_types[0]': 'card',
    'line_items[0][price]': price.id, 'line_items[0][quantity]': '1',
    'metadata[ruvi_venue]': venue.id, success_url: returnToVenue, cancel_url: returnToVenue,
  }), 'ruvi-venue-' + venue.id + '-' + venue.checkout_attempt);
  const saved = await sql(db, `
    UPDATE ruvi_venues SET checkout_session = ?
    WHERE id = ? AND status = 'approved' AND checkout_session IS NULL AND stripe_subscription IS NULL AND checkout_attempt = ?
  `, session.id, venue.id, venue.checkout_attempt).run();
  if (!changed(saved)) {
    const current = await sql(db, 'SELECT checkout_session, status FROM ruvi_venues WHERE id = ?', venue.id).first();
    if (current?.checkout_session !== session.id || current.status !== 'approved') return fail('changed', 409);
  }
  return stripeCheckoutLink(session.url);
}

async function attachVenueSubscription(env, session) {
  if (session.mode !== 'subscription' || !session.metadata?.ruvi_venue
    || typeof session.subscription !== 'string' || typeof session.id !== 'string') return;
  const venue = await sql(env.DB, 'SELECT id FROM ruvi_venues WHERE id = ? AND checkout_session = ?',
    session.metadata.ruvi_venue, session.id).first();
  if (!venue) return;
  const subscription = await getVenueSubscription(env, session.subscription);
  await sql(env.DB, `
    UPDATE ruvi_venues SET stripe_subscription = ?, membership_active = ?
    WHERE id = ? AND checkout_session = ? AND stripe_subscription IS NULL
  `, subscription.id, Number(subscription.status === 'active'), venue.id, session.id).run();
}

async function venueStripeEvent(env, event) {
  const object = event?.data?.object;
  if (!object || !env.STRIPE_SECRET_KEY) return;
  if (event.type === 'checkout.session.completed') {
    await attachVenueSubscription(env, object);
  } else if (['customer.subscription.updated', 'customer.subscription.deleted', 'customer.subscription.paused',
    'customer.subscription.resumed'].includes(event.type) && typeof object.id === 'string') {
    const venue = await sql(env.DB, 'SELECT id FROM ruvi_venues WHERE stripe_subscription = ?', object.id).first();
    if (!venue) return;
    const subscription = await getVenueSubscription(env, object.id);
    if (venueSubscriptionEnded(subscription)) {
      await sql(env.DB, `
        UPDATE ruvi_venues SET stripe_subscription = NULL, membership_active = 0, checkout_session = NULL,
          checkout_attempt = checkout_attempt + 1 WHERE id = ? AND stripe_subscription = ?
      `, venue.id, subscription.id).run();
    } else {
      await sql(env.DB, 'UPDATE ruvi_venues SET membership_active = ? WHERE id = ? AND stripe_subscription = ?',
        Number(subscription.status === 'active'), venue.id, subscription.id).run();
    }
  }
}
