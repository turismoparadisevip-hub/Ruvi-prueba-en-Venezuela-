const merchantVenueFields = 'id, name, region, country, city, address, description, status, phone, contact_name, store_type, hours, own_delivery';
const merchantProductFields = 'id, venue_id, name, description, amount, currency, photo, available, version';
const merchantId = value => typeof value === 'string' && /^[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}$/i.test(value);

async function merchantRead(request, env, path, user) {
  if (!env.DB) return fail('unavailable', 503);
  if (path === '/api/ruvi/merchant/marketplace') {
    const params = new URL(request.url).searchParams;
    const query = clean(params.get('q'), 80).toLowerCase();
    const city = venueKey(clean(params.get('city'), 100));
    const cursor = params.get('cursor') ?? '';
    const region = params.get('region') ?? 've';
    if (!['ve', 'do'].includes(region)) return fail('invalid');
    if (cursor && !merchantId(cursor)) return fail('invalid');
    const result = await sql(env.DB, `
      SELECT p.id, p.venue_id, p.name, p.description, p.amount, p.currency, p.photo,
        v.name AS shop_name, v.city
      FROM ruvi_menu_products p JOIN ruvi_venues v ON v.id = p.venue_id
      WHERE p.archived = 0 AND p.available = 1 AND v.status = 'approved'
        AND v.merchant_enrolled = 1 AND v.store_type = 'tienda' AND v.region = ?
        AND (? = '' OR instr(lower(p.name || ' ' || p.description || ' ' || v.name), ?) > 0)
        AND (? = '' OR instr(v.city_key, ?) > 0)
        AND (? = '' OR p.id > ?)
      ORDER BY p.id LIMIT 13
    `, region, query, query, city, city, cursor, cursor).all();
    const items = result.results.slice(0, 12);
    return json({ products: items, nextCursor: result.results.length > 12 ? items.at(-1).id : null });
  }
  if (path === '/api/ruvi/merchant/profile') {
    if (!user) return fail('signin', 401);
    const venues = await sql(env.DB, `SELECT ${merchantVenueFields} FROM ruvi_venues
      WHERE owner = ? AND merchant_enrolled = 1 ORDER BY updated_at DESC LIMIT 10`, user).all();
    const products = await sql(env.DB, `SELECT ${merchantProductFields} FROM ruvi_menu_products
      WHERE archived = 0 AND venue_id IN (SELECT id FROM ruvi_venues WHERE owner = ? AND merchant_enrolled = 1)
      ORDER BY name`, user).all();
    return json({ venues: venues.results, products: products.results });
  }
  if (path !== '/api/ruvi/merchant/menu') return fail('invalid', 404);
  const id = new URL(request.url).searchParams.get('id');
  if (!merchantId(id)) return fail('invalid');
  const venue = await sql(env.DB, `SELECT id, owner, name, region, country, city, address, description, store_type, hours, status
    FROM ruvi_venues WHERE id = ? AND merchant_enrolled = 1`, id).first();
  if (!venue || (venue.status !== 'approved' && venue.owner !== user)) return fail('menu_unavailable', 404);
  const products = await sql(env.DB, `SELECT name, description, amount, currency, photo
    FROM ruvi_menu_products WHERE venue_id = ? AND archived = 0 AND available = 1 ORDER BY name`, id).all();
  const { owner, ...publicVenue } = venue;
  return json({ venue: publicVenue, preview: venue.status !== 'approved', products: products.results });
}

async function merchantWrite(request, env, path, user, body, now) {
  const db = env.DB;
  if (path === '/api/ruvi/merchant/register') {
    const id = body.id;
    const name = clean(body.name, 100);
    const contact = clean(body.contact, 100);
    const phone = clean(body.phone, 40);
    const address = clean(body.address, 180);
    const description = clean(body.description, 450);
    const hours = clean(body.hours, 180);
    const { storeType, ownDelivery } = body;
    const country = body.country ?? 'VE';
    const cityInput = clean(body.city, 100);
    const cities = { caracas: 'Caracas', valencia: 'Valencia', maracay: 'Maracay' };
    const city = country === 'VE' ? cities[venueKey(cityInput)] : cityInput;
    if (!merchantId(id) || !name || !contact || !address || !description || !hours
      || !/^\+?[0-9 ()-]{7,39}$/.test(phone) || phone.replace(/\D/g, '').length < 7
      || !['VE', 'DO'].includes(country) || !city
      || !['restaurante', 'luncheria', 'cafeteria', 'comida-rapida', 'bar', 'discoteca', 'lounge', 'tienda', 'otro'].includes(storeType)
      || typeof ownDelivery !== 'boolean') return fail('invalid');
    const category = storeType === 'tienda' ? 'shopping'
      : ['bar', 'discoteca', 'lounge'].includes(storeType) ? 'clubs' : 'food';
    const result = await sql(db, `
      INSERT OR IGNORE INTO ruvi_venues
        (id, owner, name, category, region, country, city, city_key, address, description, phone,
         status, updated_at, merchant_enrolled, contact_name, store_type, hours, own_delivery)
      SELECT ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, 1, ?, ?, ?, ?
      WHERE (SELECT count(*) FROM ruvi_venues WHERE owner = ? AND merchant_enrolled = 1) < 10
    `, id, user, name, category, country === 'DO' ? 'do' : 've', country === 'DO' ? 'República Dominicana' : 'Venezuela', city, venueKey(city), address, description, phone, now,
    contact, storeType, hours, Number(ownDelivery), user).run();
    if (!changed(result)) {
      const existing = await sql(db, 'SELECT id FROM ruvi_venues WHERE id = ? AND owner = ?', id, user).first();
      if (!existing) return fail('changed', 409);
    }
    return json({ saved: true });
  }
  if (path === '/api/ruvi/merchant/archive') {
    if (!merchantId(body.id) || !Number.isSafeInteger(body.version)) return fail('invalid');
    const result = await sql(db, `
      UPDATE ruvi_menu_products SET archived = 1, version = version + 1
      WHERE id = ? AND version = ? AND archived = 0
        AND venue_id IN (SELECT id FROM ruvi_venues WHERE owner = ? AND merchant_enrolled = 1)
    `, body.id, body.version, user).run();
    return changed(result) ? json({ saved: true }) : fail('changed', 409);
  }
  if (path !== '/api/ruvi/merchant/product') return fail('invalid', 404);
  const { id, venueId, amount, currency, available, version } = body;
  const name = clean(body.name, 100);
  const description = clean(body.description, 450);
  const photo = body.photo ?? '';
  if (!merchantId(id) || !merchantId(venueId) || !name || !Number.isSafeInteger(amount) || amount < 1 || amount > 100000000
    || !['USD', 'VES', 'DOP'].includes(currency) || typeof available !== 'boolean'
    || !Number.isSafeInteger(version) || version < 0
    || typeof photo !== 'string' || photo.length > 130000
    || (photo && !/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(photo))) return fail('invalid');
  let result;
  if (version === 0) {
    result = await sql(db, `
      INSERT OR IGNORE INTO ruvi_menu_products (id, venue_id, name, description, amount, currency, photo, available)
      SELECT ?, id, ?, ?, ?, ?, ?, ? FROM ruvi_venues
      WHERE id = ? AND owner = ? AND merchant_enrolled = 1
        AND (SELECT count(*) FROM ruvi_menu_products p JOIN ruvi_venues v ON v.id = p.venue_id WHERE v.owner = ? AND p.archived = 0) < 100
    `, id, name, description, amount, currency, photo, Number(available), venueId, user, user).run();
    if (!changed(result)) {
      const existing = await sql(db, `SELECT id FROM ruvi_menu_products WHERE id = ? AND venue_id = ?
        AND venue_id IN (SELECT id FROM ruvi_venues WHERE owner = ?)`, id, venueId, user).first();
      if (existing) return json({ saved: true });
    }
  } else {
    result = await sql(db, `
      UPDATE ruvi_menu_products SET name = ?, description = ?, amount = ?, currency = ?, photo = ?,
        available = ?, version = version + 1
      WHERE id = ? AND venue_id = ? AND version = ? AND archived = 0
        AND venue_id IN (SELECT id FROM ruvi_venues WHERE owner = ? AND merchant_enrolled = 1)
    `, name, description, amount, currency, photo, Number(available), id, venueId, version, user).run();
  }
  return changed(result) ? json({ saved: true }) : fail('changed', 409);
}
