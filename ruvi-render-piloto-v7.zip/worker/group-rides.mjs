let groupSchema;
function ensureGroupSchema(db) {
  groupSchema ??= db.batch([
    db.prepare('CREATE TABLE IF NOT EXISTS ruvi_group_vehicles (driver TEXT PRIMARY KEY, zone TEXT NOT NULL, vehicle TEXT NOT NULL, seats INTEGER NOT NULL, active_until INTEGER NOT NULL)'),
    db.prepare('CREATE TABLE IF NOT EXISTS ruvi_group_requests (id TEXT PRIMARY KEY, rider TEXT NOT NULL, zone TEXT NOT NULL, vehicle TEXT NOT NULL, passengers INTEGER NOT NULL, pickup TEXT NOT NULL, destination TEXT NOT NULL, service TEXT NOT NULL, trip TEXT NOT NULL, departure INTEGER NOT NULL, accepted TEXT, created INTEGER NOT NULL)'),
    db.prepare('CREATE TABLE IF NOT EXISTS ruvi_group_offers (id TEXT PRIMARY KEY, request_id TEXT NOT NULL, driver TEXT NOT NULL, amount INTEGER NOT NULL, note TEXT NOT NULL, UNIQUE(request_id, driver))'),
  ]).catch(error => { groupSchema = undefined; throw error; });
  return groupSchema;
}

async function groupRideApi(db, user, approved, body, now) {
  await ensureGroupSchema(db);
  const { action, zone, vehicle, seats, passengers } = body;
  const validZone = zone === 'pc' || zone === 've';
  const validVehicle = vehicle === 'van' || vehicle === 'camioneta';
  if (action === 'request') {
    const pickup = clean(body.pickup, 150), destination = clean(body.destination, 150);
    const { service, trip, departure } = body;
    if (!validZone || !validVehicle || !Number.isInteger(passengers) || passengers < 1 || passengers > 30
      || !pickup || !destination || !['traslado','excursion'].includes(service)
      || !['ida','regreso','espera'].includes(trip) || !Number.isSafeInteger(departure) || departure <= now) return fail('invalid');
    if (!await throttle(db, 'group-request:' + user, now, 5000)) return fail('wait', 429);
    await sql(db, 'INSERT INTO ruvi_group_requests VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?)',
      crypto.randomUUID(), user, zone, vehicle, passengers, pickup, destination, service, trip, departure, now).run();
    return json({ ok: true }, 201);
  }
  if (action === 'accept') {
    const result = await sql(db, `UPDATE ruvi_group_requests SET accepted = ? WHERE id = ? AND rider = ?
      AND accepted IS NULL AND departure > ? AND EXISTS
      (SELECT 1 FROM ruvi_group_offers WHERE id = ? AND request_id = ruvi_group_requests.id)`,
      clean(body.offer, 36), clean(body.request, 36), user, now, clean(body.offer, 36)).run();
    return changed(result) ? json({ ok: true }) : fail('unavailable', 409);
  }
  if (action === 'passenger') {
    const { results } = await sql(db, 'SELECT * FROM ruvi_group_requests WHERE rider = ? ORDER BY created DESC LIMIT 25', user).all();
    const offers = await sql(db, `SELECT o.id, o.request_id, o.amount, o.note, d.name, d.car_details
      FROM ruvi_group_offers o JOIN ruvi_group_requests r ON r.id = o.request_id
      JOIN ruvi_drivers d ON d.id = o.driver WHERE r.rider = ? AND (r.departure > ? OR r.accepted = o.id)
      ORDER BY o.amount LIMIT 300`, user, now).all();
    return json({ requests: results.map(({ rider, ...row }) => ({ ...row, offers: offers.results.filter(o => o.request_id === row.id) })) });
  }

  if (!approved) return fail('driver_required', 403);
  const profile = await ownDriver(db, user);
  if (!profile || !['pc','ve'].includes(profile.zone)) return fail('driver_required', 403);
  if (action === 'vehicle') {
    if (!validVehicle || !Number.isInteger(seats) || seats < 1 || seats > 30 || typeof body.online !== 'boolean') return fail('invalid');
    await sql(db, `INSERT INTO ruvi_group_vehicles VALUES (?, ?, ?, ?, ?) ON CONFLICT(driver)
      DO UPDATE SET zone=excluded.zone, vehicle=excluded.vehicle, seats=excluded.seats, active_until=excluded.active_until`,
      user, profile.zone, vehicle, seats, body.online ? now + 3600000 : 0).run();
    return json({ ok: true });
  }
  if (action === 'offer') {
    const { amount } = body;
    if (!Number.isSafeInteger(amount) || amount < 1 || amount > 100000000) return fail('invalid');
    const result = await sql(db, `INSERT INTO ruvi_group_offers (id, request_id, driver, amount, note)
      SELECT ?, r.id, v.driver, ?, ? FROM ruvi_group_requests r JOIN ruvi_group_vehicles v
      ON v.driver = ? AND v.zone = r.zone AND v.vehicle = r.vehicle AND v.seats >= r.passengers
      WHERE r.id = ? AND r.rider != v.driver AND r.zone = ? AND r.accepted IS NULL AND r.departure > ? AND v.active_until > ?
      ON CONFLICT(request_id,driver) DO NOTHING`,
      crypto.randomUUID(), amount, clean(body.note, 240), user, clean(body.request, 36), profile.zone, now, now).run();
    return changed(result) ? json({ ok: true }) : fail('unavailable', 409);
  }
  if (action !== 'driver') return fail('invalid');
  const registered = await sql(db, 'SELECT vehicle, seats, active_until FROM ruvi_group_vehicles WHERE driver = ?', user).first();
  const { results } = await sql(db, `SELECT r.id,r.zone,r.vehicle,r.passengers,r.pickup,r.destination,r.service,r.trip,r.departure,r.accepted,o.id AS offer,o.amount
    FROM ruvi_group_requests r LEFT JOIN ruvi_group_offers o ON o.request_id=r.id AND o.driver=?
    LEFT JOIN ruvi_group_vehicles v ON v.driver=? AND v.zone=r.zone AND v.vehicle=r.vehicle AND v.seats>=r.passengers
    WHERE (r.accepted=o.id OR (r.accepted IS NULL AND r.departure>? AND r.zone=? AND r.rider!=? AND v.active_until>?))
    ORDER BY r.departure LIMIT 40`, user,user,now,profile.zone,user,now).all();
  return json({ vehicle: registered, zone: profile.zone, requests: results });
}
