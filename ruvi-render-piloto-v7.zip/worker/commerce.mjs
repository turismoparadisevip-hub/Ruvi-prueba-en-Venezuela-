const commerceCategories = ['products','technology','fashion','home','parts','vehicles','properties'];
const commerceRegions = ['ve','do','us','eu'];
const commerceClassified = category => ['vehicles','properties'].includes(category);
const commerceAdmin = (env,email) => venueAdmin(env,email) || Boolean(email && (env.RUVI_MARKETPLACE_ADMIN_EMAILS ?? '').split(',').some(v=>v.trim().toLowerCase()===email));
const commerceMoney = value => Number.isSafeInteger(value) && value >= 0 && value <= 100000000;
const commercePhone = value => typeof value === 'string' && /^\+?[0-9 ()-]{7,39}$/.test(value);
const commercePublicFields = 'l.id,l.name,l.description,l.category,l.region,l.country,l.city,l.amount,l.currency,l.photo,l.stock,l.version,s.name AS seller_name,l.seller';
async function commerceApi(request,env,path,user,email,body,now=Date.now()) {
 const db=env.DB; if(!db)return fail('unavailable',503);
 const endpoint=path.replace('/api/ruvi/commerce/','');
 const admin=commerceAdmin(env,email);
 const params=new URL(request.url).searchParams;
 if(request.method==='GET') {
  if(endpoint==='catalog') {
   const region=params.get('region')||'ve', category=params.get('category')||'', city=venueKey(clean(params.get('city'),100)), q=clean(params.get('q'),80).toLowerCase();
   if(!commerceRegions.includes(region)||(category&&!commerceCategories.includes(category)))return fail('invalid');
   const rows=await sql(db,`SELECT ${commercePublicFields} FROM ruvi_listings l JOIN ruvi_sellers s ON s.id=l.seller
    WHERE l.status='approved' AND s.status='approved' AND l.stock>0 AND l.region=?
    AND (?='' OR l.category=?) AND (?='' OR instr(l.city_key,?)>0)
    AND (?='' OR instr(lower(l.name || ' ' || l.description),?)>0)
    ORDER BY l.created_at DESC LIMIT 60`,region,category,category,city,city,q,q).all();
   return json({listings:rows.results});
  }
  if(endpoint==='session')return json({signedIn:Boolean(user),admin,cardConfigured:Boolean(env.RUVI_MARKETPLACE_CARD_ENABLED==='true'&&env.STRIPE_SECRET_KEY&&env.STRIPE_WEBHOOK_SECRET)});
  if(!user)return fail('signin',401);
  if(endpoint==='mine') {
   const seller=await sql(db,'SELECT id,name,phone,status,stripe_account IS NOT NULL AS card_ready FROM ruvi_sellers WHERE id=?',user).first();
   const listings=await sql(db,'SELECT * FROM ruvi_listings WHERE seller=? ORDER BY created_at DESC LIMIT 100',user).all();
   return json({seller,listings:listings.results});
  }
  if(endpoint==='orders') {
   const rows=await sql(db,`SELECT o.*,s.name AS seller_name,s.phone AS seller_phone FROM ruvi_orders o JOIN ruvi_sellers s ON s.id=o.seller WHERE o.buyer=? OR o.seller=? ORDER BY o.created_at DESC LIMIT 100`,user,user).all();
   for(const o of rows.results.filter(o=>o.buyer===user&&o.checkout_session&&!o.paid_at&&o.state==='confirmed').slice(0,5)){if(env.STRIPE_SECRET_KEY){const session=await stripeRequest(env,'/checkout/sessions/'+o.checkout_session);await commerceRecordPayment(db,session,now);if(session.payment_status==='paid'){o.paid_at=now;o.version++;}}}
   return json({orders:rows.results.map(o=>({...o,items:JSON.parse(o.items),role:o.buyer===user?'buyer':'seller'}))});
  }
  if(endpoint==='inquiries') {const result=await sql(db,`SELECT i.*,l.name AS listing_name FROM ruvi_market_inquiries i JOIN ruvi_listings l ON l.id=i.listing WHERE i.buyer=? OR i.seller=? ORDER BY i.created_at DESC LIMIT 100`,user,user).all();return json({inquiries:result.results.map(i=>({...i,role:i.seller===user?'seller':'buyer'}))});}
  if(endpoint==='review'&&admin) {
   const sellers=await sql(db,'SELECT id,name,phone,status,stripe_account FROM ruvi_sellers ORDER BY created_at DESC LIMIT 100').all();
   const listings=await sql(db,`SELECT ${commercePublicFields},l.status FROM ruvi_listings l JOIN ruvi_sellers s ON s.id=l.seller WHERE l.status='pending' ORDER BY l.created_at LIMIT 100`).all();
   const claims=await sql(db,`SELECT id,order_id,reason,state FROM ruvi_market_claims WHERE state='open' LIMIT 100`).all();
   const reports=await sql(db,`SELECT r.id,r.reason,r.listing,l.name FROM ruvi_market_reports r JOIN ruvi_listings l ON l.id=r.listing WHERE r.state='open' LIMIT 100`).all();
   return json({sellers:sellers.results,listings:listings.results,reports:reports.results,claims:claims.results});
  }
  return fail('invalid',404);
 }
 if(!user)return fail('signin',401);
 if(endpoint==='inquiry') {
  const name=clean(body.name,100),phone=clean(body.phone,40);
  if(!merchantId(body.id)||!name||!commercePhone(phone))return fail('invalid');
  const listing=await sql(db,`SELECT l.seller FROM ruvi_listings l JOIN ruvi_sellers s ON s.id=l.seller WHERE l.id=? AND l.status='approved' AND s.status='approved' AND l.category IN ('vehicles','properties') AND l.stock>0`,body.id).first();
  if(!listing||listing.seller===user)return fail('changed',409);
  await sql(db,`INSERT OR IGNORE INTO ruvi_market_inquiries(id,buyer,seller,listing,name,phone,created_at) SELECT ?,?,?,?,?,?,? WHERE (SELECT count(*) FROM ruvi_market_inquiries WHERE buyer=?)<100`,crypto.randomUUID(),user,listing.seller,body.id,name,phone,now,user).run();return json({saved:true});
 }
 if(endpoint==='inquiry-reply') {const reply=clean(body.reply,700);if(!reply)return fail('invalid');const result=await sql(db,'UPDATE ruvi_market_inquiries SET reply=? WHERE id=? AND seller=?',reply,body.id,user).run();return changed(result)?json({saved:true}):fail('changed',409);}
 if(endpoint==='claim') {const reason=clean(body.reason,700);if(reason.length<10)return fail('invalid');const order=await sql(db,'SELECT id FROM ruvi_orders WHERE id=? AND (buyer=? OR seller=?)',body.id,user,user).first();if(!order)return fail('invalid');await sql(db,'INSERT OR IGNORE INTO ruvi_market_claims(id,order_id,reporter,reason,created_at) VALUES(?,?,?,?,?)',crypto.randomUUID(),body.id,user,reason,now).run();return json({saved:true});}
 if(endpoint==='seller') {
  const name=clean(body.name,100),phone=clean(body.phone,40);
  if(!name||!commercePhone(phone))return fail('invalid');
  await sql(db,`INSERT INTO ruvi_sellers(id,name,phone,created_at) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,phone=excluded.phone,status='pending',stripe_account=NULL`,user,name,phone,now).run();
  return json({saved:true});
 }
 if(endpoint==='listing') {
  const {id,amount,currency,stock,category,region,version}=body;
  const name=clean(body.name,100), description=clean(body.description,1500), city=clean(body.city,100), country=clean(body.country,100),photo=body.photo;
  if(!merchantId(id)||!name||!description||!city||!country||!commerceRegions.includes(region)||!commerceCategories.includes(category)
   ||!commerceMoney(amount)||amount<1||!['USD','DOP','VES','EUR','GBP'].includes(currency)||!Number.isInteger(stock)||stock<0||stock>10000
   ||typeof photo!=='string'||photo.length>130000||!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/]+={0,2}$/.test(photo)
   ||!Number.isInteger(version)||version<0)return fail('invalid');
  if(!await sql(db,'SELECT id FROM ruvi_sellers WHERE id=?',user).first())return fail('seller_required',409);
  let result;
  if(version===0)result=await sql(db,`INSERT OR IGNORE INTO ruvi_listings(id,seller,name,description,category,region,country,city,city_key,amount,currency,photo,stock,created_at)
   SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,? WHERE (SELECT count(*) FROM ruvi_listings WHERE seller=?)<100`,id,user,name,description,category,region,country,city,venueKey(city),amount,currency,photo,stock,now,user).run();
  else result=await sql(db,`UPDATE ruvi_listings SET name=?,description=?,category=?,region=?,country=?,city=?,city_key=?,amount=?,currency=?,photo=?,stock=?,status='pending',version=version+1 WHERE id=? AND seller=? AND version=?`,name,description,category,region,country,city,venueKey(city),amount,currency,photo,stock,id,user,version).run();
  return changed(result)?json({saved:true}):fail('changed',409);
 }
 if(endpoint==='sold') {
  const result=await sql(db,`UPDATE ruvi_listings SET status='sold',stock=0,version=version+1 WHERE id=? AND seller=? AND version=?`,body.id,user,body.version).run();
  return changed(result)?json({saved:true}):fail('changed',409);
 }
 if(endpoint==='report') {
  const reason=clean(body.reason,500);
  if(!merchantId(body.id)||reason.length<10)return fail('invalid');
  await sql(db,`INSERT OR IGNORE INTO ruvi_market_reports(id,reporter,listing,reason,created_at) SELECT ?,?,?,?,? WHERE EXISTS(SELECT 1 FROM ruvi_listings WHERE id=?) AND (SELECT count(*) FROM ruvi_market_reports WHERE reporter=?)<100`,crypto.randomUUID(),user,body.id,reason,now,body.id,user).run();return json({saved:true});
 }
 if(endpoint==='review'&&admin) {
  if(body.kind==='claim'){await sql(db,"UPDATE ruvi_market_claims SET state='resolved' WHERE id=?",body.id).run();return json({saved:true});}
  if(body.kind==='report') {await sql(db,"UPDATE ruvi_market_reports SET state='resolved' WHERE id=?",body.id).run();return json({saved:true});}
  if(!['approved','rejected'].includes(body.status))return fail('invalid');
  if(body.kind==='seller') {
   const account=body.account||null;
   if(account){if(!/^acct_[A-Za-z0-9]+$/.test(account)||!env.STRIPE_SECRET_KEY)return fail('invalid');const verified=await stripeRequest(env,'/accounts/'+account);if(!verified.charges_enabled||!verified.payouts_enabled)return fail('account_unavailable',409);}
   await sql(db,'UPDATE ruvi_sellers SET status=?,stripe_account=? WHERE id=?',body.status,account,body.id).run();
  } else if(body.kind==='listing') await sql(db,'UPDATE ruvi_listings SET status=?,version=version+1 WHERE id=?',body.status,body.id).run();
  else return fail('invalid');return json({saved:true});
 }
 if(endpoint==='order')return commerceCreateOrder(db,user,body,now);
 if(endpoint==='order-action')return commerceOrderAction(db,user,body,now);
 if(endpoint==='checkout') {
  const order=await sql(db,`SELECT o.*,s.stripe_account,s.status AS seller_status FROM ruvi_orders o JOIN ruvi_sellers s ON s.id=o.seller WHERE o.id=? AND o.buyer=?`,body.id,user).first();
  if(!order||order.payment!=='card'||order.state!=='confirmed'||order.paid_at||order.seller_status!=='approved')return fail('changed',409);
  if(!['USD','DOP','EUR','GBP'].includes(order.currency)||env.RUVI_MARKETPLACE_CARD_ENABLED!=='true'||!env.STRIPE_SECRET_KEY||!env.STRIPE_WEBHOOK_SECRET||!order.stripe_account)return fail('card_unavailable',503);
  const bps=Number(env.RUVI_MARKETPLACE_COMMISSION_BPS);
  if(!Number.isInteger(bps)||bps<0||bps>3000)return fail('card_unavailable',503);
  if(order.checkout_session) {const session=await stripeRequest(env,'/checkout/sessions/'+order.checkout_session);await commerceRecordPayment(db,session,now);if(session.status==='open')return stripeCheckoutLink(session.url);return fail('changed',409);}
  const locked=await sql(db,"UPDATE ruvi_orders SET payment_locked=1 WHERE id=? AND state='confirmed' AND version=?",order.id,order.version).run();
  if(!changed(locked))return fail('changed',409);
  const origin=new URL(request.url).origin,total=order.amount+order.shipping_amount;
  const values=new URLSearchParams({mode:'payment','payment_method_types[0]':'card','line_items[0][price_data][currency]':order.currency.toLowerCase(),'line_items[0][price_data][unit_amount]':String(total),'line_items[0][price_data][product_data][name]':'Pedido RUVI '+order.id.slice(0,8),'line_items[0][quantity]':'1','metadata[ruvi_order]':order.id,'payment_intent_data[transfer_data][destination]':order.stripe_account,'payment_intent_data[application_fee_amount]':String(Math.floor(order.amount*bps/10000)),success_url:origin+'/marketplace/?pedido='+order.id+'#orders',cancel_url:origin+'/marketplace/#orders'});
  const session=await stripeRequest(env,'/checkout/sessions',values,'ruvi-commerce-'+order.id);
  await sql(db,'UPDATE ruvi_orders SET checkout_session=? WHERE id=? AND checkout_session IS NULL',session.id,order.id).run();return stripeCheckoutLink(session.url);
 }
 return fail('invalid',404);
}
async function commerceCreateOrder(db,user,body,now) {
 if(!merchantId(body.id)||!Array.isArray(body.items)||!body.items.length||body.items.length>20||!['cash','card'].includes(body.payment)||!['pickup','delivery'].includes(body.delivery))return fail('invalid');
 const pending=await sql(db,"SELECT count(*) AS count FROM ruvi_orders WHERE buyer=? AND state IN ('pending','confirmed')",user).first();
 const previous=await sql(db,'SELECT id FROM ruvi_orders WHERE id=? AND buyer=?',body.id,user).first();if(previous)return json({id:previous.id});
 if(pending.count>=20)return fail('too_many_orders',409);
 const name=clean(body.name,100), phone=clean(body.phone,40),address=body.delivery==='pickup'?'Recogida en el punto confirmado por el vendedor':clean(body.address,250);
 if(!name||!commercePhone(phone)||!address)return fail('invalid');
 const seen=new Set(),items=[];let seller,currency,total=0;
 for(const line of body.items){
  if(!merchantId(line.id)||seen.has(line.id)||!Number.isInteger(line.quantity)||line.quantity<1||line.quantity>20)return fail('invalid');seen.add(line.id);
  const product=await sql(db,`SELECT l.*,s.status AS seller_status FROM ruvi_listings l JOIN ruvi_sellers s ON s.id=l.seller WHERE l.id=?`,line.id).first();
  if(!product||product.status!=='approved'||product.seller_status!=='approved'||commerceClassified(product.category)||product.stock<line.quantity||product.seller===user)return fail('stock',409);
  if(seller&&(seller!==product.seller||currency!==product.currency))return fail('one_seller',409);
  if(product.amount!==line.amount||product.version!==line.version)return fail('price_changed',409);
  seller=product.seller;currency=product.currency;total+=product.amount*line.quantity;
  items.push({id:product.id,name:product.name,amount:product.amount,quantity:line.quantity,version:product.version});
 }
 if(!commerceMoney(total)||total<1)return fail('invalid');
 const reservationToken=crypto.randomUUID();
 const conditions=items.map(()=>`EXISTS(SELECT 1 FROM ruvi_listings l JOIN ruvi_sellers s ON s.id=l.seller WHERE l.id=? AND l.version=? AND l.stock>=? AND l.status='approved' AND s.status='approved')`).join(' AND ');
 const insert=sql(db,`INSERT OR IGNORE INTO ruvi_orders(id,buyer,seller,payment,amount,currency,items,contact_name,phone,address,delivery,created_at,reservation_token) SELECT ?,?,?,?,?,?,?,?,?,?,?,?,? WHERE ${conditions} AND (SELECT count(*) FROM ruvi_orders WHERE buyer=? AND state IN ('pending','confirmed'))<20`,body.id,user,seller,body.payment,total,currency,JSON.stringify(items),name,phone,address,body.delivery,now,reservationToken,...items.flatMap(i=>[i.id,i.version,i.quantity]),user);
 // Batch is atomic. Unique order id is checked again under the write lock; an existing order must not reserve twice.
 const reserve=items.map(i=>sql(db,`UPDATE ruvi_listings SET stock=stock-?,version=version+1 WHERE id=? AND version=? AND EXISTS(SELECT 1 FROM ruvi_orders WHERE id=? AND buyer=? AND state='pending' AND reservation_token=?)`,i.quantity,i.id,i.version,body.id,user,reservationToken));
 const result=await db.batch([insert,...reserve]);
 if(!changed(result[0]))return await sql(db,'SELECT id FROM ruvi_orders WHERE id=? AND buyer=?',body.id,user).first()?json({id:body.id}):fail('stock',409);
 return json({id:body.id},201);
}
async function commerceOrderAction(db,user,body,now) {
 const order=await sql(db,'SELECT * FROM ruvi_orders WHERE id=? AND (buyer=? OR seller=?)',body.id,user,user).first();
 if(!order||order.version!==body.version)return fail('changed',409);
 const seller=order.seller===user,action=body.action;
 if(action==='cancel') {
  if(order.paid_at||order.payment_locked||!['pending','confirmed'].includes(order.state))return fail('cancel_unavailable',409);
  const items=JSON.parse(order.items);
  const restore=items.map(i=>sql(db,`UPDATE ruvi_listings SET stock=stock+?,version=version+1 WHERE id=? AND EXISTS(SELECT 1 FROM ruvi_orders WHERE id=? AND version=? AND state IN ('pending','confirmed') AND paid_at IS NULL AND payment_locked=0)`,i.quantity,i.id,order.id,body.version));
  await db.batch([...restore,sql(db,`UPDATE ruvi_orders SET state='cancelled',version=version+1 WHERE id=? AND version=? AND state IN ('pending','confirmed') AND paid_at IS NULL AND payment_locked=0`,order.id,body.version)]);return json({saved:true});
 }
 const next={confirm:'confirmed',ready:'ready',ship:'shipped',received:'delivered'}[action];
 const allowed=action==='confirm'?seller&&order.state==='pending':action==='ready'?seller&&order.state==='confirmed'&&(order.payment==='cash'||order.paid_at):action==='ship'?seller&&order.state==='ready'&&order.delivery==='delivery':action==='received'?!seller&&['ready','shipped'].includes(order.state):false;
 if(!allowed||!next)return fail('changed',409);
 const note=action==='confirm'?clean(body.deliveryNote,350):order.delivery_note;
 if(action==='confirm'&&!note)return fail('invalid');
 const shipping=action==='confirm'?body.shippingAmount:order.shipping_amount;
 if(!commerceMoney(shipping)||(order.delivery==='pickup'&&shipping!==0))return fail('invalid');
 const result=await sql(db,`UPDATE ruvi_orders SET state=?,shipping_amount=?,delivery_note=?,version=version+1 WHERE id=? AND version=?`,next,shipping,note,order.id,body.version).run();return changed(result)?json({saved:true}):fail('changed',409);
}
async function commerceRecordPayment(db,session,now) {
 if(session.payment_status!=='paid'||session.mode!=='payment'||!session.metadata?.ruvi_order||typeof session.id!=='string'||!Number.isSafeInteger(session.amount_total)||typeof session.currency!=='string')return;
 await sql(db,`UPDATE ruvi_orders SET paid_at=?,version=version+1 WHERE id=? AND checkout_session=? AND payment='card' AND state='confirmed' AND paid_at IS NULL AND amount+shipping_amount=? AND currency=?`,now,session.metadata.ruvi_order,session.id,session.amount_total,session.currency.toUpperCase()).run();
}
