const solutionServices={flight:'Vuelo',stay:'Alojamiento',transfer:'Traslado',activities:'Actividades',ride:'Viaje con conductor',mechanic:'Taller o asistencia',parts:'Repuestos',rent:'Renta de vehículo',delivery:'Envío o entrega'};
const solutionDate=value=>typeof value==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(value)&&Number.isFinite(new Date(value+'T12:00:00Z').getTime())&&new Date(value+'T12:00:00Z').toISOString().slice(0,10)===value;
function solutionBrief(body) {
 const description=clean(body.description,1600),origin=clean(body.origin,150),destination=clean(body.destination,150),country=clean(body.country,100),preferences=clean(body.preferences,500);
 const {region,currency,budget,start,end,adults,children,kind}=body;
 if(description.length<15||!destination||!country||!['ve','do','us','eu'].includes(region)||!['USD','DOP','VES','EUR','GBP'].includes(currency)
  ||!Number.isSafeInteger(budget)||budget<1||budget>100000000||!['travel','vehicle','daily'].includes(kind)
  ||!Number.isInteger(adults)||adults<1||adults>30||!Number.isInteger(children)||children<0||children>20
  ||!solutionDate(start)||!solutionDate(end)||end<start)return null;
 if(!Array.isArray(body.services)||body.services.length<1||body.services.length>9||new Set(body.services).size!==body.services.length||body.services.some(s=>!Object.hasOwn(solutionServices,s)))return null;
 if(region==='ve'&&body.services.includes('rent'))return null;
 return {description,origin,destination,country,preferences,region,currency,budget,start,end,adults,children,kind,services:body.services};
}
function solutionQuote(body,brief,now) {
 if(!Array.isArray(body.lines)||body.lines.length!==brief.services.length||!Number.isSafeInteger(body.expiresAt)||body.expiresAt<=now||body.expiresAt>now+7*86400000)return null;
 const services=new Set();let total=0,complete=true;
 const lines=[];
 for(const input of body.lines) {
  const {service,amount,availability,progress}=input;
  const provider=clean(input.provider,150),details=clean(input.details,500),reference=clean(input.reference,100);
  if(!brief.services.includes(service)||services.has(service)||!['pending','available','unavailable'].includes(availability)
   ||!['pending','confirmed','completed'].includes(progress)||!(amount===null||(Number.isSafeInteger(amount)&&amount>=0&&amount<=100000000)))return null;
  services.add(service);
  if(availability==='available'&&(!provider||!details||amount===null))return null;
  if(progress!=='pending'&&(availability!=='available'||!reference))return null;
  if(availability!=='available'||amount===null)complete=false;
  if(amount!==null)total+=amount;
  if(total>100000000)return null;
  lines.push({service,amount,availability,provider,details,progress,reference});
 }
 return {lines,notes:clean(body.notes,1000),complete,total};
}
async function solutionsApi(request,env,path,user,email,body,now=Date.now()) {
 const endpoint=path.replace('/api/ruvi/solutions/',''),admin=commerceAdmin(env,email),db=env.DB;
 if(endpoint==='session'&&request.method==='GET')return json({signedIn:Boolean(user),admin});
 if(!user)return fail('signin',401);if(!db)return fail('unavailable',503);
 if(request.method==='GET') {
  if(endpoint==='mine'||(endpoint==='review'&&admin)){
   const result=endpoint==='review'?await sql(db,"SELECT * FROM ruvi_solutions ORDER BY updated_at DESC LIMIT 100").all():await sql(db,'SELECT * FROM ruvi_solutions WHERE owner=? ORDER BY updated_at DESC LIMIT 50',user).all();
   return json({requests:result.results.map(row=>({...row,brief:JSON.parse(row.brief),quote:row.quote?JSON.parse(row.quote):null}))});
  }
  if(endpoint==='history'){
   const id=new URL(request.url).searchParams.get('id');
   if(!await sql(db,'SELECT id FROM ruvi_solutions WHERE id=? AND (owner=? OR ?=1)',id,user,Number(admin)).first())return fail('forbidden',403);
   const result=await sql(db,'SELECT actor_role,action,details,version,created_at FROM ruvi_solution_events WHERE solution=? ORDER BY created_at,version LIMIT 200',id).all();return json({events:result.results.map(row=>({...row,details:JSON.parse(row.details)}))});
  }
  return fail('invalid',404);
 }
 if(endpoint==='create'){
  if(!merchantId(body.id))return fail('invalid');const brief=solutionBrief(body);if(!brief)return fail('invalid');
  const previous=await sql(db,'SELECT id FROM ruvi_solutions WHERE id=? AND owner=?',body.id,user).first();if(previous)return json({id:previous.id});
  const creationToken=crypto.randomUUID();
  const insert=sql(db,`INSERT OR IGNORE INTO ruvi_solutions(id,owner,brief,currency,created_at,updated_at,mutation_token) SELECT ?,?,?,?,?,?,? WHERE (SELECT count(*) FROM ruvi_solutions WHERE owner=? AND state!='cancelled')<30`,body.id,user,JSON.stringify(brief),brief.currency,now,now,creationToken,user);
  const event=sql(db,`INSERT INTO ruvi_solution_events(id,solution,actor_role,action,details,version,created_at) SELECT ?,?,'customer','submitted',?,1,? WHERE EXISTS(SELECT 1 FROM ruvi_solutions WHERE id=? AND owner=? AND mutation_token=?)`,crypto.randomUUID(),body.id,JSON.stringify({services:brief.services,budget:brief.budget}),now,body.id,user,creationToken);
  const result=await db.batch([insert,event]);return changed(result[0])?json({id:body.id},201):fail('limit',409);
 }
 const current=await sql(db,'SELECT * FROM ruvi_solutions WHERE id=? AND (owner=? OR ?=1)',body.id,user,Number(admin)).first();
 if(!current)return fail('forbidden',403);
 if(!Number.isInteger(body.version)||current.version!==body.version)return fail('changed',409);
 if(current.state==='cancelled')return fail('changed',409);
 const brief=JSON.parse(current.brief),existingQuote=current.quote?JSON.parse(current.quote):null;
 if(endpoint==='quote'&&admin){
  const quote=solutionQuote(body,brief,now);if(!quote)return fail('invalid');
  // Changes to an approved scope, price or supplier require fresh customer approval.
  const commercial=lines=>lines.map(({service,amount,availability,provider,details})=>({service,amount,availability,provider,details})).sort((a,b)=>a.service.localeCompare(b.service));
  const unchanged=current.state==='approved'&&existingQuote&&JSON.stringify(commercial(quote.lines))===JSON.stringify(commercial(existingQuote.lines))&&quote.notes===existingQuote.notes&&body.expiresAt===current.expires_at;
  const state=unchanged?'approved':'quoted';
  await solutionUpdate(db,current,now,state,{quote:JSON.stringify(quote),total:quote.total,expires:body.expiresAt,accepted:unchanged?current.accepted_version:null},'coordinator',unchanged?'progress_updated':'proposal_updated',{quote,expiresAt:body.expiresAt,previousTotal:current.total,needsApproval:!unchanged});
  return json({saved:true});
 }
 if(current.owner!==user)return fail('forbidden',403);
 if(endpoint==='accept'){
  if(current.state!=='quoted'||!existingQuote?.complete||current.expires_at<=now)return fail('quote_unavailable',409);
  if(current.total>brief.budget&&body.acceptOverBudget!==true)return fail('budget',409);
  await solutionUpdate(db,current,now,'approved',{accepted:current.version},'customer','proposal_approved',{total:current.total,currency:current.currency,quote:existingQuote,expiresAt:current.expires_at});return json({saved:true});
 }
 if(endpoint==='change'){
  const reason=clean(body.reason,1000);if(reason.length<10)return fail('invalid');
  await solutionUpdate(db,current,now,'change_requested',{accepted:null},'customer','change_requested',{reason});return json({saved:true});
 }
 if(endpoint==='cancel'){
  // Cancelling a request cannot cancel a supplier reservation automatically.
  await solutionUpdate(db,current,now,'cancelled',{},'customer','request_closed',{hadApproval:current.state==='approved',note:'No supplier reservation or refund has been executed.'});return json({saved:true});
 }
 return fail('invalid',404);
}
async function solutionUpdate(db,current,now,state,values,role,action,details){
 const token=crypto.randomUUID();
 const update=sql(db,`UPDATE ruvi_solutions SET state=?,quote=?,total=?,expires_at=?,accepted_version=?,version=version+1,updated_at=?,mutation_token=? WHERE id=? AND version=?`,state,values.quote??current.quote,values.total??current.total,values.expires??current.expires_at,values.accepted===undefined?current.accepted_version:values.accepted,now,token,current.id,current.version);
 const event=sql(db,`INSERT INTO ruvi_solution_events(id,solution,actor_role,action,details,version,created_at) SELECT ?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM ruvi_solutions WHERE id=? AND mutation_token=?)`,crypto.randomUUID(),current.id,role,action,JSON.stringify(details),current.version+1,now,current.id,token);
 const result=await db.batch([update,event]);if(!changed(result[0]))throw new Error('Solution version conflict');
}
