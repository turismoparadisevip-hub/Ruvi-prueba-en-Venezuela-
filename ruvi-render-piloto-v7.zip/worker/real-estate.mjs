const estateTypes = ['casa', 'apartamento', 'terreno', 'local'];
const estateOperations = ['venta', 'alquiler'];

function estateLink(value) {
  if (!value) return '';
  if (typeof value !== 'string' || value.length > 500) return null;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' && !url.username && !url.password ? url.href : null;
  } catch { return null; }
}

async function realEstateApi(request, env, endpoint, owner) {
  const db = env.DB;
  if (!db) return fail('unavailable', 503);
  if (endpoint === 'estate-search' && request.method === 'GET') {
    const params = new URL(request.url).searchParams;
    const city = venueKey(clean(params.get('city'), 100));
    const type = params.get('type') ?? '';
    const operation = params.get('operation') ?? '';
    if ((type && !estateTypes.includes(type)) || (operation && !estateOperations.includes(operation))) return fail('invalid');
    const result = await sql(db, `SELECT l.id,l.title,l.city,l.property_type,l.operation,l.price,l.location,l.photo,
      p.kind,p.name,p.catalog FROM ruvi_estate_listings l JOIN ruvi_estate_profiles p ON p.owner=l.owner
      WHERE (?='' OR instr(l.city_key,?)>0) AND (?='' OR l.property_type=?) AND (?='' OR l.operation=?)
      ORDER BY l.updated_at DESC LIMIT 60`, city, city, type, type, operation, operation).all();
    return json({ listings: result.results });
  }
  if (!owner) return fail('signin', 401);
  if (request.method === 'GET') {
    const profile = await sql(db, 'SELECT kind,name,registration,catalog FROM ruvi_estate_profiles WHERE owner=?', owner).first();
    const result = await sql(db, 'SELECT id,title,city,property_type,operation,price,location,photo FROM ruvi_estate_listings WHERE owner=? ORDER BY updated_at DESC LIMIT 50', owner).all();
    return json({ profile, listings: result.results });
  }
  let body;
  try { body = await request.json(); } catch { return fail('invalid'); }
  if (!body || typeof body !== 'object') return fail('invalid');
  if (body.action === 'profile') {
    const name = clean(body.name, 100);
    const registration = clean(body.registration, 60);
    const catalog = estateLink(body.catalog);
    const { kind } = body;
    if (!name || !['owner','agency'].includes(kind) || catalog === null || (kind === 'agency' && (!registration || !catalog))) return fail('invalid');
    const saved = await sql(db, `INSERT INTO ruvi_estate_profiles(owner,kind,name,registration,catalog) VALUES(?,?,?,?,?)
      ON CONFLICT(owner) DO UPDATE SET name=excluded.name,registration=excluded.registration,catalog=excluded.catalog
      WHERE ruvi_estate_profiles.kind=excluded.kind`, owner, kind, name, kind === 'agency' ? registration : '', kind === 'agency' ? catalog : '').run();
    return changed(saved) ? json({ saved: true }) : fail('changed', 409);
  }
  const id = body.id;
  if (typeof id !== 'string' || !/^[\da-f-]{36}$/i.test(id)) return fail('invalid');
  if (body.action === 'remove') {
    const result = await sql(db, 'DELETE FROM ruvi_estate_listings WHERE id=? AND owner=?', id, owner).run();
    return changed(result) ? json({ saved: true }) : fail('invalid', 404);
  }
  const title = clean(body.title, 120);
  const city = clean(body.city, 100);
  const location = clean(body.location, 180);
  const photo = estateLink(body.photo);
  const { type, operation, price } = body;
  if (body.action !== 'listing' || !title || !city || !location || photo === null || !estateTypes.includes(type)
    || !estateOperations.includes(operation) || !Number.isSafeInteger(price) || price < 1 || price > 100000000000) return fail('invalid');
  const result = await sql(db, `INSERT INTO ruvi_estate_listings(id,owner,title,city,city_key,property_type,operation,price,location,photo,updated_at)
    SELECT ?,?,?,?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM ruvi_estate_profiles WHERE owner=?)
    AND ((SELECT count(*) FROM ruvi_estate_listings WHERE owner=?)<50 OR EXISTS(SELECT 1 FROM ruvi_estate_listings WHERE id=? AND owner=?))
    ON CONFLICT(id) DO UPDATE SET title=excluded.title,city=excluded.city,city_key=excluded.city_key,
    property_type=excluded.property_type,operation=excluded.operation,price=excluded.price,location=excluded.location,
    photo=excluded.photo,updated_at=excluded.updated_at WHERE ruvi_estate_listings.owner=excluded.owner`,
    id, owner, title, city, venueKey(city), type, operation, price, location, photo, Date.now(), owner, owner, id, owner).run();
  return changed(result) ? json({ saved: true }) : fail('changed', 409);
}
