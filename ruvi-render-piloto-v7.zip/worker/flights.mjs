const flightSearchEnabled = (env) => Boolean(env.DB && env.DUFFEL_ACCESS_TOKEN?.startsWith('duffel_live_'));
const flightCabins = ['economy', 'premium_economy', 'business', 'first'];
const iataPattern = /^[A-Z]{3}$/;

async function duffelRequest(env, path, body) {
  const response = await fetch('https://api.duffel.com' + path, {
    method: body === undefined ? 'GET' : 'POST',
    headers: {
      Accept: 'application/json', 'Content-Type': 'application/json',
      'Duffel-Version': 'v2', Authorization: 'Bearer ' + env.DUFFEL_ACCESS_TOKEN,
    },
    body: body === undefined ? undefined : JSON.stringify({ data: body }),
    signal: AbortSignal.timeout(15000),
  });
  if (!response.ok) throw new Error('Flight inventory unavailable');
  return (await response.json()).data;
}

function flightDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const date = new Date(value + 'T00:00:00Z');
  return Number.isFinite(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

async function flightRateLimit(request, env, kind) {
  const identity = request.headers.get('oai-authenticated-user-id') ?? request.headers.get('CF-Connecting-IP') ?? 'anonymous';
  const bytes = new TextEncoder().encode(env.DUFFEL_ACCESS_TOKEN + ':' + identity);
  const digest = new Uint8Array(await crypto.subtle.digest('SHA-256', bytes));
  const key = Array.from(digest.slice(0, 16), (byte) => byte.toString(16).padStart(2, '0')).join('');
  const now = Date.now();
  const delay = kind === 'places' ? 500 : 6000;
  return throttle(env.DB, 'flights:' + kind + ':' + key, now, delay);
}

function flightOffer(offer, now) {
  const amount = Number(offer.total_amount);
  const expires = Date.parse(offer.expires_at);
  if (typeof offer.id !== 'string' || !Number.isFinite(amount) || amount <= 0
    || !iataPattern.test(offer.total_currency ?? '') || !(expires > now)
    || !Array.isArray(offer.slices) || !offer.slices.length) return null;
  const slices = offer.slices.map((slice) => {
    if (!Array.isArray(slice.segments) || !slice.segments.length) return null;
    const first = slice.segments[0];
    const last = slice.segments.at(-1);
    return {
      origin: first.origin?.iata_code, destination: last.destination?.iata_code,
      departure: first.departing_at, arrival: last.arriving_at,
      stops: slice.segments.length - 1, duration: slice.duration,
    };
  });
  if (slices.some((slice) => !slice?.departure || !slice.arrival || !slice.origin || !slice.destination)) return null;
  return { id: offer.id, amount, currency: offer.total_currency, expires,
    airline: clean(offer.owner?.name, 100), slices };
}

async function flightsApi(request, env, path) {
  if (!flightSearchEnabled(env)) return fail('unavailable', 503);

  if (path === '/api/ruvi/flights/places' && request.method === 'GET') {
    const query = clean(new URL(request.url).searchParams.get('q'), 100);
    if (query.length < 2) return fail('invalid');
    if (!await flightRateLimit(request, env, 'places')) return fail('wait', 429);
    const data = await duffelRequest(env, '/places/suggestions?' + new URLSearchParams({ query }));
    const seen = new Set();
    const places = [];
    for (const place of Array.isArray(data) ? data : []) {
      const code = place.iata_code;
      const name = clean(place.name, 100);
      if (!iataPattern.test(code ?? '') || !name || seen.has(code)) continue;
      seen.add(code);
      places.push({ code, name, city: clean(place.city_name, 100) });
      if (places.length >= 8) break;
    }
    return json({ places });
  }

  if (path !== '/api/ruvi/flights/search' || request.method !== 'POST'
    || request.headers.get('Origin') !== new URL(request.url).origin) return fail('invalid', 403);
  const raw = await request.text();
  if (raw.length > 3000) return fail('invalid', 413);
  let data;
  try { data = JSON.parse(raw); } catch { return fail('invalid'); }
  if (!data || typeof data !== 'object') return fail('invalid');
  const { origin, destination, departure, returning, passengers, cabin, nonstop } = data;
  const today = new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString().slice(0, 10);
  if (typeof origin !== 'string' || typeof destination !== 'string'
    || !iataPattern.test(origin) || !iataPattern.test(destination) || origin === destination
    || !flightDate(departure) || departure < today
    || (returning !== null && (!flightDate(returning) || returning < departure))
    || !Number.isInteger(passengers) || passengers < 1 || passengers > 9
    || !flightCabins.includes(cabin) || typeof nonstop !== 'boolean') return fail('invalid');
  if (!await flightRateLimit(request, env, 'search')) return fail('wait', 429);
  const slices = [{ origin, destination, departure_date: departure }];
  if (returning) slices.push({ origin: destination, destination: origin, departure_date: returning });
  const requestData = await duffelRequest(env, '/air/offer_requests?return_offers=false&supplier_timeout=10000', {
    slices, passengers: Array.from({ length: passengers }, () => ({ type: 'adult' })),
    cabin_class: cabin, max_connections: nonstop ? 0 : 2,
  });
  if (!requestData?.id) throw new Error('Flight inventory unavailable');
  const params = new URLSearchParams({ offer_request_id: requestData.id, limit: '12',
    sort: 'total_amount', max_connections: nonstop ? '0' : '2' });
  const offers = await duffelRequest(env, '/air/offers?' + params);
  const now = Date.now();
  return json({ offers: (Array.isArray(offers) ? offers : []).map((offer) => flightOffer(offer, now)).filter(Boolean) });
}
