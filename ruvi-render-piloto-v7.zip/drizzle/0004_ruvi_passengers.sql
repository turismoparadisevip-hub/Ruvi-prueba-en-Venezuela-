CREATE TABLE ruvi_passengers (
  id TEXT PRIMARY KEY NOT NULL,
  name TEXT NOT NULL,
  payment TEXT NOT NULL CHECK (payment IN ('cash', 'card'))
);
