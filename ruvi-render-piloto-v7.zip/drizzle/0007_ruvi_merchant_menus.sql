ALTER TABLE ruvi_venues ADD COLUMN merchant_enrolled INTEGER NOT NULL DEFAULT 0;
--> statement-breakpoint
ALTER TABLE ruvi_venues ADD COLUMN contact_name TEXT;
--> statement-breakpoint
ALTER TABLE ruvi_venues ADD COLUMN store_type TEXT;
--> statement-breakpoint
ALTER TABLE ruvi_venues ADD COLUMN hours TEXT;
--> statement-breakpoint
ALTER TABLE ruvi_venues ADD COLUMN own_delivery INTEGER NOT NULL DEFAULT 0;
--> statement-breakpoint
CREATE TABLE ruvi_menu_products (
  id TEXT PRIMARY KEY,
  venue_id TEXT NOT NULL REFERENCES ruvi_venues(id),
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  amount INTEGER NOT NULL CHECK (amount > 0),
  currency TEXT NOT NULL CHECK (currency IN ('USD', 'VES')),
  photo TEXT NOT NULL DEFAULT '',
  available INTEGER NOT NULL DEFAULT 1,
  archived INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
);
--> statement-breakpoint
CREATE INDEX ruvi_menu_products_by_venue ON ruvi_menu_products(venue_id, archived);
