CREATE TABLE ruvi_sellers (
 id TEXT PRIMARY KEY, name TEXT NOT NULL, phone TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected')),
 stripe_account TEXT, created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE ruvi_listings (
 id TEXT PRIMARY KEY, seller TEXT NOT NULL REFERENCES ruvi_sellers(id),
 name TEXT NOT NULL, description TEXT NOT NULL, category TEXT NOT NULL,
 region TEXT NOT NULL, country TEXT NOT NULL, city TEXT NOT NULL, city_key TEXT NOT NULL,
 amount INTEGER NOT NULL CHECK(amount>0), currency TEXT NOT NULL,
 photo TEXT NOT NULL, stock INTEGER NOT NULL CHECK(stock>=0),
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','sold')),
 version INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX ruvi_listings_catalog ON ruvi_listings(region,status,city_key);
--> statement-breakpoint
CREATE TABLE ruvi_orders (
 id TEXT PRIMARY KEY, buyer TEXT NOT NULL, seller TEXT NOT NULL REFERENCES ruvi_sellers(id),
 state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','confirmed','ready','shipped','delivered','cancelled')),
 payment TEXT NOT NULL CHECK(payment IN ('cash','card')), paid_at INTEGER,
 amount INTEGER NOT NULL CHECK(amount>0), currency TEXT NOT NULL, items TEXT NOT NULL,
 contact_name TEXT NOT NULL, phone TEXT NOT NULL, address TEXT NOT NULL,
 delivery TEXT NOT NULL CHECK(delivery IN ('pickup','delivery')),
 shipping_amount INTEGER NOT NULL DEFAULT 0 CHECK(shipping_amount>=0),
 checkout_session TEXT UNIQUE, payment_locked INTEGER NOT NULL DEFAULT 0,
 version INTEGER NOT NULL DEFAULT 1, created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX ruvi_orders_buyer ON ruvi_orders(buyer,created_at);
--> statement-breakpoint
CREATE INDEX ruvi_orders_seller ON ruvi_orders(seller,created_at);
--> statement-breakpoint
CREATE TABLE ruvi_market_reports (
 id TEXT PRIMARY KEY, reporter TEXT NOT NULL, listing TEXT NOT NULL REFERENCES ruvi_listings(id),
 reason TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'open' CHECK(state IN ('open','resolved')),
 created_at INTEGER NOT NULL, UNIQUE(reporter,listing)
);
--> statement-breakpoint
ALTER TABLE ruvi_orders ADD COLUMN reservation_token TEXT NOT NULL DEFAULT '';
--> statement-breakpoint
CREATE TABLE ruvi_market_inquiries (
 id TEXT PRIMARY KEY, buyer TEXT NOT NULL, seller TEXT NOT NULL, listing TEXT NOT NULL REFERENCES ruvi_listings(id),
 name TEXT NOT NULL, phone TEXT NOT NULL, reply TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL,
 UNIQUE(buyer,listing)
);
--> statement-breakpoint
CREATE TABLE ruvi_market_claims (
 id TEXT PRIMARY KEY, order_id TEXT NOT NULL REFERENCES ruvi_orders(id), reporter TEXT NOT NULL,
 reason TEXT NOT NULL, state TEXT NOT NULL DEFAULT 'open' CHECK(state IN ('open','resolved')),
 created_at INTEGER NOT NULL, UNIQUE(order_id,reporter)
);
--> statement-breakpoint
ALTER TABLE ruvi_orders ADD COLUMN delivery_note TEXT NOT NULL DEFAULT '';
