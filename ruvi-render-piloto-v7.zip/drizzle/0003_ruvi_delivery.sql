ALTER TABLE ruvi_drivers ADD COLUMN accepts_delivery INTEGER NOT NULL DEFAULT 0 CHECK (accepts_delivery IN (0, 1));
--> statement-breakpoint
ALTER TABLE ruvi_rides ADD COLUMN delivery_note TEXT;
