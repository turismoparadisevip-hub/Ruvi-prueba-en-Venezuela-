CREATE TABLE ruvi_venues (
  id TEXT PRIMARY KEY,
  owner TEXT NOT NULL,
  name TEXT NOT NULL,
  category TEXT NOT NULL,
  region TEXT NOT NULL,
  country TEXT NOT NULL,
  city TEXT NOT NULL,
  city_key TEXT NOT NULL,
  address TEXT NOT NULL,
  description TEXT NOT NULL,
  phone TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'rejected')),
  updated_at INTEGER NOT NULL,
  checkout_session TEXT UNIQUE,
  checkout_attempt INTEGER NOT NULL DEFAULT 0,
  stripe_subscription TEXT UNIQUE,
  membership_active INTEGER NOT NULL DEFAULT 0
);
--> statement-breakpoint
CREATE INDEX ruvi_venues_by_owner ON ruvi_venues(owner, updated_at);
--> statement-breakpoint
CREATE INDEX ruvi_venues_directory ON ruvi_venues(region, status, membership_active, updated_at);
