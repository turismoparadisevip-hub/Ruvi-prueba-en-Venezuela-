CREATE TABLE ruvi_menu_products_dop (
  id TEXT PRIMARY KEY,
  venue_id TEXT NOT NULL REFERENCES ruvi_venues(id),
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  amount INTEGER NOT NULL CHECK (amount > 0),
  currency TEXT NOT NULL CHECK (currency IN ('USD', 'VES', 'DOP')),
  photo TEXT NOT NULL DEFAULT '',
  available INTEGER NOT NULL DEFAULT 1,
  archived INTEGER NOT NULL DEFAULT 0,
  version INTEGER NOT NULL DEFAULT 1
);
--> statement-breakpoint
INSERT INTO ruvi_menu_products_dop
  (id, venue_id, name, description, amount, currency, photo, available, archived, version)
SELECT id, venue_id, name, description, amount, currency, photo, available, archived, version
FROM ruvi_menu_products;
--> statement-breakpoint
DROP TABLE ruvi_menu_products;
--> statement-breakpoint
ALTER TABLE ruvi_menu_products_dop RENAME TO ruvi_menu_products;
--> statement-breakpoint
CREATE INDEX ruvi_menu_products_by_venue ON ruvi_menu_products(venue_id, archived);
