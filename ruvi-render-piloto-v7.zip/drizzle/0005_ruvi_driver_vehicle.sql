ALTER TABLE ruvi_drivers ADD COLUMN car_details TEXT;
--> statement-breakpoint
ALTER TABLE ruvi_drivers ADD COLUMN plate TEXT;
