ALTER TABLE ruvi_rides ADD COLUMN payment_method TEXT NOT NULL DEFAULT 'cash' CHECK (payment_method IN ('cash', 'card'));
--> statement-breakpoint
ALTER TABLE ruvi_rides ADD COLUMN card_paid_at INTEGER;
--> statement-breakpoint
ALTER TABLE ruvi_rides ADD COLUMN checkout_session TEXT;
--> statement-breakpoint
ALTER TABLE ruvi_rides ADD COLUMN checkout_attempt INTEGER NOT NULL DEFAULT 0;
--> statement-breakpoint
CREATE UNIQUE INDEX ruvi_checkout_session ON ruvi_rides(checkout_session) WHERE checkout_session IS NOT NULL;
