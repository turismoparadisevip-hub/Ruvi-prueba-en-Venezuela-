CREATE TABLE ruvi_driver_photos (
  driver_id TEXT NOT NULL REFERENCES ruvi_drivers(id),
  kind TEXT NOT NULL CHECK (kind IN ('front', 'side', 'interior')),
  photo TEXT NOT NULL,
  version INTEGER NOT NULL DEFAULT 1,
  PRIMARY KEY (driver_id, kind)
);
