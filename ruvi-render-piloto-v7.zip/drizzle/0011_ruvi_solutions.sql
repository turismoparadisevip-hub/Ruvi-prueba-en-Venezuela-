CREATE TABLE ruvi_solutions (
 id TEXT PRIMARY KEY, owner TEXT NOT NULL, brief TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'submitted' CHECK(state IN ('submitted','quoted','approved','change_requested','cancelled')),
 quote TEXT, total INTEGER, currency TEXT NOT NULL,
 expires_at INTEGER, accepted_version INTEGER, version INTEGER NOT NULL DEFAULT 1,
 created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX ruvi_solutions_by_owner ON ruvi_solutions(owner,updated_at);
--> statement-breakpoint
CREATE INDEX ruvi_solutions_review ON ruvi_solutions(state,updated_at);
--> statement-breakpoint
CREATE TABLE ruvi_solution_events (
 id TEXT PRIMARY KEY, solution TEXT NOT NULL REFERENCES ruvi_solutions(id),
 actor_role TEXT NOT NULL, action TEXT NOT NULL, details TEXT NOT NULL,
 version INTEGER NOT NULL, created_at INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX ruvi_solution_history ON ruvi_solution_events(solution,created_at);
--> statement-breakpoint
ALTER TABLE ruvi_solutions ADD COLUMN mutation_token TEXT NOT NULL DEFAULT '';
