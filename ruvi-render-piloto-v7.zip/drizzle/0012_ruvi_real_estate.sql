CREATE TABLE ruvi_estate_profiles (
  owner TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('owner','agency')),
  name TEXT NOT NULL,
  registration TEXT NOT NULL,
  catalog TEXT NOT NULL
);
CREATE TABLE ruvi_estate_listings (
  id TEXT PRIMARY KEY,
  owner TEXT NOT NULL REFERENCES ruvi_estate_profiles(owner),
  title TEXT NOT NULL,
  city TEXT NOT NULL,
  city_key TEXT NOT NULL,
  property_type TEXT NOT NULL,
  operation TEXT NOT NULL,
  price INTEGER NOT NULL,
  location TEXT NOT NULL,
  photo TEXT NOT NULL,
  updated_at INTEGER NOT NULL
);
CREATE INDEX ruvi_estate_search ON ruvi_estate_listings(city_key, property_type, operation, updated_at);
CREATE INDEX ruvi_estate_owner ON ruvi_estate_listings(owner);
