CREATE TABLE ruvi_drivers (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  city TEXT NOT NULL,
  zone TEXT NOT NULL,
  vehicle TEXT NOT NULL CHECK (vehicle IN ('carro', 'mototaxi')),
  online INTEGER NOT NULL DEFAULT 0,
  lat REAL,
  lng REAL,
  seen INTEGER NOT NULL DEFAULT 0
);
--> statement-breakpoint
CREATE INDEX ruvi_drivers_dispatch ON ruvi_drivers(zone, vehicle, online, seen);
--> statement-breakpoint
CREATE TABLE ruvi_quotes (
  id TEXT PRIMARY KEY,
  rider TEXT NOT NULL,
  zone TEXT NOT NULL,
  vehicle TEXT NOT NULL,
  pickup TEXT NOT NULL,
  dropoff TEXT NOT NULL,
  from_lat REAL NOT NULL,
  from_lng REAL NOT NULL,
  to_lat REAL NOT NULL,
  to_lng REAL NOT NULL,
  amount INTEGER NOT NULL,
  currency TEXT NOT NULL,
  distance REAL NOT NULL,
  duration REAL NOT NULL,
  expires INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX ruvi_quotes_expiry ON ruvi_quotes(rider, expires);
--> statement-breakpoint
CREATE TABLE ruvi_rides (
  id TEXT PRIMARY KEY,
  rider TEXT NOT NULL,
  zone TEXT NOT NULL,
  vehicle TEXT NOT NULL,
  pickup TEXT NOT NULL,
  dropoff TEXT NOT NULL,
  from_lat REAL NOT NULL,
  from_lng REAL NOT NULL,
  to_lat REAL NOT NULL,
  to_lng REAL NOT NULL,
  amount INTEGER NOT NULL,
  currency TEXT NOT NULL,
  distance REAL NOT NULL,
  duration REAL NOT NULL,
  created INTEGER NOT NULL,
  state TEXT NOT NULL,
  driver_id TEXT REFERENCES ruvi_drivers(id),
  offer_until INTEGER,
  cash_paid INTEGER NOT NULL DEFAULT 0
);
--> statement-breakpoint
CREATE UNIQUE INDEX ruvi_one_ride_per_rider ON ruvi_rides(rider)
WHERE state IN ('searching', 'offered', 'accepted', 'arrived', 'in_progress');
--> statement-breakpoint
CREATE UNIQUE INDEX ruvi_one_ride_per_driver ON ruvi_rides(driver_id)
WHERE state IN ('offered', 'accepted', 'arrived', 'in_progress');
--> statement-breakpoint
CREATE INDEX ruvi_rides_dispatch ON ruvi_rides(zone, vehicle, state, created);
--> statement-breakpoint
CREATE INDEX ruvi_rides_history ON ruvi_rides(rider, created DESC);
--> statement-breakpoint
CREATE TABLE ruvi_offers (
  ride_id TEXT NOT NULL REFERENCES ruvi_rides(id),
  driver_id TEXT NOT NULL REFERENCES ruvi_drivers(id),
  PRIMARY KEY (ride_id, driver_id)
);
--> statement-breakpoint
CREATE TRIGGER ruvi_record_offer AFTER UPDATE ON ruvi_rides
WHEN NEW.state = 'offered' AND OLD.state = 'searching'
BEGIN
  INSERT INTO ruvi_offers (ride_id, driver_id) VALUES (NEW.id, NEW.driver_id);
END;
--> statement-breakpoint
CREATE TABLE ruvi_throttle (
  id TEXT PRIMARY KEY,
  until INTEGER NOT NULL
);
