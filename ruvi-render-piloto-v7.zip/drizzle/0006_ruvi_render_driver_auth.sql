CREATE TABLE ruvi_driver_accounts (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created INTEGER NOT NULL
);
--> statement-breakpoint
CREATE TABLE ruvi_driver_sessions (
  token_hash TEXT PRIMARY KEY,
  account_id TEXT NOT NULL REFERENCES ruvi_driver_accounts(id),
  expires INTEGER NOT NULL
);
--> statement-breakpoint
CREATE INDEX ruvi_driver_sessions_expiry ON ruvi_driver_sessions(expires);
--> statement-breakpoint
CREATE TABLE ruvi_driver_auth_limits (
  id TEXT PRIMARY KEY,
  attempts INTEGER NOT NULL,
  resets INTEGER NOT NULL
);
